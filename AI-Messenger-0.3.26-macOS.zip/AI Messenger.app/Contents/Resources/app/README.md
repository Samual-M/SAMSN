# AI Messenger

A desktop AI chat client that keeps the **classic MSN Messenger 7.5 interface** (menus, layouts, graphics,
strings) and replaces everything behind it. Contacts are AI models; conversations stream replies.

## Run
* **Linux (.deb):** `sudo apt install ./ai-messenger_*.deb`, then start *AI Messenger* from the app menu or run `ai-messenger`.
* **macOS / Windows:** copy `/usr/lib/ai-messenger` (or this folder) to the machine, install Node.js 18+ and Chrome, Edge or
  Brave, then run `bin/ai-messenger.command` (macOS) or `bin\ai-messenger.cmd` (Windows). No other dependencies.

## Using it
* **Contacts > Add a Contact** - pick a provider plug-in, model, base URL and API key. Local models (Ollama, LM Studio) need no key:
  provider *OpenAI-compatible*, base URL `http://localhost:11434/v1`.
* Double-click a contact to chat. `Enter` sends, `Shift+Enter` adds a line, `Esc` stops a reply.
* Attach images or text files with **Send a File or Photo**, drag-and-drop, or paste an image.
* The "nudge" button regenerates the last reply. Tools > Text Size, Edit menu, File > Save (exports a transcript) all work.
* Menu items that belong to MSN's online services (mobile messages, MSN Today, ...) are kept for fidelity and show
  "not available in this version".

## Privacy
Nothing is sent anywhere except the AI endpoint you configure for a contact. No telemetry, no analytics, no third parties.
The server listens on 127.0.0.1 only, requires a random per-launch token and rejects foreign Host headers.
Data lives in `~/.config/ai-messenger` (Linux), `~/Library/Application Support/AI Messenger` (macOS) or `%APPDATA%\AI Messenger`
(Windows). API keys are stored in `config.json` (mode 0600) and are never sent back to the UI.

## Adding an AI backend (plug-ins)
Drop a `.js` file in `<data folder>/plugins/`:

```js
module.exports = {
  id: 'mybackend', name: 'My backend',
  fields: [{ key: 'apiKey', label: 'API key', type: 'password', secret: true }],
  models: ['model-1'],
  async listModels(cfg) { return ['model-1']; },          // optional
  async *chat({ messages, model, system, config, signal }) { // messages: [{role:'user'|'assistant', text, attachments}]
    yield 'streamed ';  yield 'text';
  },
};
```
Built-in providers live in `providers/` (OpenAI-compatible, Anthropic, offline demo).

## About the interface assets
`ui/assets` contains resources extracted from Microsoft's MSN Messenger 7.5 installer (layouts `.uif`, images, menus, strings).
They remain Microsoft's property: use them for personal/educational purposes and do not redistribute this package publicly
without replacing them. `ui/uif.js` is a new, independent engine that renders those layout files.

## 0.2.1 - Hugging Face model browser

"Add a Contact" now opens a Hugging Face model browser. Nothing connects until you press **Allow connection**
(the window states the server, operator, what is sent and what happens if you decline). Only huggingface.co
is contacted; your chats, contacts and profile are never sent.

* Filter: models that run on this computer (GGUF, checked against your RAM), online models, or all.
* Pick a file (size and fit are shown), press Download; when it finishes the model is added as a contact.
* Local models appear under **Offline**; online (Hugging Face-hosted) models under **Online**.
* Local models run through llama.cpp's `llama-server` (free, offline). Install it so `llama-server` is on your PATH,
  or put it in `<data folder>/bin/`, or set `AI_MESSENGER_LLAMA_SERVER=/path/to/llama-server`.
* Online models need a Hugging Face access token (stored only in your profile on this computer) and send your
  messages to router.huggingface.co.
* "Add manually (any provider)..." in that window keeps the old dialog (OpenAI-compatible, Anthropic, ...).

Also fixed: long lines/URLs in the chat window, the cut-off message toolbar in narrow windows, and misaligned
toolbar labels.

## 0.2.2

* Model browser filters: purpose (coding, reasoning & math, chat, writing & roleplay, multilingual), size
  (tiny to very large), and "Best my computer can run" sorting, on top of the fits-this-computer checkbox.
* The original MSN display pictures (flower, football, chess, ...) and the classic buddy figure are now the
  default pictures and appear in the Display Picture and contact Picture galleries.
* The original sounds are wired to more events and can be previewed under Options > Sounds.
* Chat window: duplicate title strip removed, MSN logo and window buttons at the right edge.

## 0.3.0

* **Tools > Themes...** switches between MSN Messenger 7.5, 7.0, 6.2, 6.0, 5.1, 5.0 and a new **MSN 8.0 (AI edition)**.
  Each version theme uses that version's art (icons, buttons) where it matches the 7.5 layout, its original sounds,
  and a matching colour treatment. An optional, experimental "original conversation window layout" checkbox loads
  the real 6.0/6.2/7.0 layout files. Only 6.0, 6.2 and 7.0 contained layout files; 5.x was drawn by Windows, so
  5.x themes are art, sound and colour only.
* **MSN 8.0**: the 7.5 layout with a brighter look, speech-bubble messages, **Copy** buttons on messages and code
  blocks, the MSN emoticon set (typed shortcuts like `:)` and `(H)` render as the original emoticons and the
  smiley button opens the full set; not applied inside code), wider history and the 7.0 sounds.
* **Claude**: Add a Contact > Add manually > **Claude preset** fills in the Anthropic provider. It needs an
  Anthropic API key from console.anthropic.com (pay-per-use). A claude.ai subscription cannot be imported:
  its sign-in is not available to third-party apps. Desktop-app-only features (Projects, artifacts, etc.) are not
  part of the API.
* All extracted assets from the five installers are in `assets/sets/<version>/` (Microsoft's, personal use).

## 0.3.1

* **One window like the Claude desktop app.** The contact list and the chat window are combined: a conversations
  column on the left, the conversation on the right (the original MSN conversation window, menus and themes).
  The app opens on a new, empty conversation.
* Sidebar: **+ New conversation**, search, **Pinned**, **Projects**, **Recents** and **Models** (your AI contacts, with
  online/offline status; click one to start a conversation with it). Right-click or use the ... button on any row
  to rename, pin, move to a project, export or delete.
* Conversations are now separate threads (several with the same model), saved per profile. Existing histories are
  converted automatically, one conversation per old contact history.
* **Projects** group conversations and can carry instructions that are sent with every message in them.
* Pick (or change) the model for a conversation in the "To:" drop-down above the messages.
* The old contact-list window is still available at `/?classic=1`.

## 0.3.2

* **Find models on this PC**: scans the usual folders (Hugging Face cache, LM Studio, Ollama, GPT4All, Jan, Downloads,
  Documents, your models folders, plus any folder you type) for `.gguf` files you already have and adds the ones you
  tick as offline contacts. Reachable from the Models list in the sidebar ("Find"), from File > Find Models on this
  Computer, and from the Add a Contact window. It only reads file names locally; nothing is sent anywhere and it works
  without allowing the Hugging Face connection.
* **Resizable sidebar**: drag the line between the conversations column and the chat (or focus it and use the
  Left/Right arrow keys); double-click it to reset. The width is remembered.

## 0.3.3

* **Set up local runtime**: local (offline) models need llama.cpp's `llama-server`. Choose **File > Set Up Local
  Runtime (llama.cpp)...** (or click the "Set up local runtime..." button under the error, or the runtime line in the
  Add a Contact window) to download the CPU build for your system. The app asks first and says who the server is
  (GitHub), what is sent and why; it verifies the checksum when GitHub provides one and unpacks it into
  `<data folder>/bin/`. It is found automatically; nothing else is needed. Declining changes nothing.
* The "needs llama-server" message now points to this.

## 0.3.4

* **Ollama support.** New "Ollama (local, offline)" provider that talks to the Ollama app already on your computer
  (default `http://127.0.0.1:11434`, or `OLLAMA_HOST`). **Find models on this PC** now lists the models Ollama has
  and adds the ones you tick, so they work without llama.cpp. If Ollama is not running, the message says how to start
  it (or that you can use File > Set Up Local Runtime instead; Ollama is optional).
* Ollama's internal model files are no longer offered as raw files; use the Ollama entries instead.
* Clearer errors when an OpenAI-compatible server (for example one pointed at Ollama) can't be reached.

## 0.3.5

* Fixed "No matching build was found on the llama.cpp releases page" in Set Up Local Runtime. The installer now reads
  the public releases feed, takes the newest build that has a file for your system (skipping ones still being
  uploaded), and falls back to a known-good build. The checksum check is optional.

## 0.3.6

* **Reasoning effort in the chat** (like opencode's variants): a **Reasoning** box above every conversation
  (Default / Off / Low / Medium / High / Max), remembered per conversation; **Alt+T** cycles it. It maps to each
  provider's own control: Claude extended-thinking budget (2k / 8k / 16k / 32k tokens), OpenAI-style
  `reasoning_effort` (Max = the highest the model accepts), Ollama `think`. Providers or models without it
  (the demo bot, local .gguf) hide the box. The model's streamed thinking is shown in a collapsible "Thought process".
* **Settings window** (Tools > Settings, Ctrl+, or the Settings link in the sidebar): default model, default
  reasoning effort, thinking display, **custom instructions** for every conversation, **context window** (send only the
  last N messages), **keyboard shortcuts** you can rebind, and appearance.

## 0.3.7
- Conversation window now matches the original MSN 7.5 layout: Send/Search buttons stacked with their original artwork, tidy display-picture frames on the right, msn logo top-right, no stray frame lines or roster label, taller input area.

## 0.3.8
- Toolbar right-hand band (tab curve and msn logo) lowered to line up with the toolbar on the left.

## 0.3.9
- Removed the stray dark line along the top of the conversation toolbar.

## 0.3.10
- Model browser: checkbox row tidied; new filters (minimum size, last updated, minimum downloads, open licences only, hide approval-required); new sorts (recently updated, smallest); list shows likes, updated date and licence; detail panel shows author, parameters, memory needed, licence, strengths, languages, base model, popularity and access.

## 0.3.11
- Model browser: Hugging Face style filters (task, library, app, language, licence, inference provider, trending sort) in a collapsible "More filters" area. Chat window: Send and Search buttons visible again.

## 0.3.12
- Conversation toolbar: removed the earlier 16px offset so the tab band lines up with the toolbar like MSN 7.5.

## 0.3.13
- Conversation window rebuilt to match MSN 7.5 more closely: icon toolbar with drop-down carets, Voice Clip, taller input box with Send and Search, status/ink strip, picture frames with drop-down arrow and side tab.

## 0.3.14
- Toolbar: the tab curve now stretches to the full height of the toolbar panel so the panel flows into it like MSN 7.5 (no hard cut under "Games").

## 0.3.15
- Toolbar: msn strip and tab row edges moved down 7px.

## 0.3.16
- Toolbar tab row: top edge raised to meet the msn strip; right end extended down and out.

## 0.3.17
- New "Align layout" tool (Tools menu, the Align link in the sidebar, or Ctrl+Alt+L): click any block of the window and drag it, nudge it with the arrow keys (Shift = 10px), resize with Alt+arrows or type exact X/Y/W/H values, then Save. Stored only in your profile on this computer.

## 0.3.18
- Align layout: movable/foldable panel; list of every block under the pointer (click a name to select a hidden one); click again or Alt+click to cycle to the block underneath; Layer controls (forward, back, to front, to back).

## 0.3.19
- Align layout: Photoshop-style Layers list. Select a block and every block inside it is listed; click one to select it (then move, resize, re-layer it), use the eye to hide or show it, the arrow to open its contents, and "up one level" to go back. Hidden blocks are saved with the layout. Blocks that share a name are now told apart individually.

## 0.3.20
- Align layout: every artwork piece (the small picture tiles that were not selectable, such as the end cap of the tab row) now has its own name like taskbar.art2, so it can be selected, moved, resized, re-layered and hidden independently.

## 0.3.21
- Align layout: per-block colour controls (opacity, brightness, contrast, saturation, hue shift), saved with the layout, so colour mismatches between toolbar pieces can be matched by eye.

## 0.3.22
- Toolbar: the msn logo now sits at the left end of the strip beside the toolbar panel. Older saved offsets for it are cleared once so they do not stack.

## 0.3.23
- Align layout: "Lock size" and "Lock + scale" for any block. A locked block keeps the exact layout it had when locked, so the pieces inside cannot drift apart when the window is resized or maximised; with "Lock + scale" the whole block scales in proportion with the window. The tool panel can no longer be dragged off screen.

## 0.3.24
- Typing box: the missing toolbar background strip (top border and gradient) is now drawn, the frame sides run continuously down the box, and the stray orange highlight on the pen tab is gone.

## 0.3.25
- Typing box ink tabs: the pen and "A" tab icons no longer sit clipped against the top edge of the bottom strip.

## 0.3.26
- Bottom status bar added to the conversation window (as in the original).
- Update button (sidebar, and Help > Check for Updates): checks your own GitHub repository for a newer release. Asks before connecting, shows exactly what is sent, and verifies the download size and GitHub checksum before installing.
