'use strict';
/*
 * Hugging Face model browser backend. Nothing here runs until the user has said "Allow" in the app,
 * and the only host contacted is Hugging Face (huggingface.co and its download CDN).
 * Sent: the search text / model ids you pick, and - only if you saved one - your Hugging Face token.
 * Never sent: your chats, profile, contacts or anything else.
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const BASE = () => (process.env.AIM_HF_BASE || 'https://huggingface.co').replace(/\/$/, '');
const GB = 1024 ** 3;
const ID_RE = /^[\w.-]+\/[\w.-]+$/;
const FILE_RE = /^(?!.*\.\.)[\w.\-\/]+\.gguf$/i;

const sysInfo = () => ({ ramGB: +(os.totalmem() / GB).toFixed(1), cpus: os.cpus().length, platform: process.platform + '/' + process.arch });
// Rough CPU-inference fit: a 4-bit quant needs ~0.6 GB per billion parameters plus runtime overhead.
const estQ4GB = (b) => (b ? +(b * 0.6 + 0.6).toFixed(1) : null);
const fitsRam = (needGB) => needGB != null && needGB <= (os.totalmem() / GB) * 0.7;

function paramsB(m) {
  const t = (m.gguf && m.gguf.total) || (m.safetensors && m.safetensors.total);
  if (t) return +(t / 1e9).toFixed(2);
  const x = /(?:^|[^\w.])(\d+(?:\.\d+)?)\s*[bB](?![a-zA-Z])/.exec(m.id.split('/')[1] || '');
  return x ? +x[1] : null;
}
const hasOnline = (m) => { const v = m.inferenceProviderMapping; return Array.isArray(v) ? v.length > 0 : !!v && Object.keys(v).length > 0; };

async function hfFetch(url, token, opts = {}) {
  const r = await fetch(url, Object.assign({ headers: Object.assign({ 'User-Agent': 'ai-messenger' }, token ? { Authorization: 'Bearer ' + token } : {}) }, opts));
  if (r.status === 401 || r.status === 403) throw new Error('Hugging Face says this needs a token or accepted licence (gated model). Save a token under "Hugging Face token" and accept the licence on the model page.');
  if (!r.ok) throw new Error('Hugging Face returned ' + r.status);
  return r;
}

function walk(d, rel = '') { let o = []; try { for (const e of fs.readdirSync(path.join(d, rel), { withFileTypes: true })) { const r = rel ? rel + '/' + e.name : e.name; if (e.isDirectory()) o = o.concat(walk(d, r)); else o.push(r); } } catch {} return o; }


// ---------- finding models that are already on this computer (purely local: no network, nothing is sent) ----------
const isGguf = (f) => { try { const fd = fs.openSync(f, 'r'); const b = Buffer.alloc(4); fs.readSync(fd, b, 0, 4, 0); fs.closeSync(fd); return b.toString('latin1') === 'GGUF'; } catch { return false; } };
function scanRoots() {
  const h = os.homedir(); const env = process.env; const j = path.join;
  const r = [j(h, '.cache/huggingface/hub'), j(h, '.cache/lm-studio/models'), j(h, '.lmstudio/models'), j(h, 'models'), j(h, 'Models'), j(h, 'Downloads'), j(h, 'Documents'), j(h, 'Desktop'),
    j(h, 'jan/models'), j(h, '.local/share/nomic.ai/GPT4All'), j(h, '.cache/gpt4all'), j(h, 'llama.cpp/models'), j(h, '.ollama/models/blobs'), '/usr/share/ollama/.ollama/models/blobs', '/var/lib/ollama/models/blobs', j(h, 'Library/Application Support/nomic.ai/GPT4All'), j(h, 'Library/Caches/lm-studio/models')];
  if (env.LOCALAPPDATA) r.push(j(env.LOCALAPPDATA, 'nomic.ai/GPT4All'));
  if (env.HF_HOME) r.push(j(env.HF_HOME, 'hub')); if (env.OLLAMA_MODELS) r.push(env.OLLAMA_MODELS + '/blobs');
  return r;
}
function niceName(f) { // a friendly name and model id from where the file sits
  const parts = f.split(path.sep); const hfc = parts.find((x) => /^models--/.test(x));
  if (hfc) return hfc.replace(/^models--/, '').replace(/--/g, '/');
  const base = path.basename(f).replace(/\.gguf$/i, '');
  if (/^sha256-/.test(base)) return 'ollama-' + base.slice(7, 15);
  return base;
}
function scanModels(roots, deadline) {
  const seen = new Set(); const out = []; out.ollamaBlobs = 0; let visited = 0; const SKIP = new Set(['node_modules', '.git', '.svn', 'proc', 'sys', 'dev']);
  const walkDir = (d, depth, blobs) => {
    if (depth > 6 || visited > 40000 || Date.now() > deadline) return; let ents; try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const e of ents) {
      visited++; const full = path.join(d, e.name);
      if (e.isDirectory()) { if (!SKIP.has(e.name)) walkDir(full, depth + 1, blobs || /blobs$/.test(d + path.sep + e.name) && /ollama/i.test(full)); continue; }
      let st; try { st = fs.statSync(full); } catch { continue; } if (!st.isFile()) continue;
      const named = /\.gguf$/i.test(e.name) && !/^mmproj/i.test(e.name) && st.size > 1e6;
      if (blobs && /^sha256-/.test(e.name) && st.size > 5e7 && isGguf(full)) { out.ollamaBlobs++; continue; } // Ollama's own storage: use Ollama itself for these
      if (!named) continue;
      let real = full; try { real = fs.realpathSync(full); } catch {}
      if (seen.has(real)) continue; seen.add(real); out.push({ path: real, name: niceName(full), size: st.size, dir: path.dirname(real) });
    }
  };
  for (const r of roots) { try { if (fs.statSync(r).isDirectory()) walkDir(r, 0, /ollama/i.test(r) && /blobs$/.test(r)); } catch {} }
  return out.sort((a, b) => b.size - a.size);
}

module.exports = function hfRoutes({ json, body, getConfig, saveConfig, dataDir, providers, localServer }) {
  const modelsDir = () => path.join(dataDir, 'models');
  const hf = () => { const c = getConfig(); c.hf = c.hf || { consent: false, token: '' }; return c.hf; };
  const dl = new Map(); // active downloads

  return async function handle(parts, m, req, res, url) {
    const sub = parts[1];
    if (sub === 'status' && m === 'GET') {
      const h = hf(); const list = fs.existsSync(modelsDir()) ? walk(modelsDir()).filter((f) => /\.gguf$/i.test(f)) : [];
      return json(res, 200, Object.assign({ consent: !!h.consent, hasToken: !!h.token, runtime: localServer(), downloaded: list, base: BASE() }, sysInfo()));
    }
    if (sub === 'consent' && m === 'POST') { const b = await body(req); hf().consent = !!b.allow; saveConfig(); return json(res, 200, { consent: hf().consent }); }
    if (sub === 'token' && m === 'POST') { const b = await body(req); hf().token = String(b.token || '').trim(); saveConfig(); return json(res, 200, { hasToken: !!hf().token }); }
    if (sub === 'scan' && m === 'GET') { // list model files already on this computer
      const extra = (url.searchParams.get('dir') || '').trim(); const roots = [modelsDir(), ...scanRoots()]; if (extra) { if (!path.isAbsolute(extra)) return json(res, 400, { error: 'Type the full path of a folder, for example /home/you/models' }); roots.unshift(extra); }
      const known = new Set(getConfig().contacts.filter((c) => c.provider === 'localgguf' && c.config).map((c) => c.config.file));
      const scanned = scanModels(roots, Date.now() + 10000); const found = scanned.map((f) => Object.assign(f, { added: known.has(f.path) }));
      const ol = { running: false, base: providers.ollama.normBase(), models: [], blobs: scanned.ollamaBlobs };
      try { const have = new Set(getConfig().contacts.filter((c) => c.provider === 'ollama').map((c) => c.model)); ol.models = (await providers.ollama.tags(ol.base)).map((x) => ({ name: x.name, size: x.size || 0, added: have.has(x.name) })); ol.running = true; } catch {}
      return json(res, 200, { found, ollama: ol, roots: roots.filter((r) => { try { return fs.statSync(r).isDirectory(); } catch { return false; } }) });
    }
    if (sub === 'addollama' && m === 'POST') { // add a model that Ollama already has
      const b = await body(req); const name = String(b.name || '').slice(0, 120); if (!name) return json(res, 400, { error: 'No model name' });
      const cfg = getConfig(); let c = cfg.contacts.find((x) => x.provider === 'ollama' && x.model === name);
      if (!c) { c = { id: crypto.randomBytes(6).toString('hex'), name: name.replace(/:latest$/, ''), provider: 'ollama', model: name, system: '', psm: 'Ollama - runs on this computer', group: '', config: { baseUrl: providers.ollama.normBase() } }; cfg.contacts.push(c); saveConfig(); }
      return json(res, 200, { id: c.id, name: c.name });
    }
    if (sub === 'addfile' && m === 'POST') { // add a model file that is already on disk as an offline contact
      const b = await body(req); const file = String(b.file || ''); let st; try { st = fs.statSync(file); } catch { return json(res, 400, { error: 'File not found' }); }
      if (!path.isAbsolute(file) || !st.isFile() || !isGguf(file)) return json(res, 400, { error: 'That is not a GGUF model file' });
      const cfg = getConfig(); let c = cfg.contacts.find((x) => x.provider === 'localgguf' && x.config && x.config.file === file);
      if (!c) { const nm = String(b.name || niceName(file)).slice(0, 80); c = { id: crypto.randomBytes(6).toString('hex'), name: nm.split('/').pop(), provider: 'localgguf', model: nm, system: '', psm: 'Local model - runs on this computer', group: '', config: { file } }; cfg.contacts.push(c); saveConfig(); }
      return json(res, 200, { id: c.id, name: c.name });
    }
    if (!hf().consent) return json(res, 403, { error: 'consent' });

    if (sub === 'search' && m === 'GET') {
      const sp = url.searchParams; const kind = sp.get('kind') || 'all'; const q = (sp.get('q') || '').trim();
      const sortKey = sp.get('sort'); const sort = sortKey === 'likes' ? 'likes' : sortKey === 'new' ? 'createdAt' : sortKey === 'updated' ? 'lastModified' : sortKey === 'trending' ? 'trendingScore' : 'downloads';
      const TASKS = ['text-generation', 'image-text-to-text', 'any-to-any', 'text-to-speech', 'automatic-speech-recognition', 'feature-extraction', 'text-classification', 'translation', 'summarization', 'question-answering']; const task = TASKS.includes(sp.get('task')) ? sp.get('task') : 'text-generation';
      const safe = (v) => /^[A-Za-z0-9_.:\-]{1,60}$/.test(v || '') ? v : ''; const lib = safe(sp.get('lib')), lang = safe(sp.get('lang')), lic = safe(sp.get('lic')), prov = safe(sp.get('prov')), app = safe(sp.get('app'));
      const USE = { coding: ['coder', 'code'], reasoning: ['reasoning', 'r1', 'math'], chat: ['instruct', 'chat'], writing: ['roleplay', 'story', 'creative'], multilingual: ['multilingual', 'translate'] };
      const words = USE[sp.get('use')] || [''];
      const one = async (w) => {
        const p = new URLSearchParams({ pipeline_tag: task, sort, direction: '-1', limit: '30' });
        const term = [q, w].filter(Boolean).join(' '); if (term) p.set('search', term);
        if (kind === 'local') p.append('filter', 'gguf'); else if (kind === 'online') p.set('inference_provider', prov || 'all');
        if (lib && !(kind === 'local' && lib === 'gguf')) p.append('filter', lib); if (lang) p.append('filter', lang); if (lic) p.append('filter', 'license:' + lic); if (app) p.append('filter', app); if (prov && kind !== 'online') p.set('inference_provider', prov);
        for (const e of ['downloads', 'likes', 'gguf', 'safetensors', 'inferenceProviderMapping', 'gated', 'tags', 'lastModified', 'createdAt', 'author', 'library_name']) p.append('expand[]', e);
        return (await (await hfFetch(`${BASE()}/api/models?${p}`, hf().token)).json());
      };
      const seen = new Map(); for (const arr of await Promise.all(words.map(one))) for (const x of arr) { x.id = x.id || x.modelId; if (!seen.has(x.id)) seen.set(x.id, x); }
      let out = [...seen.values()].map((x) => { const b = paramsB(x); const est = estQ4GB(b);
        const tags = Array.isArray(x.tags) ? x.tags : []; const lic = (tags.find((t) => t.startsWith('license:')) || '').slice(8);
        const base = (tags.find((t) => t.startsWith('base_model:') && !/^base_model:(quantized|finetune|adapter|merge)/.test(t)) || '').replace('base_model:', '');
        const langs = tags.filter((t) => /^[a-z]{2}$/.test(t)); const low = (x.id + ' ' + tags.join(' ')).toLowerCase();
        const caps = []; if (/coder|code/.test(low)) caps.push('coding'); if (/reason|r1|thinking|qwq/.test(low)) caps.push('reasoning'); if (/vision|-vl|llava|image-text/.test(low)) caps.push('vision'); if (/tool|function/.test(low)) caps.push('tool use'); if (/uncensored|abliterated|heretic/.test(low)) caps.push('uncensored'); if (/instruct|chat|-it\b/.test(low)) caps.push('chat-tuned'); if (/a\d+b|moe|mixtral/.test(low)) caps.push('mixture-of-experts');
        const ctx = (/(\d+)k\b/i.exec(x.id) || [])[1]; const mod = x.lastModified || x.createdAt || null;
        return { id: x.id, author: x.author || x.id.split('/')[0], downloads: x.downloads || 0, likes: x.likes || 0, paramsB: b, estGB: est, gguf: !!x.gguf || /gguf/i.test(x.id), fits: fitsRam(est), online: hasOnline(x), gated: !!x.gated, license: lic, base, langs: langs.slice(0, 8), caps, ctxK: ctx ? Number(ctx) : null, updated: mod, open: /^(apache-2\.0|mit|bsd|cc0|unlicense|openrail|llama|gemma|qwen)/.test(lic) }; });
      const maxB = Number(sp.get('maxb')) || 0; if (maxB) out = out.filter((x) => x.paramsB != null && x.paramsB <= maxB);
      const minB = Number(sp.get('minb')) || 0; if (minB) out = out.filter((x) => x.paramsB != null && x.paramsB >= minB);
      if (sp.get('open') === '1') out = out.filter((x) => x.open);
      if (sp.get('nogate') === '1') out = out.filter((x) => !x.gated);
      const days = Number(sp.get('days')) || 0; if (days) out = out.filter((x) => x.updated && Date.now() - Date.parse(x.updated) < days * 864e5);
      const minDl = Number(sp.get('mindl')) || 0; if (minDl) out = out.filter((x) => x.downloads >= minDl);
      if (sp.get('fits') === '1') out = out.filter((x) => x.fits !== false && x.gguf);
      if (sortKey === 'biggest') { out = out.filter((x) => x.fits && x.paramsB).sort((a, b) => b.paramsB - a.paramsB || b.downloads - a.downloads); }
      else if (sortKey === 'smallest') out.sort((a, b) => (a.paramsB || 999) - (b.paramsB || 999));
      else if (sortKey === 'updated' || sortKey === 'new') out.sort((a, b) => Date.parse(b.updated || 0) - Date.parse(a.updated || 0));
      else if (sortKey === 'trending') {} // keep Hugging Face's own trending order
      else out.sort((a, b) => (sort === 'likes' ? b.likes - a.likes : b.downloads - a.downloads));
      return json(res, 200, out.slice(0, 60));
    }
    if (sub === 'files' && m === 'GET') {
      const id = url.searchParams.get('id') || ''; if (!ID_RE.test(id)) return json(res, 400, { error: 'bad model id' });
      const r = await hfFetch(`${BASE()}/api/models/${id}/tree/main?recursive=true`, hf().token); const tree = await r.json();
      const files = tree.filter((f) => f.type === 'file' && FILE_RE.test(f.path)).map((f) => { const size = (f.lfs && f.lfs.size) || f.size || 0;
        return { path: f.path, sizeGB: +(size / GB).toFixed(2), split: /-\d+-of-\d+\.gguf$/i.test(f.path), fits: size * 1.15 <= os.totalmem() * 0.8 }; }).sort((a, b) => a.sizeGB - b.sizeGB);
      const quant = (f) => (/(Q\d[\w]*|IQ\d[\w]*|F16|BF16)\.gguf$/i.exec(f.path) || [])[1] || '';
      files.forEach((f) => { f.quant = quant(f); });
      const pick = files.find((f) => !f.split && f.fits && /Q4_K_M/i.test(f.path)) || [...files].reverse().find((f) => !f.split && f.fits);
      if (pick) pick.recommended = true;
      return json(res, 200, files);
    }
    if (sub === 'download' && m === 'POST') {
      const b = await body(req); if (!ID_RE.test(b.id || '') || !FILE_RE.test(b.file || '')) return json(res, 400, { error: 'bad model id or file' });
      const dest = path.join(modelsDir(), b.id.replace('/', '__'), path.basename(b.file));
      fs.mkdirSync(path.dirname(dest), { recursive: true, mode: 0o700 });
      if (dl.has(dest)) return json(res, 409, { error: 'already downloading' });
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store' });
      const send = (o) => res.write('data: ' + JSON.stringify(o) + '\n\n'); const ac = new AbortController(); dl.set(dest, ac); res.on('close', () => ac.abort());
      const part = dest + '.part';
      try {
        const r = await hfFetch(`${BASE()}/${b.id}/resolve/main/${b.file.split('/').map(encodeURIComponent).join('/')}`, hf().token, { signal: ac.signal });
        const total = Number(r.headers.get('content-length')) || 0;
        try { const s = fs.statfsSync(path.dirname(dest)); if (total && s.bavail * s.bsize < total * 1.02) throw new Error('Not enough free disk space for this download.'); } catch (e) { if (/disk space/.test(e.message)) throw e; }
        const out = fs.createWriteStream(part, { mode: 0o600 }); let got = 0, last = 0;
        for await (const chunk of r.body) { if (!out.write(chunk)) await new Promise((ok) => out.once('drain', ok)); got += chunk.length; if (Date.now() - last > 250) { last = Date.now(); send({ got, total }); } }
        await new Promise((ok, bad) => { out.end(ok); out.on('error', bad); });
        if (total && got !== total) throw new Error('Download was cut short; please try again.');
        fs.renameSync(part, dest); send({ got, total: total || got, done: true, file: dest });
      } catch (e) { try { fs.unlinkSync(part); } catch {} if (!ac.signal.aborted) send({ error: e.message }); }
      dl.delete(dest); return res.end();
    }
    if (sub === 'add' && m === 'POST') { // create the contact for a downloaded or online model
      const b = await body(req); if (!ID_RE.test(b.id || '')) return json(res, 400, { error: 'bad model id' });
      const cfg = getConfig(); const short = b.id.split('/')[1]; let c;
      if (b.mode === 'local') {
        const file = path.join(modelsDir(), b.id.replace('/', '__'), path.basename(String(b.file || '')));
        if (!fs.existsSync(file)) return json(res, 400, { error: 'model file not downloaded' });
        c = cfg.contacts.find((x) => x.provider === 'localgguf' && x.config && x.config.file === file);
        if (!c) { c = { id: crypto.randomBytes(6).toString('hex'), name: short, provider: 'localgguf', model: b.id, system: '', psm: 'Local model - runs on this computer', group: '', config: { file } }; cfg.contacts.push(c); }
      } else {
        if (!hf().token) return json(res, 400, { error: 'token' });
        c = cfg.contacts.find((x) => x.provider === 'hfonline' && x.model === b.id);
        if (!c) { c = { id: crypto.randomBytes(6).toString('hex'), name: short, provider: 'hfonline', model: b.id, system: '', psm: 'Hugging Face - online', group: '', config: { apiKey: hf().token } }; cfg.contacts.push(c); }
      }
      saveConfig(); return json(res, 200, { id: c.id, name: c.name });
    }
    if (sub === 'model' && m === 'DELETE') { // remove a downloaded file
      const f = url.searchParams.get('file') || ''; const full = path.normalize(path.join(modelsDir(), f));
      if (!full.startsWith(modelsDir() + path.sep) || !/\.gguf$/i.test(full)) return json(res, 400, { error: 'bad file' });
      try { fs.unlinkSync(full); } catch {} return json(res, 200, { ok: true });
    }
    return json(res, 404, { error: 'unknown hf route' });
  };
};
