#!/usr/bin/env node
'use strict';
/*
 * AI Messenger - local backend. Zero dependencies (Node >= 18).
 * Serves the UI on 127.0.0.1 only, stores data locally, and talks only to the
 * AI endpoints that YOU configure for a contact. No telemetry, no third parties.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { spawn } = require('child_process');

const APP = 'ai-messenger';
const UI_DIR = path.join(__dirname, 'ui');
const args = process.argv.slice(2);
const flag = (n) => args.includes(n);
const opt = (n, d) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : d; };

// ---------- data directory (per-OS) ----------
function dataDir() {
  if (process.env.AI_MESSENGER_HOME) return process.env.AI_MESSENGER_HOME;
  if (process.platform === 'win32') return path.join(process.env.APPDATA || os.homedir(), 'AI Messenger');
  if (process.platform === 'darwin') return path.join(os.homedir(), 'Library', 'Application Support', 'AI Messenger');
  return path.join(process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config'), APP);
}
const DATA = dataDir();
const PLUGINS = path.join(DATA, 'plugins');
const PROFILES_FILE = path.join(DATA, 'profiles.json');
const PROFILES_DIR = path.join(DATA, 'profiles');
for (const d of [DATA, PLUGINS, PROFILES_DIR]) fs.mkdirSync(d, { recursive: true, mode: 0o700 });

const DEFAULT_SETTINGS = { sounds: true, soundOnReply: true, timestamps: false, enterSends: true, hue: 0, pictures: 'large', sortBy: 'status',
  labelBy: 'name', fontPx: 13, fontFamily: '', fontColor: '', bold: false, italic: false, readAloud: false, background: '', showStd: true, showFmt: true,
  defaultContact: '', defaultEffort: '', showReasoning: 'collapsed', instructions: '', contextMessages: 0, keybinds: {} };
const DEFAULT_CONFIG = {
  profile: { name: 'You', psm: '', status: 'Online' },
  groups: [],
  settings: DEFAULT_SETTINGS,
  contacts: [
    { id: 'demo', name: 'Demo Bot', provider: 'echo', model: 'echo', system: '', psm: 'Works without any API key', group: '', config: {} },
  ],
};
const jread = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
function jwrite(f, o) { const tmp = f + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(o, null, 2), { mode: 0o600 }); fs.renameSync(tmp, f); }

const safeId = (id) => String(id).replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 64);
let profiles = jread(PROFILES_FILE, null);
if (!profiles) {
  profiles = { profiles: [], auto: null, last: null };
  const old = path.join(DATA, 'config.json'); // migrate a v0.1 single-profile install
  const id = 'default'; const pd = path.join(PROFILES_DIR, id); fs.mkdirSync(pd, { recursive: true, mode: 0o700 });
  let name = 'Default';
  if (fs.existsSync(old)) {
    try { name = (jread(old, {}).profile || {}).name || name; fs.renameSync(old, path.join(pd, 'config.json')); } catch {}
    try { fs.renameSync(path.join(DATA, 'history'), path.join(pd, 'history')); } catch {}
  }
  profiles.profiles.push({ id, name, created: Date.now() }); profiles.auto = id; jwrite(PROFILES_FILE, profiles);
}
const saveProfiles = () => jwrite(PROFILES_FILE, profiles);

// ---- current session (one signed-in profile at a time) ----
let cur = null, config = null, PD = null;
const pf = (...p) => path.join(PD, ...p);
const histFile = (id) => path.join(pf('history'), safeId(id) + '.json');
function signIn(id) {
  cur = id; PD = path.join(PROFILES_DIR, id);
  for (const d of [PD, pf('history'), pf('received')]) fs.mkdirSync(d, { recursive: true, mode: 0o700 });
  const c = jread(pf('config.json'), null) || JSON.parse(JSON.stringify(DEFAULT_CONFIG));
  c.settings = Object.assign({}, DEFAULT_SETTINGS, c.settings || {}); c.groups = c.groups || []; c.profile = Object.assign({ name: 'You', psm: '', status: 'Online' }, c.profile || {});
  for (const x of c.contacts || []) if (x.id === 'demo' && x.name === 'Demo Bot (offline)') x.name = 'Demo Bot'; // presence now shows offline status
  c.chats = c.chats || []; c.projects = c.projects || [];
  if (!c.chatsMigrated) { // 0.3.x histories were one per contact: each becomes a conversation (same id, same file)
    for (const x of c.contacts || []) {
      const h = jread(histFile(x.id), []); if (!h.length) continue; const last = h[h.length - 1];
      c.chats.push({ id: safeId(x.id), title: titleFrom((h.find((m) => m.role === 'user') || {}).text) || x.name, participants: [x.id], pinned: false, project: '', created: h[0].t || Date.now(), updated: last.t || Date.now(), preview: String(last.text || '').slice(0, 120) });
    }
    c.chatsMigrated = true;
  }
  config = c; saveConfig(); profiles.last = id; saveProfiles();
}
function signOut() { cur = null; config = null; PD = null; }
const titleFrom = (t) => String(t || '').replace(/`+\w*/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 48);
const saveConfig = () => jwrite(pf('config.json'), config);
const loadAssets = () => jread(pf('assets.json'), { emoticons: [], backgrounds: [], avatar: '' });
const hashPw = (pw, salt) => crypto.scryptSync(String(pw), salt, 32).toString('hex');

// ---------- provider plugins ----------
process.env.AIM_DATA = DATA;
const providers = {};
function loadProviders(dir) {
  if (!fs.existsSync(dir)) return;
  for (const f of fs.readdirSync(dir)) {
    if (!f.endsWith('.js')) continue;
    try {
      const p = require(path.join(dir, f));
      if (p && p.id && typeof p.chat === 'function') providers[p.id] = p;
    } catch (e) { console.error('plugin failed:', f, e.message); }
  }
}
loadProviders(path.join(__dirname, 'providers'));
loadProviders(PLUGINS); // user plugins override built-ins

const SECRET = '********';
function publicContact(c) {
  const p = providers[c.provider];
  const cfg = Object.assign({}, c.config || {});
  for (const f of (p && p.fields) || []) if (f.secret && cfg[f.key]) cfg[f.key] = SECRET;
  return Object.assign({}, c, { config: cfg, presence: p && p.local ? 'offline' : 'online' });
}
const ORDER = ['openai', 'anthropic', 'hfonline', 'ollama', 'localgguf', 'echo'];
const publicProviders = () => Object.values(providers).sort((a, b) => (ORDER.indexOf(a.id) + 1 || 99) - (ORDER.indexOf(b.id) + 1 || 99) || a.name.localeCompare(b.name)).map((p) => ({ id: p.id, name: p.name, fields: p.fields || [], models: p.models || [], local: !!p.local, efforts: p.efforts || [] }));

// ---------- history ----------
function loadHist(id) { return jread(histFile(id), []); }
function saveHist(id, h) { fs.writeFileSync(histFile(id), JSON.stringify(h), { mode: 0o600 }); }
function addAlert(a) { const f = pf('alerts.json'); const l = jread(f, []); l.unshift(Object.assign({ t: Date.now() }, a)); jwrite(f, l.slice(0, 300)); }

// ---------- http helpers ----------
const TOKEN = crypto.randomBytes(24).toString('hex');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css', '.json': 'application/json',
  '.png': 'image/png', '.gif': 'image/gif', '.jpg': 'image/jpeg', '.bmp': 'image/bmp', '.ico': 'image/x-icon', '.uif': 'text/plain; charset=utf-8', '.svg': 'image/svg+xml' };
const json = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); };
function body(req, limit = 40e6) {
  return new Promise((resolve, reject) => {
    let n = 0; const chunks = [];
    req.on('data', (c) => { n += c.length; if (n > limit) { reject(new Error('too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString()) : {}); } catch (e) { reject(e); } });
    req.on('error', reject);
  });
}

const hfHandle = require('./hf')({ json, body, getConfig: () => config, saveConfig: () => saveConfig(), dataDir: DATA, providers, localServer: () => providers.localgguf.findServer() });
const runtimeHandle = require('./runtime')({ json, body, dataDir: DATA, localServer: () => providers.localgguf.findServer() });
const updateHandle = require('./update')({ json, body, dataDir: DATA });
let lastPing = 0;
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    const host = (req.headers.host || '').split(':')[0];
    if (host !== '127.0.0.1' && host !== 'localhost') { res.writeHead(403); return res.end(); } // anti DNS-rebinding

    if (url.pathname.startsWith('/api/')) {
      if (req.headers['x-token'] !== TOKEN) return json(res, 401, { error: 'unauthorized' });
      return await api(req, res, url);
    }
    // static
    let p = decodeURIComponent(url.pathname);
    if (p === '/') p = '/index.html';
    const file = path.normalize(path.join(UI_DIR, p));
    if (!file.startsWith(UI_DIR + path.sep)) { res.writeHead(403); return res.end(); }
    fs.readFile(file, (err, data) => {
      if (err) { res.writeHead(404); return res.end('not found'); }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
      res.end(data);
    });
  } catch (e) { if (!res.headersSent) json(res, 500, { error: e.message }); else res.end(); }
});

const MAX_ASSET = 6e6;
function sessionInfo() {
  return { signedIn: !!cur, current: cur, auto: profiles.auto, last: profiles.last,
    profiles: profiles.profiles.map((p) => ({ id: p.id, name: p.name, locked: !!p.pw })) };
}
const NEED_SESSION = new Set(['state', 'profile', 'contacts', 'history', 'models', 'chat', 'settings', 'groups', 'overview', 'search', 'received', 'alerts', 'assets', 'password', 'hf', 'chats', 'projects']);

async function api(req, res, url) {
  const parts = url.pathname.split('/').filter(Boolean).slice(1); // after 'api'
  const m = req.method; const r0 = parts[0];
  if (r0 === 'ui') { // app-wide look (not per profile): which MSN version theme is active
    const f = path.join(DATA, 'ui.json'); const cur0 = jread(f, {});
    if (m === 'PUT') { const b = await body(req); if (typeof b.theme === 'string' && /^[a-z0-9]{3,12}$/.test(b.theme)) cur0.theme = b.theme; if (typeof b.native === 'boolean') cur0.native = b.native; jwrite(f, cur0); }
    return json(res, 200, cur0);
  }
  if (r0 === 'ping') { lastPing = Date.now(); return json(res, 200, { ok: true }); }

  // ----- sessions / local "accounts" (replaces the MSN sign-in) -----
  if (r0 === 'session' && m === 'GET') return json(res, 200, sessionInfo());
  if (r0 === 'signin' && m === 'POST') {
    const b = await body(req); const p = profiles.profiles.find((x) => x.id === b.id);
    if (!p) return json(res, 404, { error: 'No such profile' });
    if (p.pw && hashPw(b.password || '', p.pw.salt) !== p.pw.hash) return json(res, 403, { error: 'Wrong password' });
    signIn(p.id); if (b.makeDefault !== undefined) { profiles.auto = b.makeDefault ? p.id : (profiles.auto === p.id ? null : profiles.auto); saveProfiles(); }
    return json(res, 200, sessionInfo());
  }
  if (r0 === 'signout' && m === 'POST') { signOut(); if (profiles.auto) { profiles.auto = null; saveProfiles(); } return json(res, 200, sessionInfo()); }
  if (r0 === 'profiles' && m === 'POST') {
    const b = await body(req); const name = String(b.name || '').trim().slice(0, 60);
    if (!name) return json(res, 400, { error: 'Name required' });
    let id = safeId(name.toLowerCase()) || 'profile'; while (profiles.profiles.some((p) => p.id === id)) id += '_';
    const p = { id, name, created: Date.now() };
    if (b.password) { const salt = crypto.randomBytes(16).toString('hex'); p.pw = { salt, hash: hashPw(b.password, salt) }; }
    profiles.profiles.push(p); saveProfiles();
    const was = cur; signIn(id); config.profile.name = name; saveConfig(); if (!b.signIn) { if (was) signIn(was); else signOut(); }
    return json(res, 200, sessionInfo());
  }
  if (r0 === 'profiles' && m === 'DELETE' && parts[1]) {
    const id = safeId(parts[1]); profiles.profiles = profiles.profiles.filter((p) => p.id !== id);
    if (profiles.auto === id) profiles.auto = null; saveProfiles();
    try { fs.rmSync(path.join(PROFILES_DIR, id), { recursive: true, force: true }); } catch {}
    if (cur === id) signOut(); return json(res, 200, sessionInfo());
  }
  if (r0 === 'runtime') return runtimeHandle(parts, m, req, res);
  if (r0 === 'update') return updateHandle(parts, m, req, res);
  if (r0 === 'hf' && cur) return hfHandle(parts, m, req, res, url);
  if (NEED_SESSION.has(r0) && !cur) return json(res, 409, { error: 'not signed in' });

  if (r0 === 'state' && m === 'GET') return json(res, 200, { profile: config.profile, groups: config.groups, settings: config.settings, contacts: config.contacts.map(publicContact), chats: config.chats, projects: config.projects, providers: publicProviders(), dataDir: DATA, profileId: cur, assets: loadAssets() });
  if (r0 === 'profile' && m === 'PUT') {
    const b = await body(req); config.profile = Object.assign(config.profile, b); saveConfig();
    if (b.name) { const p = profiles.profiles.find((x) => x.id === cur); if (p) { p.name = b.name; saveProfiles(); } }
    return json(res, 200, config.profile);
  }
  if (r0 === 'password' && m === 'PUT') {
    const b = await body(req); const p = profiles.profiles.find((x) => x.id === cur);
    if (p.pw && hashPw(b.old || '', p.pw.salt) !== p.pw.hash) return json(res, 403, { error: 'Current password is wrong' });
    if (b.password) { const salt = crypto.randomBytes(16).toString('hex'); p.pw = { salt, hash: hashPw(b.password, salt) }; } else delete p.pw;
    saveProfiles(); return json(res, 200, { locked: !!p.pw });
  }
  if (r0 === 'settings' && m === 'PUT') { config.settings = Object.assign(config.settings, await body(req)); saveConfig(); return json(res, 200, config.settings); }
  if (r0 === 'assets' && m === 'PUT') { const b = await body(req, MAX_ASSET * 2); jwrite(pf('assets.json'), { emoticons: b.emoticons || [], backgrounds: b.backgrounds || [], avatar: b.avatar || '' }); return json(res, 200, { ok: true }); }

  if (r0 === 'groups' && m === 'POST') { // {op:'create'|'rename'|'delete', name, to}
    const b = await body(req); const n = String(b.name || '').trim();
    if (b.op === 'create' && n && !config.groups.includes(n)) config.groups.push(n);
    if (b.op === 'rename' && config.groups.includes(n) && b.to && !config.groups.includes(b.to)) { config.groups[config.groups.indexOf(n)] = b.to; config.contacts.forEach((c) => { if (c.group === n) c.group = b.to; }); }
    if (b.op === 'delete') { config.groups = config.groups.filter((g) => g !== n); config.contacts.forEach((c) => { if (c.group === n) c.group = ''; }); }
    saveConfig(); return json(res, 200, { groups: config.groups, contacts: config.contacts.map(publicContact) });
  }

  if (r0 === 'contacts') {
    if (m === 'POST') { // create or update
      const c = await body(req);
      if (!c.name || !providers[c.provider]) return json(res, 400, { error: 'name and valid provider required' });
      c.id = c.id ? safeId(c.id) : crypto.randomBytes(6).toString('hex');
      const old = config.contacts.find((x) => x.id === c.id);
      c.config = c.config || {};
      for (const f of providers[c.provider].fields || []) // keep stored secret when UI sends mask
        if (f.secret && c.config[f.key] === SECRET) c.config[f.key] = old && old.config ? old.config[f.key] : '';
      if (c.group && !config.groups.includes(c.group)) config.groups.push(c.group);
      if (old) Object.assign(old, c); else config.contacts.push(c);
      saveConfig();
      return json(res, 200, publicContact(old || c));
    }
    if (m === 'DELETE' && parts[1]) {
      config.contacts = config.contacts.filter((x) => x.id !== parts[1]);
      for (const ch of config.chats) ch.participants = ch.participants.filter((x) => x !== parts[1]);
      for (const ch of config.chats.filter((x) => !x.participants.length)) { try { fs.unlinkSync(histFile(ch.id)); } catch {} }
      config.chats = config.chats.filter((x) => x.participants.length);
      saveConfig();
      return json(res, 200, { ok: true });
    }
  }
  if (r0 === 'chats') {
    const known = (l) => (Array.isArray(l) ? l : []).filter((x) => config.contacts.some((c) => c.id === x));
    if (m === 'GET' && !parts[1]) return json(res, 200, config.chats);
    if (m === 'POST') {
      const b = await body(req); const ps = known(b.participants); if (!ps.length) return json(res, 400, { error: 'Pick a contact first' });
      const ch = { id: 'c_' + crypto.randomBytes(6).toString('hex'), title: 'New conversation', participants: ps, pinned: false, project: config.projects.some((p) => p.id === b.project) ? b.project : '', created: Date.now(), updated: Date.now(), preview: '' };
      config.chats.push(ch); saveConfig(); return json(res, 200, ch);
    }
    const ch = config.chats.find((x) => x.id === parts[1]); if (!ch) return json(res, 404, { error: 'No such conversation' });
    if (m === 'PUT') {
      const b = await body(req);
      if (typeof b.title === 'string' && b.title.trim()) ch.title = b.title.trim().slice(0, 120);
      if (typeof b.pinned === 'boolean') ch.pinned = b.pinned;
      if (typeof b.project === 'string') ch.project = config.projects.some((p) => p.id === b.project) ? b.project : '';
      if (Array.isArray(b.participants)) { const ps = known(b.participants); if (ps.length) ch.participants = ps; }
      saveConfig(); return json(res, 200, ch);
    }
    if (m === 'DELETE') { config.chats = config.chats.filter((x) => x !== ch); try { fs.unlinkSync(histFile(ch.id)); } catch {} saveConfig(); return json(res, 200, { ok: true }); }
  }
  if (r0 === 'projects') {
    if (m === 'GET' && !parts[1]) return json(res, 200, config.projects);
    if (m === 'POST') {
      const b = await body(req); const name = String(b.name || '').trim().slice(0, 80); if (!name) return json(res, 400, { error: 'Name required' });
      const p = { id: 'p_' + crypto.randomBytes(6).toString('hex'), name, instructions: String(b.instructions || '').slice(0, 20000), pinned: false, created: Date.now() };
      config.projects.push(p); saveConfig(); return json(res, 200, p);
    }
    const p = config.projects.find((x) => x.id === parts[1]); if (!p) return json(res, 404, { error: 'No such project' });
    if (m === 'PUT') {
      const b = await body(req);
      if (typeof b.name === 'string' && b.name.trim()) p.name = b.name.trim().slice(0, 80);
      if (typeof b.instructions === 'string') p.instructions = b.instructions.slice(0, 20000);
      if (typeof b.pinned === 'boolean') p.pinned = b.pinned;
      saveConfig(); return json(res, 200, p);
    }
    if (m === 'DELETE') { config.projects = config.projects.filter((x) => x !== p); for (const c of config.chats) if (c.project === p.id) c.project = ''; saveConfig(); return json(res, 200, { ok: true }); }
  }
  if (r0 === 'history' && parts[1]) {
    if (m === 'GET') return json(res, 200, loadHist(parts[1]));
    if (m === 'DELETE') { saveHist(parts[1], []); const ch = config.chats.find((x) => x.id === parts[1]); if (ch) { ch.preview = ''; saveConfig(); } return json(res, 200, { ok: true }); }
    if (m === 'PUT') { const b = await body(req); const h = loadHist(parts[1]); if (b.remove != null) h.splice(Number(b.remove), 1); saveHist(parts[1], h); return json(res, 200, h); }
  }
  if (r0 === 'overview' && m === 'GET') { // inbox-style summary of every conversation
    return json(res, 200, config.chats.map((c) => {
      const h = loadHist(c.id); const last = h[h.length - 1];
      const undelivered = h.length && last.role === 'user' ? h.filter((x, i) => x.role === 'user' && (!h[i + 1] || h[i + 1].role === 'user')).length : 0;
      return { id: c.id, name: c.title, count: h.length, last: last ? { role: last.role, text: String(last.text).slice(0, 200), t: last.t } : null, undelivered, firstUndelivered: undelivered ? (h.findLast((x, i) => x.role === 'user' && (!h[i + 1] || h[i + 1].role === 'user')) || {}).text : '' };
    }));
  }
  if (r0 === 'search' && m === 'GET') {
    const q = (url.searchParams.get('q') || '').toLowerCase(); const only = url.searchParams.get('contact');
    const out = [];
    if (q) for (const c of config.chats) {
      if (only && c.id !== only) continue;
      loadHist(c.id).forEach((x, i) => { const t = String(x.text); const k = t.toLowerCase().indexOf(q); if (k >= 0) out.push({ id: c.id, name: c.title, i, role: x.role, t: x.t, snippet: t.slice(Math.max(0, k - 40), k + 100) }); });
    }
    return json(res, 200, out.sort((a, b) => b.t - a.t).slice(0, 200));
  }
  if (r0 === 'alerts') { const f = pf('alerts.json'); if (m === 'GET') return json(res, 200, jread(f, [])); if (m === 'POST') { addAlert(await body(req)); return json(res, 200, { ok: true }); } if (m === 'DELETE') { jwrite(f, []); return json(res, 200, { ok: true }); } }
  if (r0 === 'received') {
    const dir = pf('received');
    if (m === 'GET' && !parts[1]) return json(res, 200, fs.readdirSync(dir).map((n) => { const st = fs.statSync(path.join(dir, n)); return { name: n, size: st.size, t: st.mtimeMs }; }).sort((a, b) => b.t - a.t));
    if (m === 'GET' && parts[1]) { const f = path.join(dir, path.basename(decodeURIComponent(parts[1]))); if (!fs.existsSync(f)) return json(res, 404, { error: 'not found' }); res.writeHead(200, { 'Content-Type': 'application/octet-stream' }); return res.end(fs.readFileSync(f)); }
    if (m === 'POST') {
      const b = await body(req); let name = path.basename(String(b.name || 'file')).replace(/[^\w.\- ()]/g, '_').slice(0, 120) || 'file';
      const ext = path.extname(name), stem = name.slice(0, name.length - ext.length); let f = path.join(dir, name), n = 1;
      while (fs.existsSync(f)) f = path.join(dir, `${stem} (${n++})${ext}`);
      const data = b.dataUrl ? Buffer.from(String(b.dataUrl).split(',')[1] || '', 'base64') : Buffer.from(String(b.text || ''), 'utf8');
      fs.writeFileSync(f, data, { mode: 0o600 }); return json(res, 200, { name: path.basename(f) });
    }
    if (m === 'DELETE' && parts[1]) { try { fs.unlinkSync(path.join(dir, path.basename(decodeURIComponent(parts[1])))); } catch {} return json(res, 200, { ok: true }); }
  }
  if (r0 === 'models' && m === 'POST') {
    const b = await body(req); const p = providers[b.provider];
    const old = config.contacts.find((x) => x.id === b.id);
    const cfg = Object.assign({}, b.config || {});
    for (const f of (p && p.fields) || []) if (f.secret && cfg[f.key] === SECRET) cfg[f.key] = old && old.config ? old.config[f.key] : '';
    if (!p || !p.listModels) return json(res, 200, { models: (p && p.models) || [] });
    try { return json(res, 200, { models: await p.listModels(cfg) }); } catch (e) { return json(res, 200, { models: p.models || [], error: e.message }); }
  }
  if (r0 === 'chat' && parts[1] && m === 'POST') return chat(req, res, parts[1]);
  json(res, 404, { error: 'not found' });
}

// Build the message list one participant sees. In a multi-AI conversation, other contacts' replies are shown to
// this one as "[Name]: ..." user turns, and consecutive same-role turns are merged (some APIs require alternation).
function viewFor(hist, me, byId) {
  const out = [];
  for (const m of hist) {
    let role, text, att;
    if (m.role === 'user') { role = 'user'; text = m.text; att = m.attachments || []; }
    else if (!m.from || m.from === me.id) { role = 'assistant'; text = m.text; att = []; }
    else { role = 'user'; text = `[${(byId[m.from] || { name: 'Someone' }).name}]: ${m.text}`; att = []; }
    const prev = out[out.length - 1];
    if (prev && prev.role === role) { prev.text += '\n\n' + text; prev.attachments = (prev.attachments || []).concat(att); }
    else out.push({ role, text, attachments: att });
  }
  return out;
}

async function chat(req, res, id) {
  const b = await body(req);
  const chat = config.chats.find((x) => x.id === id);
  if (!chat) return json(res, 404, { error: 'unknown conversation' });
  const byId = Object.fromEntries(config.contacts.map((x) => [x.id, x]));
  const ids = chat.participants.filter((x) => byId[x]);
  if (!ids.length) return json(res, 400, { error: 'This conversation has no contact. Pick a model first.' });
  const proj = config.projects.find((p) => p.id === chat.project); const S = config.settings || {};
  const projSys = (S.instructions ? String(S.instructions).slice(0, 20000) + '\n\n' : '') + (proj && proj.instructions ? proj.instructions + '\n\n' : '');
  const EFF = ['', 'off', 'low', 'medium', 'high', 'max']; const effort = EFF.includes(b.effort) ? b.effort : EFF.includes(chat.effort) ? chat.effort : EFF.includes(S.defaultEffort) ? S.defaultEffort : '';
  if (b.effort !== undefined && EFF.includes(b.effort)) chat.effort = b.effort;
  const ctxN = Math.max(0, Math.min(Number(S.contextMessages) || 0, 1000));
  const windowed = (h) => { if (!ctxN || h.length <= ctxN) return h; let w = h.slice(-ctxN); while (w.length && w[0].role !== 'user') w.shift(); return w.length ? w : h.slice(-1); };
  const blocked = ids.filter((x) => byId[x].blocked);
  if (blocked.length === ids.length) return json(res, 403, { error: `${byId[blocked[0]].name} is blocked. Unblock the contact in its properties.` });
  const hist = loadHist(id);
  if (b.regenerate) { while (hist.length && hist[hist.length - 1].role === 'assistant') hist.pop(); }
  else {
    hist.push({ role: 'user', text: String(b.text || ''), attachments: b.attachments || [], t: Date.now(), ...(b.sticker ? { sticker: String(b.sticker).replace(/\W/g, '') } : {}) });
    if (!chat.title || chat.title === 'New conversation') chat.title = titleFrom(b.text) || 'New conversation';
  }
  chat.updated = Date.now(); saveConfig();

  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
  const send = (o) => res.write('data: ' + JSON.stringify(o) + '\n\n');
  const ac = new AbortController();
  res.on('close', () => ac.abort());
  let failed = false;
  for (const pid of ids) {
    const pc = byId[pid]; if (pc.blocked || ac.signal.aborted) continue;
    const p = providers[pc.provider]; let out = '';
    send({ start: pid });
    try {
      if (!p) throw new Error('provider plug-in missing: ' + pc.provider);
      const group = ids.length > 1 ? `\n\nYou are "${pc.name}" in a group chat with the user and ${ids.filter((x) => x !== pid).map((x) => '"' + byId[x].name + '"').join(', ')}. Other participants' messages appear as "[Name]: text". Reply only as yourself, without a name prefix.` : '';
      let think = '';
      for await (const delta of p.chat({ messages: viewFor(windowed(hist), pc, byId), model: pc.model, system: projSys + (pc.system || '') + group, config: pc.config || {}, signal: ac.signal, effort: p.efforts && p.efforts.length ? effort : '' })) { if (delta && typeof delta === 'object') { if (delta.reasoning) { think += delta.reasoning; send({ reasoning: delta.reasoning, from: pid }); } continue; } out += delta; send({ delta, from: pid }); }
      hist.push({ role: 'assistant', from: pid, text: out, ...(think ? { reasoning: think } : {}), t: Date.now() });
      send({ end: pid });
    } catch (e) {
      if (out) hist.push({ role: 'assistant', from: pid, text: out, t: Date.now() });
      failed = true;
      if (!ac.signal.aborted) { send({ error: e.message || String(e), from: pid }); addAlert({ kind: 'error', contact: pc.name, text: e.message || String(e) }); }
    }
  }
  saveHist(id, hist);
  { const last = hist[hist.length - 1]; chat.updated = Date.now(); chat.preview = last ? String(last.text || '').slice(0, 120) : ''; saveConfig(); }
  if (!ac.signal.aborted) { if (!failed) addAlert({ kind: 'reply', contact: byId[ids[0]].name, text: 'New message received' }); send({ done: true }); }
  res.end();
}

// ---------- launching an app-style window ----------
function findBrowser() {
  const win = ['PROGRAMFILES', 'PROGRAMFILES(X86)', 'LOCALAPPDATA'].map((k) => process.env[k]).filter(Boolean);
  const cands = process.platform === 'win32'
    ? win.flatMap((r) => [r + '\\Microsoft\\Edge\\Application\\msedge.exe', r + '\\Google\\Chrome\\Application\\chrome.exe', r + '\\BraveSoftware\\Brave-Browser\\Application\\brave.exe'])
    : process.platform === 'darwin'
      ? ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge', '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser', '/Applications/Chromium.app/Contents/MacOS/Chromium']
      : ['google-chrome-stable', 'google-chrome', 'chromium', 'chromium-browser', 'microsoft-edge', 'brave-browser'].flatMap((n) => (process.env.PATH || '').split(':').map((d) => path.join(d, n)));
  return cands.find((f) => { try { fs.accessSync(f, fs.constants.X_OK); return true; } catch { return false; } });
}
function openWindow(url) {
  const b = process.env.AI_MESSENGER_BROWSER || findBrowser();
  if (b) {
    const prof = path.join(DATA, 'browser-profile');
    const a = ['--app=' + url, '--user-data-dir=' + prof, '--no-first-run', '--no-default-browser-check', '--window-size=1100,720'];
    if (process.getuid && process.getuid() === 0) a.push('--no-sandbox');
    spawn(b, a, { stdio: 'ignore', detached: true }).unref();
    return;
  }
  const opener = process.platform === 'win32' ? ['cmd', ['/c', 'start', '', url]] : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
  spawn(opener[0], opener[1], { stdio: 'ignore', detached: true }).unref();
  console.log('No Chromium-based browser found; opened default browser. Open this if nothing appears:\n' + url);
}

const port = Number(opt('--port', process.env.AI_MESSENGER_PORT || 0));
server.listen(port, '127.0.0.1', () => {
  const url = `http://127.0.0.1:${server.address().port}/?t=${TOKEN}`;
  console.log('AI Messenger running at ' + url);
  console.log('Data: ' + DATA);
  if (!flag('--no-open')) openWindow(url);
  if (!flag('--keep-alive')) { // quit when all windows are closed
    setInterval(() => { if (lastPing && Date.now() - lastPing > 20000) process.exit(0); }, 5000).unref();
    setTimeout(() => { if (!lastPing) process.exit(0); }, 120000).unref();
  }
});
module.exports = { server };
