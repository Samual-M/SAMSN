/* Update check against the user's own GitHub repository.
 * Nothing connects until the user has pressed Allow in the update window.
 * Sent to GitHub: only the repository name the user typed and a generic client name. No chats, contacts, profile or name. */
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');

const VERSION = '0.3.26';
const REPO_RE = /^[A-Za-z0-9_.-]{1,39}\/[A-Za-z0-9_.-]{1,100}$/;
const UA = 'AI-Messenger-Update-Check';

const parseV = (v) => String(v || '').replace(/^[^0-9]*/, '').split(/[.\-+]/).map((x) => parseInt(x, 10) || 0);
const newer = (a, b) => { const x = parseV(a), y = parseV(b); for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d > 0; } return false; };

module.exports = function updateRoutes({ json, body, dataDir }) {
  const file = path.join(dataDir, 'update.json');
  const load = () => { try { return Object.assign({ consent: false, repo: '' }, JSON.parse(fs.readFileSync(file, 'utf8'))); } catch { return { consent: false, repo: '' }; } };
  const save = (o) => { fs.mkdirSync(dataDir, { recursive: true }); fs.writeFileSync(file, JSON.stringify(o)); };
  const platformPick = () => process.platform === 'darwin' ? /(macos.*\.(zip|dmg|pkg)|\.dmg)$/i : process.platform === 'win32' ? /\.(exe|msi)$/i : /\.deb$/i;

  async function latest(repo) {
    const r = await fetch(`https://api.github.com/repos/${repo}/releases/latest`, { headers: { Accept: 'application/vnd.github+json', 'User-Agent': UA } }).catch(() => { throw new Error('Could not reach GitHub. Check your internet connection and try again.'); });
    if (r.status === 404) throw new Error('No release found in ' + repo + '. Publish a GitHub release and attach the .deb (and the macOS zip) to it.');
    if (!r.ok) throw new Error('GitHub answered ' + r.status);
    const j = await r.json(); const pick = platformPick();
    const a = (j.assets || []).find((x) => pick.test(x.name || ''));
    return { tag: j.tag_name || '', name: j.name || j.tag_name || '', page: j.html_url || '', notes: String(j.body || '').slice(0, 1500), asset: a ? { name: a.name, size: a.size, url: a.browser_download_url, digest: a.digest || '' } : null };
  }

  return async function handle(parts, m, req, res) {
    const sub = parts[1]; const c = load();
    if (sub === 'status' && m === 'GET') return json(res, 200, { consent: c.consent, repo: c.repo, version: VERSION, platform: process.platform });
    if (sub === 'config' && m === 'POST') {
      const b = await body(req);
      if (b.repo !== undefined) { const r = String(b.repo).trim().replace(/^https?:\/\/github\.com\//i, '').replace(/\.git$/i, '').replace(/\/+$/, ''); if (r && !REPO_RE.test(r)) return json(res, 400, { error: 'Type the repository as owner/name, for example yourname/ai-messenger' }); c.repo = r; }
      if (b.consent !== undefined) c.consent = !!b.consent;
      save(c); return json(res, 200, { consent: c.consent, repo: c.repo });
    }
    if (!c.consent) return json(res, 403, { error: 'consent' });
    if (!c.repo) return json(res, 400, { error: 'Type your GitHub repository first (owner/name).' });

    if (sub === 'check' && m === 'GET') {
      try { const l = await latest(c.repo); return json(res, 200, Object.assign({ current: VERSION, newer: newer(l.tag, VERSION) }, l)); }
      catch (e) { return json(res, 502, { error: e.message }); }
    }
    if (sub === 'install' && m === 'POST') {
      let l; try { l = await latest(c.repo); } catch (e) { return json(res, 502, { error: e.message }); }
      if (!l.asset) return json(res, 404, { error: 'The latest release has no file for this computer.' });
      if (!newer(l.tag, VERSION)) return json(res, 409, { error: 'You already have the newest version.' });
      if (!l.asset.url.startsWith(`https://github.com/${c.repo}/releases/download/`)) return json(res, 400, { error: 'Unexpected download address.' });
      let r; try { r = await fetch(l.asset.url, { headers: { 'User-Agent': UA } }); } catch { return json(res, 502, { error: 'Could not reach GitHub. Check your internet connection and try again.' }); }
      if (!r.ok) return json(res, 502, { error: 'Download failed: ' + r.status });
      const buf = Buffer.from(await r.arrayBuffer());
      if (l.asset.size && buf.length !== l.asset.size) return json(res, 502, { error: 'Download was incomplete. Try again.' });
      const want = /^sha256:([0-9a-f]{64})$/i.exec(l.asset.digest || '');
      if (want && crypto.createHash('sha256').update(buf).digest('hex') !== want[1].toLowerCase()) return json(res, 502, { error: 'The download did not match GitHub\'s checksum, so it was discarded.' });
      const dir = path.join(os.homedir(), 'Downloads'); fs.mkdirSync(dir, { recursive: true });
      const out = path.join(dir, path.basename(l.asset.name)); fs.writeFileSync(out, buf);
      let installed = false, message = 'Saved to ' + out + '.';
      if (process.platform === 'linux' && /\.deb$/i.test(out)) {
        const has = (x) => spawnSync('which', [x]).status === 0;
        if (has('pkexec') && has('dpkg')) { const p = spawnSync('pkexec', ['dpkg', '-i', out], { encoding: 'utf8' }); installed = p.status === 0; message = installed ? 'Installed ' + l.tag + '. Close and reopen AI Messenger to use it.' : 'The installer was cancelled or failed. The file is saved at ' + out + '. You can install it with: sudo dpkg -i "' + out + '"'; }
        else message += ' Install it with: sudo dpkg -i "' + out + '"';
      } else if (process.platform === 'darwin') { try { spawn('open', ['-R', out], { stdio: 'ignore', detached: true }).unref(); } catch {} message += ' Unzip it and replace the old AI Messenger app.'; }
      return json(res, 200, { installed, file: out, message, tag: l.tag });
    }
    return json(res, 404, { error: 'unknown' });
  };
};
module.exports.VERSION = VERSION;
