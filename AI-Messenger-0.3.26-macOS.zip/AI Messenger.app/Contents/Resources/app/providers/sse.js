'use strict';
// Minimal helpers shared by provider plugins.
async function* sseLines(response) {
  const dec = new TextDecoder();
  let buf = '';
  for await (const chunk of response.body) {
    buf += dec.decode(chunk, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).replace(/\r$/, '');
      buf = buf.slice(i + 1);
      if (line.startsWith('data:')) yield line.slice(5).trim();
    }
  }
  if (buf.startsWith('data:')) yield buf.slice(5).trim();
}
async function failIfBad(r) {
  if (r.ok) return;
  let t = ''; try { t = (await r.text()).slice(0, 400); } catch {}
  throw new Error(`HTTP ${r.status} ${r.statusText} ${t}`);
}
// Split stored attachments into images (data URLs) and inline text files.
function splitAttachments(atts) {
  const images = [], texts = [];
  for (const a of atts || []) {
    if (/^data:image\//.test(a.dataUrl || '')) images.push(a);
    else if (a.text) texts.push(a);
  }
  return { images, texts };
}
module.exports = { sseLines, failIfBad, splitAttachments };
