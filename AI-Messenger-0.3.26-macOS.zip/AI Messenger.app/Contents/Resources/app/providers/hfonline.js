'use strict';
// Hugging Face hosted inference (OpenAI-compatible router). Needs internet and a Hugging Face access token.
const openai = require('./openai');
const ROUTER = () => process.env.AIM_HF_ROUTER || 'https://router.huggingface.co/v1';
module.exports = {
  id: 'hfonline',
  name: 'Hugging Face online model (needs internet + token)',
  online: true,
  fields: [{ key: 'apiKey', label: 'Hugging Face token', type: 'password', secret: true }],
  models: ['meta-llama/Llama-3.1-8B-Instruct'],
  efforts: ['low', 'medium', 'high'],
  async *chat({ messages, system, model, config, signal, effort }) {
    yield* openai.chat({ messages, system, model, config: { baseUrl: ROUTER(), apiKey: config.apiKey }, signal, effort: effort === 'max' ? 'high' : effort });
  },
};
