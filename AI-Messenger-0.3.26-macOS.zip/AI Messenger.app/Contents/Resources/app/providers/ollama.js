'use strict';
// Ollama (https://ollama.com): talks to the Ollama app already running on this computer. Models stay on this machine.
const { failIfBad, splitAttachments } = require('./sse');

const normBase = (b) => { b = String(b || process.env.OLLAMA_HOST || 'http://127.0.0.1:11434').trim(); if (!/^https?:\/\//.test(b)) b = 'http://' + b; return b.replace(/\/$/, '').replace('//0.0.0.0', '//127.0.0.1'); };
const unreachable = (base) => new Error(`Can't reach Ollama at ${base}. Open the Ollama app or run "ollama serve", then try again. If Ollama isn't installed, you don't need it: choose File > Set Up Local Runtime to run .gguf model files directly, or install Ollama from ollama.com.`);

async function tags(base, signal) {
  let r; try { r = await fetch(base + '/api/tags', { signal: signal || AbortSignal.timeout(4000) }); } catch { throw unreachable(base); }
  await failIfBad(r); return (await r.json()).models || [];
}

module.exports = {
  id: 'ollama', name: 'Ollama (local, offline)', local: true,
  fields: [{ key: 'baseUrl', label: 'Ollama address', type: 'text', default: 'http://127.0.0.1:11434' }],
  models: [],
  efforts: ['off', 'low', 'medium', 'high', 'max'], // models with thinking only; gpt-oss takes low/medium/high, others just on/off
  normBase, tags,
  async listModels(cfg) { return (await tags(normBase(cfg.baseUrl))).map((m) => m.name).sort(); },
  async *chat({ messages, model, system, config, signal, effort }) {
    const base = normBase(config.baseUrl);
    const msgs = []; if (system) msgs.push({ role: 'system', content: system });
    for (const m of messages) {
      const { images, texts } = splitAttachments(m.attachments);
      const o = { role: m.role, content: m.text + texts.map((t) => `\n\n[Attached file: ${t.name}]\n${t.text}`).join('') };
      if (m.role === 'user' && images.length) o.images = images.map((i) => String(i.dataUrl).split(',')[1]);
      msgs.push(o);
    }
    let r; try { r = await fetch(base + '/api/chat', { method: 'POST', signal, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ model, messages: msgs, stream: true, ...(effort ? { think: effort === 'off' ? false : /gpt-oss/i.test(model) ? (effort === 'max' ? 'high' : effort) : true } : {}) }) }); } catch (e) { if (e.name === 'AbortError') throw e; throw unreachable(base); }
    if (r.status === 404) throw new Error(`Ollama doesn't have a model called "${model}". Run: ollama pull ${model}`);
    await failIfBad(r);
    const dec = new TextDecoder(); let buf = '';
    for await (const chunk of r.body) {
      buf += dec.decode(chunk, { stream: true }); let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1); if (!line) continue;
        let j; try { j = JSON.parse(line); } catch { continue; }
        if (j.error) throw new Error('Ollama: ' + j.error);
        if (j.message && j.message.thinking) yield { reasoning: j.message.thinking };
        if (j.message && j.message.content) yield j.message.content;
        if (j.done) return;
      }
    }
  },
};
