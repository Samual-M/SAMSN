'use strict';
// OpenAI-compatible chat completions: OpenAI, Ollama, LM Studio, llama.cpp, OpenRouter, Groq, Together, ...
const { sseLines, failIfBad, splitAttachments } = require('./sse');

module.exports = {
  id: 'openai',
  name: 'OpenAI-compatible (OpenAI, Ollama, LM Studio, OpenRouter...)',
  fields: [
    { key: 'baseUrl', label: 'Base URL', type: 'text', default: 'https://api.openai.com/v1' },
    { key: 'apiKey', label: 'API key (blank for local models)', type: 'password', secret: true },
  ],
  models: ['gpt-4o-mini', 'gpt-4o'],
  efforts: ['low', 'medium', 'high', 'max'], // reasoning effort the chat window can ask for (max = the highest this model accepts)
  effortParam(model, effort) { return effort === 'max' ? (/gpt-5\.|gpt-5-codex/i.test(model || '') ? 'xhigh' : 'high') : effort; },
  async listModels(cfg) {
    const base = (cfg.baseUrl || 'https://api.openai.com/v1').replace(/\/$/, '');
    const r = await fetch(base + '/models', { headers: cfg.apiKey ? { Authorization: 'Bearer ' + cfg.apiKey } : {} });
    await failIfBad(r);
    const j = await r.json();
    return (j.data || []).map((m) => m.id).sort();
  },
  async *chat({ messages, model, system, config, signal, effort }) {
    const base = (config.baseUrl || 'https://api.openai.com/v1').replace(/\/$/, '');
    const msgs = [];
    if (system) msgs.push({ role: 'system', content: system });
    for (const m of messages) {
      const { images, texts } = splitAttachments(m.attachments);
      let text = m.text + texts.map((t) => `\n\n[Attached file: ${t.name}]\n${t.text}`).join('');
      if (m.role === 'user' && images.length) {
        msgs.push({ role: 'user', content: [{ type: 'text', text }, ...images.map((i) => ({ type: 'image_url', image_url: { url: i.dataUrl } }))] });
      } else msgs.push({ role: m.role, content: text });
    }
    let r;
    try { r = await fetch(base + '/chat/completions', {
      method: 'POST', signal,
      headers: Object.assign({ 'Content-Type': 'application/json' }, config.apiKey ? { Authorization: 'Bearer ' + config.apiKey } : {}),
      body: JSON.stringify({ model, messages: msgs, stream: true, ...(effort && effort !== 'off' ? { reasoning_effort: module.exports.effortParam(model, effort) } : {}) }),
    }); } catch (e) { if (e.name === 'AbortError') throw e; throw new Error(`Can't reach ${base}. Is the server running? (For models on this computer, use the Ollama provider or File > Set Up Local Runtime.)`); }
    await failIfBad(r);
    for await (const data of sseLines(r)) {
      if (data === '[DONE]') return;
      let dl; try { dl = JSON.parse(data).choices?.[0]?.delta; } catch { continue; }
      if (!dl) continue; const rs = dl.reasoning_content || dl.reasoning; if (rs) yield { reasoning: rs }; if (dl.content) yield dl.content;
    }
  },
};
