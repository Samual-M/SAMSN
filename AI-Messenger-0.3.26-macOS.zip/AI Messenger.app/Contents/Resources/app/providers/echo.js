'use strict';
// Offline demo provider - lets you test the whole UI without any API key.
module.exports = {
  id: 'echo',
  name: 'Demo (offline echo)',
  local: true,
  fields: [],
  models: ['echo'],
  async *chat({ messages, signal }) {
    const last = [...messages].reverse().find((m) => m.role === 'user');
    const text = `You said: "${last ? last.text : ''}"\n\nThis is the offline demo contact. Add a real AI contact from File > Add a Contact (or the + next to Models) and pick OpenAI-compatible or Anthropic.`;
    for (const word of text.split(/(\s+)/)) {
      if (signal && signal.aborted) return;
      yield word;
      await new Promise((r) => setTimeout(r, 25));
    }
  },
};
