'use strict';
const { sseLines, failIfBad, splitAttachments } = require('./sse');

module.exports = {
  id: 'anthropic',
  name: 'Anthropic (Claude)',
  fields: [
    { key: 'baseUrl', label: 'Base URL', type: 'text', default: 'https://api.anthropic.com' },
    { key: 'apiKey', label: 'API key (console.anthropic.com, pay-per-use)', type: 'password', secret: true },
  ],
  efforts: ['off', 'low', 'medium', 'high', 'max'], // thinking budget: low 2k, medium 8k, high 16k, max 32k tokens
  budgets: { low: 2048, medium: 8192, high: 16000, max: 32000 },
  models: ['claude-sonnet-5-5', 'claude-opus-5-5', 'claude-haiku-5-5', 'claude-fable-5-1'],
  async listModels(cfg) {
    const base = (cfg.baseUrl || 'https://api.anthropic.com').replace(/\/$/, '');
    const r = await fetch(base + '/v1/models', { headers: { 'x-api-key': cfg.apiKey || '', 'anthropic-version': '2023-06-01' } });
    await failIfBad(r);
    return ((await r.json()).data || []).map((m) => m.id);
  },
  async *chat({ messages, model, system, config, signal, effort }) {
    const base = (config.baseUrl || 'https://api.anthropic.com').replace(/\/$/, '');
    const msgs = messages.map((m) => {
      const { images, texts } = splitAttachments(m.attachments);
      const text = m.text + texts.map((t) => `\n\n[Attached file: ${t.name}]\n${t.text}`).join('');
      if (m.role === 'user' && images.length) {
        return { role: 'user', content: [
          ...images.map((i) => { const mm = /^data:(image\/[\w+.-]+);base64,(.*)$/s.exec(i.dataUrl); return { type: 'image', source: { type: 'base64', media_type: mm[1], data: mm[2] } }; }),
          { type: 'text', text },
        ] };
      }
      return { role: m.role, content: text || ' ' };
    });
    const budget = effort && effort !== 'off' ? module.exports.budgets[effort] : 0;
    const r = await fetch(base + '/v1/messages', {
      method: 'POST', signal,
      headers: { 'Content-Type': 'application/json', 'x-api-key': config.apiKey || '', 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model, max_tokens: 8192 + (budget || 0), stream: true, ...(budget ? { thinking: { type: 'enabled', budget_tokens: budget } } : {}), ...(system ? { system } : {}), messages: msgs }),
    });
    await failIfBad(r);
    for await (const data of sseLines(r)) {
      try { const j = JSON.parse(data); if (j.type === 'content_block_delta' && j.delta?.type === 'thinking_delta' && j.delta.thinking) yield { reasoning: j.delta.thinking }; if (j.type === 'content_block_delta' && j.delta?.text) yield j.delta.text; if (j.type === 'error') throw new Error(j.error?.message || 'error'); } catch (e) { if (e.message && !(e instanceof SyntaxError)) throw e; }
    }
  },
};
