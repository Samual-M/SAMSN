'use strict';
// Runs a downloaded GGUF model fully offline by starting llama.cpp's `llama-server` on 127.0.0.1
// (nothing leaves this computer) and talking to it through the OpenAI-compatible provider.
const fs = require('fs');
const path = require('path');
const net = require('net');
const { spawn } = require('child_process');
const openai = require('./openai');

const running = new Map(); // model file -> { proc, port, ready, timer }
const exe = process.platform === 'win32' ? 'llama-server.exe' : 'llama-server';
const dataDir = () => process.env.AIM_DATA || '';

function findServer() {
  const cands = [];
  if (process.env.AI_MESSENGER_LLAMA_SERVER) cands.push(process.env.AI_MESSENGER_LLAMA_SERVER);
  if (dataDir()) {
    cands.push(path.join(dataDir(), 'bin', exe));
    try { for (const n of fs.readdirSync(path.join(dataDir(), 'bin')).filter((x) => /^llama-b\d+$/.test(x)).sort().reverse()) { const f = require('../runtime').findExe(path.join(dataDir(), 'bin', n)); if (f) cands.push(f); } } catch {} // the one-click install
  }
  for (const d of (process.env.PATH || '').split(path.delimiter)) if (d) cands.push(path.join(d, exe));
  cands.push(path.join(require('os').homedir(), '.local', 'bin', exe), '/usr/local/bin/' + exe, '/opt/homebrew/bin/' + exe);
  return cands.find((f) => { try { fs.accessSync(f, fs.constants.X_OK); return true; } catch { return false; } }) || null;
}
const freePort = () => new Promise((res, rej) => { const s = net.createServer(); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => res(p)); }); s.on('error', rej); });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function start(file) {
  let r = running.get(file);
  if (r) { r.last = Date.now(); return r.ready.then(() => r); }
  const bin = findServer();
  if (!bin) throw new Error('This is a local model, so it needs llama.cpp\'s "llama-server" program (free, runs offline). Choose File > Set Up Local Runtime... to install it with one click, or install llama.cpp yourself so "llama-server" is on your PATH or in ' + (dataDir() ? path.join(dataDir(), 'bin') : 'the bin folder') + ' - then try again.');
  if (!fs.existsSync(file)) throw new Error('The model file is missing: ' + file);
  const port = await freePort();
  const proc = spawn(bin, ['-m', file, '--host', '127.0.0.1', '--port', String(port), '-c', '4096'], { stdio: ['ignore', 'ignore', 'pipe'], env: Object.assign({}, process.env, { LD_LIBRARY_PATH: path.dirname(bin) + path.delimiter + (process.env.LD_LIBRARY_PATH || ''), DYLD_LIBRARY_PATH: path.dirname(bin) + path.delimiter + (process.env.DYLD_LIBRARY_PATH || '') }) });
  let tail = ''; proc.stderr.on('data', (d) => { tail = (tail + d).slice(-1500); });
  r = { proc, port, last: Date.now(), exited: false };
  proc.on('exit', () => { r.exited = true; clearInterval(r.timer); if (running.get(file) === r) running.delete(file); });
  proc.on('error', (e) => { tail += e.message; });
  r.timer = setInterval(() => { if (Date.now() - r.last > 10 * 60 * 1000) proc.kill(); }, 30000); r.timer.unref();
  r.ready = (async () => {
    for (let i = 0; i < 240; i++) { // up to ~2 minutes to load the model
      if (r.exited) throw new Error('llama-server stopped while loading the model.\n' + tail.split('\n').slice(-4).join('\n'));
      try { const h = await fetch(`http://127.0.0.1:${port}/health`); if (h.ok) return; } catch {}
      await sleep(500);
    }
    proc.kill(); throw new Error('Timed out loading the model.');
  })();
  running.set(file, r);
  try { await r.ready; } catch (e) { proc.kill(); running.delete(file); throw e; }
  return r;
}
process.on('exit', () => { for (const r of running.values()) try { r.proc.kill(); } catch {} });

module.exports = {
  id: 'localgguf',
  name: 'Local model (GGUF via llama.cpp, runs offline)',
  local: true,
  fields: [{ key: 'file', label: 'Model file (.gguf)', type: 'text', default: '' }],
  models: ['local'],
  findServer,
  async *chat({ messages, system, config, signal }) {
    const r = await start(config.file);
    r.last = Date.now();
    yield* openai.chat({ messages, system, model: 'local', config: { baseUrl: `http://127.0.0.1:${r.port}/v1` }, signal });
    r.last = Date.now();
  },
};
