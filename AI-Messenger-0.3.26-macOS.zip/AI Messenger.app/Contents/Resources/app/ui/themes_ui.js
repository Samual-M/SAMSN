/* themes_ui.js - the "Themes" dialog (Tools > Themes...). */
(function (g) {
  'use strict';
  const A = AIM; const { el, pageWin } = A; const P = g.Pages;
  P.versionThemes = function () {
    const cur = Themes.current(); let pick = cur.id; let native = !!cur.useNative;
    const body = el('div', { style: 'padding:8px;display:flex;flex-direction:column;gap:6px' });
    body.append(el('div', { style: 'color:#444', text: 'Switch the look of Messenger to any MSN version. Art, icons, sounds and colours come from the original installers you supplied.' }));
    const list = el('div', { style: 'display:flex;flex-direction:column;gap:6px' }); body.append(list);
    const nat = el('label', { style: 'display:flex;gap:6px;align-items:flex-start;font-size:8pt;margin-top:2px' }); const cb = el('input', { type: 'checkbox', checked: native, onchange: () => { native = cb.checked; } });
    nat.append(cb, el('span', { text: 'Also use that version\'s original conversation-window layout (experimental: it was designed for a different window size and can look cramped).' }));
    const draw = () => {
      list.replaceChildren(...Themes.list.map((t) => {
        const card = el('div', { style: `display:flex;gap:8px;padding:6px;border:2px solid ${pick === t.id ? '#316ac5' : '#b9c2d6'};background:${pick === t.id ? '#e8f0ff' : '#fff'};cursor:pointer;border-radius:3px`, onclick: () => { pick = t.id; draw(); } });
        const img = el('img', { src: `assets/previews/${t.id}.png`, style: 'width:96px;height:72px;object-fit:cover;object-position:top;border:1px solid #889;background:#dde' }); img.onerror = () => { img.style.visibility = 'hidden'; };
        const info = el('div', { style: 'flex:1;min-width:0' }, el('div', { style: 'font-weight:bold;color:#003399', text: t.name + (t.best ? '  ★' : '') + (t.id === cur.id ? '  (current)' : '') }),
          el('div', { style: 'color:#6a7ea8;font-size:7.5pt', text: t.year === 'new' ? 'Custom edition' : 'Released ' + t.year }), el('div', { style: 'margin-top:2px', text: t.desc }),
          t.native.length ? el('div', { style: 'color:#164;font-size:7.5pt;margin-top:2px', text: 'Original layouts available: ' + t.native.join(', ') }) : null);
        card.append(img, info); return card;
      }));
      nat.style.display = (Themes.byId[pick].sets.length) ? 'flex' : 'none';
    };
    draw(); body.append(nat);
    pageWin({ title: 'Themes - MSN Messenger versions', width: 480, height: 540, body, buttons: [
      { label: 'Apply', primary: true, onClick: async () => { if (pick === cur.id && native === !!cur.useNative) return true; await Themes.apply(pick, native && Themes.byId[pick].sets.length > 0); return false; } }, { label: 'Close' }] });
  };
})(window);
