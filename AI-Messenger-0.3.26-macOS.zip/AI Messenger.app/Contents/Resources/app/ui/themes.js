/* themes.js - version themes. Each theme = resource sets (native DirectUI layouts of that MSN version) +
 * an image map (re-skins the 7.5 layout with that version's art) + sounds + a little CSS (themes.css). */
(function (g) {
  'use strict';
  const T = (o) => Object.assign({ sets: [], map: null, sounds: null, native: [] }, o);
  const THEMES = [
    T({ id: 'msn75', name: 'MSN Messenger 7.5', year: '2006', css: 't75', native: ['Main window', 'Conversation window', 'Sign-in'], desc: 'The final version: the default look of this app.' }),
    T({ id: 'msn70', name: 'MSN Messenger 7.0', year: '2005', css: 't70', sets: [{ id: '7.0', files: ['920_1033.uif'] }], map: '7.0', sounds: '7.0', native: ['Conversation window'], desc: 'The 7.0 conversation window; the main window uses 7.0 art on the 7.5 layout.' }),
    T({ id: 'msn62', name: 'MSN Messenger 6.2', year: '2004', css: 't62', sets: [{ id: '6.2', files: ['920_1033.uif'] }], map: '6.2', sounds: '6.2', native: ['Conversation window'], desc: 'The 6.2 conversation window; main window uses 6.2 art on the 7.5 layout.' }),
    T({ id: 'msn60', name: 'MSN Messenger 6.0', year: '2003', css: 't60', sets: [{ id: '6.0', files: ['920_1033.uif'] }], map: '6.0', sounds: '6.0', native: ['Conversation window'], desc: 'The 6.0 conversation window and art, with its display pictures and backgrounds.' }),
    T({ id: 'msn51', name: 'MSN Messenger 5.1', year: '2003', css: 't51', map: '5.1', sounds: '5.1', native: [], desc: 'Classic look with 5.1 icons and its original (shorter) sounds. 5.x had no skinnable layout files.' }),
    T({ id: 'msn50', name: 'MSN Messenger 5.0', year: '2002', css: 't50', map: '5.0', sounds: '5.0', native: [], desc: 'Classic look with 5.0 icons. 5.x had no skinnable layout files.' }),
    T({ id: 'msn80', name: 'MSN 8.0 (AI edition)', year: 'new', css: 't80', sounds: '7.0', native: [], best: true, desc: 'Best-of mix for talking to AI models: the 7.5 layout, a fresh blue look, 7.0 sounds, every version\'s display pictures, the MSN emoticon set, copy buttons on messages and code, and a wider chat history.' }),
  ];
  const byId = Object.fromEntries(THEMES.map((t) => [t.id, t]));
  let cur = byId.msn75;
  async function boot() { // runs before any window is built
    let id = 'msn75', native = false; try { const u = await API.ui(); id = u.theme || id; native = !!u.native; } catch (e) {}
    cur = byId[id] || byId.msn75; cur.useNative = native; g.AIM && (g.AIM.theme = cur);
    document.documentElement.dataset.theme = cur.css;
    const idx = await (await fetch('assets/sets/index.json')).json();
    await UIF.load(['923_1033.uif', '920_1033.uif', '936_1033.uif', '947_1033.uif', '945_1033.uif']); // the 7.5 base set
    for (const s of (native ? cur.sets : [])) {
      const files = s.files === 'all' ? idx[s.id].uif : s.files;
      await UIF.loadSet(s.id, { dir: `assets/sets/${s.id}/uif/`, files, img: `assets/sets/${s.id}/img/`, strings: `assets/sets/${s.id}/strings.json` });
    }
    if (cur.map) UIF.setImageMap({ base: `assets/sets/${cur.map}/img/`, map: await (await fetch(`assets/sets/${cur.map}/map.json`)).json() });
    cur.soundList = cur.sounds ? idx[cur.sounds].sounds : [];
    return cur;
  }
  const soundUrl = (name) => (cur.sounds && cur.soundList && cur.soundList.includes(name)) ? `assets/sets/${cur.sounds}/sounds/${name}.wav` : `assets/sounds/${name}.wav`;
  async function apply(id, native) { await API.setUi({ theme: id, native: !!native }); try { new BroadcastChannel('aim').postMessage({ t: 'reload' }); } catch (e) {} location.reload(); }
  g.Themes = { list: THEMES, byId, boot, apply, current: () => cur, soundUrl };
})(window);
