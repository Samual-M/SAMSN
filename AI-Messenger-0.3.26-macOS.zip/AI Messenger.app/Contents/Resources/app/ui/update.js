/* update.js - "Check for updates": looks at the user's own GitHub repository for a newer release.
 * Nothing connects until the user presses Allow in the consent panel. */
(function (g) {
  'use strict';
  const A = AIM; const { el, pageWin, toast } = A; const P = g.Pages;
  const api = (m, p, b) => fetch('/api/update/' + p, { method: m, headers: { 'X-Token': sessionStorage.getItem('tok') || '', 'Content-Type': 'application/json' }, body: b ? JSON.stringify(b) : undefined })
    .then(async (r) => { const j = await r.json().catch(() => ({})); if (!r.ok) { const e = new Error(j.error || r.statusText); e.code = j.error; throw e; } return j; });

  P.updates = async function () {
    let st; try { st = await api('GET', 'status'); } catch (e) { return toast(e.message); }
    const root = el('div', { style: 'padding:10px;line-height:1.45;font-size:9pt' });
    const win = pageWin({ title: 'Check for updates', width: 460, body: root, buttons: [{ label: 'Close' }] });
    const row = (k, v) => `<tr><td><b>${k}</b></td><td style="white-space:normal">${v}</td></tr>`;

    function consent() {
      root.replaceChildren(el('div', { html: `<h3 style="margin:0 0 6px">Connect to GitHub?</h3><p>To look for a newer version, this window needs to connect to the internet. Nothing has been sent yet.</p>
        <table class="tbl" style="margin:6px 0"><tbody>
        ${row('Server', 'api.github.com and github.com')}${row('Operated by', 'GitHub, Inc. (Microsoft)')}
        ${row('Sent', 'The repository name you type below and your normal IP address (as with any website). <b>Never</b> your chats, contacts, profile or name.')}
        ${row('Received', 'The newest release of that repository, and the installer file only if you press Install.')}
        ${row('Why', 'Your updates are published as GitHub releases.')}
        ${row('If you decline', 'Everything else keeps working. Update by installing a new .deb yourself.')}</tbody></table>
        <p>Only install updates from a repository you control: an update is a program that runs on your computer. No analytics or tracking is added by this app.</p>` }),
        el('div', { style: 'text-align:right' }, el('button', { class: 'btn primary', text: 'Allow connection', onclick: async () => { await api('POST', 'config', { consent: true }); st.consent = true; main(); } })));
    }

    function main() {
      const repo = el('input', { type: 'text', value: st.repo || '', placeholder: 'yourname/ai-messenger', style: 'flex:1;min-width:0' });
      const out = el('div', { style: 'margin-top:8px;min-height:40px' });
      const check = el('button', { class: 'btn primary', text: 'Check now', onclick: run });
      root.replaceChildren(
        el('div', { text: `You have version ${st.version}.` }),
        el('div', { style: 'margin-top:6px', text: 'Your GitHub repository (owner/name):' }),
        el('div', { style: 'display:flex;gap:4px;margin-top:3px' }, repo, check), out,
        el('div', { style: 'margin-top:10px;text-align:right' }, el('a', { href: '#', text: 'Turn off GitHub connection', onclick: async (e) => { e.preventDefault(); await api('POST', 'config', { consent: false }); st.consent = false; consent(); } })));
      async function run() {
        out.textContent = 'Checking...'; check.disabled = true;
        try {
          const c = await api('POST', 'config', { repo: repo.value }); st.repo = c.repo;
          const r = await api('GET', 'check');
          if (!r.newer) { out.textContent = `You are up to date (latest release: ${r.tag || 'none'}).`; return; }
          const btn = el('button', { class: 'btn primary', text: `Install ${r.tag}`, disabled: !r.asset, onclick: async () => {
            btn.disabled = true; note.textContent = 'Downloading...';
            try { const i = await api('POST', 'install'); note.textContent = i.message; } catch (e) { note.textContent = e.message; btn.disabled = false; } } });
          const note = el('div', { style: 'margin-top:6px;white-space:pre-wrap' });
          out.replaceChildren(el('div', { html: `<b>${r.tag}</b> is available.` + (r.asset ? ` File: ${r.asset.name} (${(r.asset.size / 1048576).toFixed(1)} MB).` : ' This release has no file for this computer.') }),
            el('div', { style: 'max-height:90px;overflow:auto;margin:4px 0;color:#44608f;white-space:pre-wrap', text: r.notes || '' }), btn, note);
        } catch (e) { if (e.code === 'consent') { st.consent = false; return consent(); } out.textContent = e.message; } finally { check.disabled = false; }
      }
    }
    st.consent ? main() : consent();
  };
})(window);
