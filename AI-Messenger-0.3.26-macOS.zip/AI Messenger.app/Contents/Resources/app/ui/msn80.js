/* msn80.js - extras for the "MSN 8.0 (AI edition)" theme: MSN emoticons (sprite strip), copy buttons, picture list. */
(function (g) {
  'use strict';
  // frame index -> shortcut(s) in the 79-frame emoticon strip (assets/img/727.png, 19px frames)
  const CODES = { 0: [':)', ':-)'], 1: [':D', ':-D'], 2: [';)', ';-)'], 3: [':O', ':-O'], 4: [':P', ':-P'], 5: ['(H)'], 6: [':@'], 7: [':$'], 8: [':S'], 9: [':(', ':-('], 10: [":'("], 11: [':|'], 12: ['(6)'], 13: ['(A)'], 14: ['(L)'], 15: ['(U)'], 16: ['(M)'], 17: ['(@)'], 18: ['(&)'], 19: ['(S)'], 20: ['(*)'], 21: ['(~)'], 22: ['(8)'], 23: ['(E)'], 24: ['(F)'], 25: ['(W)'], 26: ['(O)'], 27: ['(K)'], 28: ['(G)'], 29: ['(^)'], 30: ['(P)'], 31: ['(I)'], 32: ['(C)'], 33: ['(T)'], 34: ['({)'], 35: ['(})'], 36: ['(B)'], 37: ['(D)'], 38: ['(Z)'], 39: ['(X)'], 40: ['(Y)'], 41: ['(N)'], 42: [':['], 44: ['(%)'], 45: ['(#)'], 46: ['(R)'], 47: [':-#'], 48: ['8o|'], 49: ['8-|'], 50: ['^o)'], 52: ['+o('], 53: ['(sn)'], 54: ['(tu)'], 55: ['(pl)'], 57: ['(pi)'], 58: ['(so)'], 59: ['(au)'], 60: ['(ap)'], 61: ['(um)'], 62: ['(ip)'], 63: ['(co)'], 64: ['(mp)'], 76: ['(ci)'] };
  const esc = (s) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const table = []; for (const [f, cs] of Object.entries(CODES)) for (const c of cs) table.push([esc(c), +f, c]);
  table.sort((a, b) => b[0].length - a[0].length);
  const re = new RegExp(table.map((t) => t[0].replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|'), 'gi');
  const map = Object.fromEntries(table.map((t) => [t[0].toLowerCase(), t[1]]));
  const sprite = (f, c) => `<span class="emo" title="${esc(c)}" data-c="${esc(c)}" style="background-position:-${f * 19}px 0"></span>`;
  // replace shortcuts in already-escaped HTML text, leaving tags and entities-in-tags alone
  function emo(html) {
    let code = 0;
    return html.split(/(<[^>]+>)/).map((seg) => {
      if (seg[0] === '<') { if (/^<code/i.test(seg)) code++; else if (/^<\/code/i.test(seg)) code--; return seg; }
      if (code > 0) return seg;
      return seg.replace(re, (m, off, str) => {
        const before = str[off - 1];
        if (before && /\w/.test(before)) return m; // not mid-word: f(a), http://
        return map[m.toLowerCase()] != null ? sprite(map[m.toLowerCase()], m) : m;
      });
    }).join('');
  }
  function picker(x, y, put) {
    const m = AIM.el('div', { class: 'menu emo-pick', style: `left:${x}px;top:${y}px;display:grid;grid-template-columns:repeat(9,26px);padding:4px;max-height:240px;overflow:auto` });
    for (const [f, cs] of Object.entries(CODES)) m.append(AIM.el('div', { class: 'emo-cell', title: cs[0], onclick: () => { put(cs[0]); m.remove(); } }, AIM.el('span', { class: 'emo', style: `background-position:-${f * 19}px 0` })));
    document.body.append(m); const r = m.getBoundingClientRect(); if (r.right > innerWidth) m.style.left = Math.max(0, innerWidth - r.width - 4) + 'px'; if (r.bottom > innerHeight) m.style.top = Math.max(0, y - r.height - 30) + 'px';
    setTimeout(() => document.addEventListener('mousedown', function h(e) { if (!m.contains(e.target)) { m.remove(); document.removeEventListener('mousedown', h); } }), 0);
  }
  const on = () => g.AIM && AIM.theme && AIM.theme.id === 'msn80';
  g.Msn80 = { on, emo, picker, CODES };
})(window);
