/* pages.js - local replacements for every MSN page/dialog. Nothing here talks to MSN servers. */
(function (g) {
  'use strict';
  const A = AIM; const { el, esc, dialog, pageWin, info, toast, confirmBox, notApplicable, avatar, fmtTime } = A;
  const S = () => A.state;
  const refresh = () => A.hooks.refresh();
  const byId = (id) => S().contacts.find((c) => c.id === id);
  const saveSettings = async (patch) => { S().settings = await API.settings(patch); A.applyTheme(); };
  const saveAssets = async (patch) => { S().assets = Object.assign({}, S().assets, patch); await API.assets(S().assets); };
  const table = (head, rows, opts = {}) => { // rows: [{cells:[...], data, onDbl}]
    const t = el('table', { class: 'tbl' }); t.append(el('thead', null, el('tr', null, ...head.map((h) => el('th', { text: h })))));
    const tb = el('tbody'); let sel = null;
    for (const r of rows) {
      const tr = el('tr'); r.cells.forEach((c) => tr.append(el('td', c instanceof Node ? null : { text: c }, c instanceof Node ? c : null)));
      tr.onclick = () => { if (sel) sel.classList.remove('sel'); sel = tr; tr.classList.add('sel'); t.selected = r; opts.onSelect && opts.onSelect(r); };
      tr.ondblclick = () => r.onDbl && r.onDbl(r); tb.append(tr);
    }
    if (!rows.length) tb.append(el('tr', null, el('td', { colSpan: head.length, text: opts.empty || 'Nothing here yet.', style: 'color:#888;font-style:italic;padding:10px' })));
    t.append(tb); return t;
  };
  const section = (html) => el('div', { class: 'pgtext', html });
  const LINKS = [['Contacts / Address Book', () => P.addressBook()], ['Message History', () => P.history()], ['Inbox', () => P.inbox()], ['Offline Messages', () => P.offline()], ['Today', () => P.today()], ['My Space', () => P.space()], ['Alerts History', () => P.alerts()], ['Received Files', () => P.received()], ['Options', () => P.options()]];

  const P = {};

  // ====================== contacts ======================
  P.contactDialog = async function (existing) {
    const provs = S().providers; const c = existing || { provider: provs[0] && provs[0].id, config: {} };
    let pic = c.avatar || '';
    const rows = [
      { key: 'name', label: 'Display name:', value: c.name || '', placeholder: 'e.g. Claude' },
      { key: 'provider', label: 'Provider plug-in:', type: 'select', options: provs.map((p) => ({ value: p.id, label: p.name })), value: c.provider },
      { key: 'model', label: 'Model:', value: c.model || (provs.find((p) => p.id === c.provider) || provs[0]).models[0] || '', list: [] },
      ...provs.flatMap((p) => p.fields.map((f) => ({ group: p.id, key: `cfg_${p.id}_${f.key}`, label: f.label + ':', type: f.type || 'text', value: p.id === c.provider ? ((c.config && c.config[f.key]) || f.default || '') : (f.default || '') }))),
      { key: 'group', label: 'Group:', type: 'select', options: [{ value: '', label: '(none)' }, ...S().groups.map((gp) => ({ value: gp, label: gp }))], value: c.group || '' },
      { key: 'psm', label: 'Personal message:', value: c.psm || '' },
      { label: 'System prompt (optional):', full: true, key: 'system', type: 'textarea', value: c.system || '' },
      { key: 'blocked', label: 'Block this contact', type: 'checkbox', value: !!c.blocked },
    ];
    const curProv = (inp) => provs.find((p) => p.id === inp.provider.value); let lastDefaults = null;
    const res = await dialog({ title: existing ? 'Contact Properties' : 'Add a Contact', rows, width: 440,
      onBuilt: (d, inp) => { const upd = () => { const p = curProv(inp); d.querySelectorAll('[data-group]').forEach((e) => { e.style.display = e.dataset.group === p.id ? '' : 'none'; }); const dl = inp.__dl_model; dl.innerHTML = ''; p.models.forEach((m) => dl.append(el('option', { value: m }))); if (!inp.model.value || (lastDefaults && lastDefaults.includes(inp.model.value))) inp.model.value = p.models[0] || ''; lastDefaults = p.models; }; inp.provider.addEventListener('change', upd); upd(); },
      extra: [
        ...(existing ? [] : [{ label: 'Claude preset', onClick: async (inp) => { inp.provider.value = 'anthropic'; inp.provider.dispatchEvent(new Event('change')); if (!inp.name.value) inp.name.value = 'Claude'; inp.model.value = 'claude-sonnet-5-5'; toast('Paste your Anthropic API key (console.anthropic.com), then Fetch models. A claude.ai subscription cannot be used here.'); return false; } }]),
        { label: 'Picture...', onClick: async () => { const r = await P.pickPicture(pic, 'Contact Picture'); if (r !== null) { pic = r; toast('Picture selected.'); } return false; } },
        { label: 'Fetch models', onClick: async (inp) => { try { const p = curProv(inp); const cfg = {}; p.fields.forEach((f) => { cfg[f.key] = inp[`cfg_${p.id}_${f.key}`].value; }); const r = await API.models({ provider: p.id, id: c.id, config: cfg }); const dl = inp.__dl_model; dl.innerHTML = ''; r.models.forEach((m) => dl.append(el('option', { value: m }))); toast(r.error ? 'Could not list models: ' + r.error : r.models.length + ' models found'); } catch (e) { toast(e.message); } } }] });
    if (!res) return null;
    if (!res.name.trim()) { toast('Please enter a display name.'); return null; }
    const p = provs.find((x) => x.id === res.provider); const config = {};
    for (const f of p.fields) config[f.key] = res[`cfg_${p.id}_${f.key}`] != null ? res[`cfg_${p.id}_${f.key}`] : '';
    return API.saveContact({ id: c.id, name: res.name.trim(), provider: res.provider, model: res.model, psm: res.psm, system: res.system, group: res.group, blocked: res.blocked, avatar: pic, config });
  };

  P.addressBook = function () {
    let q = ''; const body = el('div', { style: 'padding:6px' });
    const search = el('input', { placeholder: 'Search contacts...', style: 'width:100%;margin-bottom:6px', oninput: () => { q = search.value.toLowerCase(); draw(); } });
    const holder = el('div', { style: 'height:300px;overflow:auto;border:1px solid #7f9db9;background:#fff' }); body.append(search, holder);
    let selId = null;
    function draw() {
      const rows = S().contacts.filter((c) => (c.name + c.model + c.provider + (c.group || '')).toLowerCase().includes(q)).map((c) => ({ id: c.id, cells: [c.name + (c.blocked ? ' (blocked)' : ''), c.provider, c.model, c.group || ''], onDbl: () => A.hooks.openConv(c.id) }));
      holder.replaceChildren(table(['Name', 'Provider', 'Model', 'Group'], rows, { onSelect: (r) => { selId = r.id; }, empty: 'No contacts.' }));
    }
    draw();
    const w = pageWin({ title: 'My Address Book', width: 560, body, buttons: [
      { label: 'Add...', onClick: async () => { await P.contactDialog(); await refresh(); draw(); return false; } },
      { label: 'Properties...', onClick: async () => { const c = byId(selId); if (!c) { toast('Select a contact first.'); return false; } await P.contactDialog(c); await refresh(); draw(); return false; } },
      { label: 'Delete', onClick: async () => { const c = byId(selId); if (!c) { toast('Select a contact first.'); return false; } if (await confirmBox('Delete contact', `Delete "${c.name}" and its message history?`, 'Delete')) { await API.delContact(c.id); selId = null; await refresh(); draw(); } return false; } },
      { label: 'Close', primary: true }] });
    return w;
  };

  P.groupOp = async function (op) {
    const gs = S().groups;
    if (op === 'create') { const r = await dialog({ title: 'Create a New Group', rows: [{ key: 'n', label: 'Group name:' }] }); if (r && r.n.trim()) { await API.groups({ op: 'create', name: r.n.trim() }); await refresh(); } return; }
    if (!gs.length) return info('Groups', '<div style="padding:12px">There are no groups yet. Use Contacts > Manage Groups > Create a New Group.</div>');
    const rows = [{ key: 'g', label: 'Group:', type: 'select', options: gs.map((x) => ({ value: x, label: x })) }]; if (op === 'rename') rows.push({ key: 'to', label: 'New name:' });
    const r = await dialog({ title: op === 'rename' ? 'Rename a Group' : 'Delete a Group', rows, ok: op === 'rename' ? 'Rename' : 'Delete' });
    if (!r) return; await API.groups({ op, name: r.g, to: (r.to || '').trim() }); await refresh();
  };
  P.exportContacts = async function () {
    const r = await dialog({ title: 'Save Contact List', rows: [{ html: 'Exports your contacts (names, providers, models, system prompts, groups).' }, { key: 'keys', type: 'checkbox', label: 'Include API keys (not recommended)' }] }); if (!r) return;
    const list = S().contacts.map((c) => { const o = JSON.parse(JSON.stringify(c)); delete o.id; if (!r.keys) for (const k of Object.keys(o.config || {})) if (/key|token|secret/i.test(k)) delete o.config[k]; else; if (r.keys) toast('Keys masked by the server cannot be exported; re-enter them after import.'); return o; });
    A.download('contacts.json', JSON.stringify({ app: 'ai-messenger', groups: S().groups, contacts: list }, null, 2), 'application/json'); toast('Contact list saved.');
  };
  P.importContacts = async function () {
    const [f] = await A.pickFile('.json,application/json'); if (!f) return;
    try { const j = JSON.parse(await f.text()); const list = j.contacts || []; let n = 0;
      for (const c of list) { if (!c.name || !c.provider) continue; await API.saveContact({ name: c.name, provider: c.provider, model: c.model, system: c.system, psm: c.psm, group: c.group || '', config: c.config || {}, avatar: c.avatar || '' }); n++; }
      await refresh(); toast(`${n} contact(s) imported.`); } catch (e) { toast('Import failed: ' + e.message); }
  };
  P.searchContacts = async function (mode) {
    const r = await dialog({ title: mode === 'interest' ? 'Search by Interest' : 'Advanced Search', rows: [{ html: mode === 'interest' ? 'Looks in personal messages and system prompts.' : 'Looks in names, providers, models and groups.' }, { key: 'q', label: 'Search for:' }], ok: 'Search' });
    if (!r || !r.q.trim()) return; const q = r.q.toLowerCase();
    const hit = S().contacts.filter((c) => (mode === 'interest' ? (c.psm || '') + (c.system || '') : c.name + c.provider + c.model + (c.group || '')).toLowerCase().includes(q));
    pageWin({ title: `Search results (${hit.length})`, width: 460, body: el('div', { style: 'padding:6px;height:220px;overflow:auto' }, table(['Name', 'Model', 'Group'], hit.map((c) => ({ cells: [c.name, c.model, c.group || ''], onDbl: () => A.hooks.openConv(c.id) })), { empty: 'No matching contacts.' })), buttons: [{ label: 'Close', primary: true }] });
  };

  // ====================== history, inbox, offline ======================
  P.history = async function (startId, startQuery) {
    const chats = [...(S().chats || [])].sort((x, y) => y.updated - x.updated); let id = startId || (chats[0] && chats[0].id); let q = startQuery || ''; let msgs = []; let selIdx = null;
    const body = el('div', { style: 'padding:6px;display:flex;flex-direction:column;gap:6px;height:100%;box-sizing:border-box' });
    const sel = el('select', { style: 'flex:1' }); chats.forEach((c) => sel.append(el('option', { value: c.id, text: c.title, selected: c.id === id })));
    const search = el('input', { placeholder: 'Search this conversation...', value: q, style: 'flex:1' });
    body.append(el('div', { style: 'display:flex;gap:6px' }, sel, search));
    const list = el('div', { style: 'flex:1;overflow:auto;border:1px solid #7f9db9;background:#fff;user-select:text' }); body.append(list);
    async function load() { id = sel.value; msgs = id ? await API.history(id) : []; draw(); }
    function draw() {
      list.replaceChildren(); const qq = search.value.toLowerCase(); const ch = chats.find((x) => x.id === id); const c = ch && byId(ch.participants[0]); let shown = 0;
      msgs.forEach((m, i) => { if (qq && !String(m.text).toLowerCase().includes(qq)) return; shown++;
        const who = m.role === 'user' ? (S().profile.name || 'You') : ((m.from && byId(m.from) ? byId(m.from).name : (c ? c.name : 'Contact')));
        const row = el('div', { style: 'padding:3px 6px;border-bottom:1px solid #eef;white-space:pre-wrap;cursor:default', class: i === selIdx ? 'selrow' : '' });
        row.append(el('div', { style: 'color:#6a7ea8;font-size:8pt', text: `${who} - ${new Date(m.t).toLocaleString()}` }), el('div', { text: m.text })); row.onclick = () => { selIdx = i; draw(); }; list.append(row); });
      if (!shown) list.append(el('div', { text: 'No messages.', style: 'padding:10px;color:#888;font-style:italic' }));
    }
    sel.onchange = () => { selIdx = null; load(); }; search.oninput = draw; await load();
    pageWin({ title: 'Message History', width: 620, height: 470, body, buttons: [
      { label: 'Open Conversation', onClick: () => { if (id) A.hooks.openConv(id); return false; } },
      { label: 'Delete Message', onClick: async () => { if (selIdx == null) { toast('Select a message first.'); return false; } await API.removeMessage(id, selIdx); selIdx = null; await load(); return false; } },
      { label: 'Clear Conversation', onClick: async () => { if (id && await confirmBox('Clear history', 'Delete the whole conversation history for this contact?', 'Delete')) { await API.clearHistory(id); await load(); } return false; } },
      { label: 'Export...', onClick: () => { const c = byId(((chats.find((x) => x.id === id)) || { participants: [] }).participants[0]); A.download(`${(chats.find((x) => x.id === id) || {}).title || 'history'}.txt`, msgs.map((m) => `[${new Date(m.t).toLocaleString()}] ${m.role === 'user' ? S().profile.name : (c ? c.name : 'Contact')}:\n${m.text}\n`).join('\n')); return false; } },
      { label: 'Close', primary: true }] });
  };
  P.searchHistory = async function (q) { // global search results page
    const res = q ? await API.search(q) : [];
    const body = el('div', { style: 'padding:6px;height:100%' }, table(['Contact', 'When', 'Message'], res.map((r) => ({ cells: [r.name, new Date(r.t).toLocaleString(), r.snippet.replace(/\s+/g, ' ')], onDbl: () => A.hooks.openConv(r.id) })), { empty: `No results for "${q}".` }));
    pageWin({ title: `Search results for "${q}" (${res.length})`, width: 620, height: 380, body, buttons: [{ label: 'Close', primary: true }] });
  };
  P.inbox = async function () {
    const ov = (await API.overview()).filter((o) => o.count).sort((a, b) => b.last.t - a.last.t);
    const body = el('div', { style: 'padding:6px;height:100%' }, table(['From', 'Last message', 'Time', 'Msgs'], ov.map((o) => ({ cells: [o.name, (o.last.role === 'user' ? 'You: ' : '') + o.last.text.replace(/\s+/g, ' ').slice(0, 80), fmtTime(o.last.t), String(o.count)], onDbl: () => A.hooks.openConv(o.id) })), { empty: 'Your inbox is empty. Start a conversation from the contact list.' }));
    pageWin({ title: 'Inbox - Conversations', width: 600, height: 360, body, buttons: [{ label: 'Close', primary: true }] });
  };
  P.offline = async function () {
    const ov = (await API.overview()).filter((o) => o.undelivered);
    const body = el('div', { style: 'padding:6px;height:100%' }, el('div', { style: 'padding:2px 2px 6px', text: 'Messages that did not get a reply (for example the AI service was unreachable). Double-click to open the conversation and send again.' }),
      table(['Contact', 'Unanswered message', 'Count'], ov.map((o) => ({ cells: [o.name, (o.firstUndelivered || '').replace(/\s+/g, ' ').slice(0, 80), String(o.undelivered)], onDbl: () => A.hooks.openConv(o.id, { resend: true }) })), { empty: 'No offline messages. Everything you sent was answered.' }));
    pageWin({ title: 'My Offline Messages', width: 580, height: 330, body, buttons: [{ label: 'Close', primary: true }] });
  };

  // ====================== Today / Home / Space ======================
  P.today = async function () {
    const ov = await API.overview(); const total = ov.reduce((a, o) => a + o.count, 0); const now = new Date(); const hr = now.getHours();
    let todayCount = 0; for (const o of ov) if (o.count) { const h = await API.history(o.id); todayCount += h.filter((m) => new Date(m.t).toDateString() === now.toDateString()).length; }
    const greet = hr < 12 ? 'Good morning' : hr < 18 ? 'Good afternoon' : 'Good evening';
    const recent = ov.filter((o) => o.count).sort((a, b) => b.last.t - a.last.t).slice(0, 4);
    const body = section(`<h2 style="margin:0 0 4px;color:#003399">${greet}, ${esc(S().profile.name)}!</h2><div style="color:#555;margin-bottom:10px">${now.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</div>
      <div style="display:flex;gap:10px;margin-bottom:10px"><div class="card"><b>${S().contacts.length}</b><br>contacts</div><div class="card"><b>${total}</b><br>messages stored</div><div class="card"><b>${todayCount}</b><br>messages today</div></div>
      <b>Recent conversations</b><ul style="margin:4px 0 10px">${recent.map((o) => `<li>${esc(o.name)} - <span style="color:#666">${esc(o.last.text.replace(/\s+/g, ' ').slice(0, 60))}</span></li>`).join('') || '<li style="color:#888">None yet</li>'}</ul>
      <b>Tip</b><br>Add more AI models under File &gt; Add a Contact (or the + next to Models). Create group chats with Actions &gt; Invite a Contact to Join This Conversation.<br><br>
      <span style="color:#666">Everything on this page is computed on your computer. Nothing is downloaded.</span>`);
    pageWin({ title: 'MSN Today (local)', width: 480, body, buttons: [{ label: 'Close', primary: true }] });
  };
  P.home = function () {
    const body = el('div', { class: 'pgtext' }, el('h2', { text: 'AI Messenger Home', style: 'margin:0 0 8px;color:#003399' }), el('div', { text: 'Everything that used to live on MSN web pages now runs locally:', style: 'margin-bottom:8px' }));
    for (const [label, fn] of LINKS) body.append(el('div', null, el('a', { href: '#', text: label, style: 'color:#0645ad', onclick: (e) => { e.preventDefault(); fn(); } })));
    pageWin({ title: 'MSN Home Page (local)', width: 380, body, buttons: [{ label: 'Close', primary: true }] });
  };
  P.space = async function () {
    const p = S().profile; const av = S().assets.avatar;
    const body = el('div', { class: 'pgtext' }); const about = el('textarea', { style: 'width:100%;height:90px', value: p.about || '' });
    body.append(el('div', { style: 'display:flex;gap:12px;align-items:center;margin-bottom:10px' }, avatar(p.name, 72, 210, av), el('div', null, el('div', { text: p.name, style: 'font-size:14pt;font-weight:bold;color:#003399' }), el('div', { text: p.psm || '', style: 'color:#6a7ea8;font-style:italic' }), el('div', { text: `${p.status} - ${S().contacts.length} contact(s)` }))), el('b', { text: 'About me' }), about,
      el('div', { style: 'margin-top:8px;color:#666', text: 'This is your local profile page. It is stored only on this computer and is not shared with anyone.' }));
    pageWin({ title: 'My MSN Space (local profile)', width: 460, body, buttons: [{ label: 'Save', primary: true, onClick: async () => { S().profile = await API.profile({ about: about.value }); toast('Saved.'); } }, { label: 'Close' }] });
  };

  // ====================== appearance ======================
  // Gallery of the original MSN display pictures + "Browse..." for your own. Resolves to a data URL, '' (default) or null (cancelled).
  P.pickPicture = function (current, title) {
    return new Promise((resolve) => {
      let pick = current || ''; let done = false; const body = el('div', { style: 'padding:10px;text-align:center' });
      const prev = el('div', { style: 'display:inline-block;margin-bottom:8px' }); const draw = () => prev.replaceChildren(avatar(S().profile.name, 96, 210, pick));
      const grid = el('div', { style: 'display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:6px' });
      const choose = async (url) => { pick = await A.resizeImage(url, 96, 'image/jpeg'); draw(); };
      for (const u of [A.BUDDY, ...A.PICS]) { const im = el('img', { src: u, style: 'width:64px;height:64px;cursor:pointer;border:2px solid #aaa;object-fit:cover;background:#fff', onclick: () => choose(u) }); grid.append(im); }
      body.append(prev, el('div', null, el('button', { class: 'btn', text: 'Browse...', onclick: async () => { const [f] = await A.pickFile('image/*'); if (f) { pick = await A.resizeImage(f, 96, 'image/jpeg'); draw(); } } }), ' ', el('button', { class: 'btn', text: 'Use default', onclick: () => { pick = ''; draw(); } })), grid); draw();
      pageWin({ title: title || 'Change Display Picture', width: 380, body, onClose: () => { if (!done) resolve(null); }, buttons: [{ label: 'OK', primary: true, onClick: async () => { done = true; resolve(pick); } }, { label: 'Cancel' }] });
    });
  };
  P.displayPicture = async function () {
    const r = await P.pickPicture(S().assets.avatar, 'Change My Display Picture'); if (r === null) return;
    await saveAssets({ avatar: r }); await refresh();
  };
  P.backgrounds = function (onPick) {
    const cur = S().settings.background; const custom = S().assets.backgrounds || [];
    const items = [{ url: '', label: 'None' }, ...[340, 341, 342, 343, 344].map((n) => ({ url: `assets/img/${n}.jpg`, label: 'Messenger' })), ...custom.map((u) => ({ url: u, label: 'Mine', custom: true }))];
    const body = el('div', { style: 'padding:8px' }); const grid = el('div', { style: 'display:grid;grid-template-columns:repeat(4,1fr);gap:8px' }); let pick = cur;
    const draw = () => { grid.replaceChildren(...items.map((it) => { const d = el('div', { style: `height:70px;border:2px solid ${pick === it.url ? '#316ac5' : '#aaa'};background:${it.url ? `url(${it.url}) center/cover` : '#fff'};cursor:pointer;display:flex;align-items:flex-end;justify-content:center;font-size:8pt` }, el('span', { text: it.label, style: 'background:#ffffffcc;padding:0 3px' })); d.onclick = () => { pick = it.url; draw(); }; return d; })); }; draw();
    body.append(grid, el('div', { style: 'margin-top:8px' }, el('button', { class: 'btn', text: 'Browse...', onclick: async () => { const [f] = await A.pickFile('image/*'); if (f) { const u = await A.resizeImage(f, 700, 'image/jpeg', .8); custom.push(u); items.push({ url: u, label: 'Mine', custom: true }); pick = u; await saveAssets({ backgrounds: custom }); draw(); } } })));
    pageWin({ title: 'My Backgrounds', width: 440, body, buttons: [{ label: 'OK', primary: true, onClick: async () => { await saveSettings({ background: pick }); onPick && onPick(pick); } }, { label: 'Cancel' }] });
  };
  P.themes = function () {
    const sw = [[0, 'Blue (original)'], [100, 'Green'], [160, 'Teal'], [260, 'Purple'], [310, 'Pink'], [30, 'Orange'], [60, 'Gold']];
    const body = el('div', { style: 'padding:10px' }, el('div', { text: 'Choose a color scheme for the Messenger windows:', style: 'margin-bottom:8px' }));
    for (const [h, n] of sw) { const r = el('label', { style: 'display:flex;gap:8px;align-items:center;padding:3px;cursor:pointer' }, el('input', { type: 'radio', name: 'th', checked: (S().settings.hue || 0) === h, onchange: () => saveSettings({ hue: h }) }), el('span', { style: `display:inline-block;width:34px;height:16px;border:1px solid #555;background:hsl(${220 + h},65%,60%)` }), n); body.append(r); }
    pageWin({ title: 'Color Scheme', width: 300, body, buttons: [{ label: 'Close', primary: true }] });
  };
  P.fontDialog = async function () {
    const s = S().settings; const fonts = ['', 'Tahoma', 'Arial', 'Verdana', 'Georgia', 'Times New Roman', 'Courier New', 'Comic Sans MS', 'Trebuchet MS'];
    const r = await dialog({ title: 'Change Font', rows: [{ key: 'fontFamily', label: 'Font:', type: 'select', options: fonts.map((f) => ({ value: f, label: f || '(default)' })), value: s.fontFamily }, { key: 'fontPx', label: 'Size (px):', type: 'number', min: 8, max: 40, value: s.fontPx }, { key: 'fontColor', label: 'Color:', type: 'color', value: s.fontColor || '#000000' }, { key: 'bold', type: 'checkbox', label: 'Bold', value: s.bold }, { key: 'italic', type: 'checkbox', label: 'Italic', value: s.italic }] });
    if (r) { await saveSettings({ fontFamily: r.fontFamily, fontPx: Math.max(8, Math.min(40, Number(r.fontPx) || 13)), fontColor: r.fontColor === '#000000' ? '' : r.fontColor, bold: r.bold, italic: r.italic }); A.hooks.styleChanged && A.hooks.styleChanged(); }
  };
  P.emoticons = function () {
    const list = [...(S().assets.emoticons || [])]; const holder = el('div', { style: 'height:200px;overflow:auto;border:1px solid #7f9db9;background:#fff;margin-bottom:8px' }); let selI = null;
    const draw = () => holder.replaceChildren(table(['Picture', 'Shortcut'], list.map((e, i) => ({ i, cells: [el('img', { src: e.dataUrl, style: 'height:22px' }), e.shortcut] })), { onSelect: (r) => { selI = r.i; }, empty: 'No custom emoticons yet. Click Add.' })); draw();
    const body = el('div', { style: 'padding:8px' }, el('div', { text: 'Type a shortcut (for example :party:) in a message and it is replaced with the picture.', style: 'margin-bottom:6px' }), holder);
    pageWin({ title: 'My Emoticons', width: 400, body, buttons: [
      { label: 'Add...', onClick: async () => { const [f] = await A.pickFile('image/*'); if (!f) return false; const r = await dialog({ title: 'New Emoticon', rows: [{ key: 's', label: 'Shortcut:', value: ':' + f.name.replace(/\.\w+$/, '').replace(/\W/g, '').slice(0, 10) + ':' }] }); if (!r || r.s.trim().length < 2) return false; list.push({ shortcut: r.s.trim(), dataUrl: await A.resizeImage(f, 40, 'image/png') }); await saveAssets({ emoticons: list }); draw(); return false; } },
      { label: 'Delete', onClick: async () => { if (selI == null) { toast('Select an emoticon first.'); return false; } list.splice(selI, 1); selI = null; await saveAssets({ emoticons: list }); draw(); return false; } },
      { label: 'Close', primary: true }] });
  };
  let WINKS = null;
  P.winks = async function (onSend) {
    if (!WINKS) WINKS = await (await fetch('assets/winks/index.json')).json();
    const body = el('div', { style: 'padding:8px' }, el('div', { style: 'margin-bottom:6px', text: onSend ? 'Pick a wink to send:' : 'Your winks (animations need Flash, which browsers no longer support, so they play as stickers):' })); const grid = el('div', { style: 'display:grid;grid-template-columns:repeat(5,1fr);gap:8px' });
    let w; for (const k of WINKS) { const c = el('div', { style: 'text-align:center;cursor:pointer;font-size:8pt;padding:3px;border:1px solid transparent' }, el('img', { src: `assets/winks/${k.id}.png`, style: 'width:60px;height:60px;object-fit:contain' }), el('div', { text: k.name })); c.onmouseenter = () => { c.style.border = '1px solid #316ac5'; }; c.onmouseleave = () => { c.style.border = '1px solid transparent'; }; c.onclick = () => { if (onSend) { w.close(); onSend(k); } }; grid.append(c); }
    body.append(grid); w = pageWin({ title: 'My Winks', width: 440, body, buttons: [{ label: 'Close', primary: true }] });
  };

  // ====================== audio / video ======================
  P.avSetup = function (mode, onSnapshot) {
    A.sound(mode === 'webcam' ? 'ring' : 'phone');
    const body = el('div', { style: 'padding:10px;display:flex;flex-direction:column;gap:8px' }); let stream = null, ctx = null, raf = 0;
    const msg = el('div', { style: 'color:#555', text: 'Devices are only accessed when you press a Test button, and nothing is recorded or sent anywhere.' });
    const camSel = el('select'), micSel = el('select'); const video = el('video', { autoplay: true, muted: true, playsInline: true, style: 'width:100%;max-height:220px;background:#000;display:none' }); const meter = el('div', { style: 'height:12px;border:1px solid #7f9db9;background:#fff' }, el('div', { style: 'height:100%;width:0;background:#4caf50' }));
    const stop = () => { cancelAnimationFrame(raf); if (stream) stream.getTracks().forEach((t) => t.stop()); stream = null; if (ctx) ctx.close().catch(() => {}); ctx = null; video.style.display = 'none'; };
    async function devices() { try { const d = await navigator.mediaDevices.enumerateDevices(); camSel.replaceChildren(...d.filter((x) => x.kind === 'videoinput').map((x) => el('option', { value: x.deviceId, text: x.label || 'Camera' }))); micSel.replaceChildren(...d.filter((x) => x.kind === 'audioinput').map((x) => el('option', { value: x.deviceId, text: x.label || 'Microphone' }))); } catch (e) {} }
    async function get(c) { if (!navigator.mediaDevices) throw new Error('This browser does not allow device access here.'); stop(); stream = await navigator.mediaDevices.getUserMedia(c); await devices(); return stream; }
    const testMic = async () => { try { await get({ audio: micSel.value ? { deviceId: micSel.value } : true }); ctx = new AudioContext(); const an = ctx.createAnalyser(); an.fftSize = 512; ctx.createMediaStreamSource(stream).connect(an); const buf = new Uint8Array(an.fftSize); const tick = () => { an.getByteTimeDomainData(buf); let m = 0; for (const v of buf) m = Math.max(m, Math.abs(v - 128)); meter.firstChild.style.width = Math.min(100, m * 1.6) + '%'; raf = requestAnimationFrame(tick); }; tick(); msg.textContent = 'Speak into the microphone - the bar should move.'; } catch (e) { msg.textContent = 'Microphone error: ' + e.message; } };
    const testCam = async () => { try { await get({ video: camSel.value ? { deviceId: camSel.value } : true }); video.srcObject = stream; video.style.display = 'block'; msg.textContent = 'Camera is working.'; } catch (e) { msg.textContent = 'Camera error: ' + e.message; } };
    const testSpk = () => { A.sound('ring'); const a = new Audio('assets/sounds/ring.wav'); a.play().catch(() => {}); msg.textContent = 'Playing the ring sound...'; };
    body.append(msg);
    if (mode !== 'webcam') body.append(el('div', null, 'Speakers: ', el('button', { class: 'btn', text: 'Test speakers', onclick: testSpk })), el('div', null, 'Microphone:'), micSel, meter, el('div', null, el('button', { class: 'btn', text: 'Test microphone', onclick: testMic })));
    if (mode !== 'audio') body.append(el('div', null, 'Camera:'), camSel, video, el('div', null, el('button', { class: 'btn', text: 'Test camera', onclick: testCam })));
    const buttons = [];
    if (mode !== 'audio') buttons.push({ label: onSnapshot ? 'Attach Snapshot' : 'Use as Display Picture', onClick: async () => { if (!stream || !video.videoWidth) { toast('Start the camera first.'); return false; } const c = document.createElement('canvas'); c.width = video.videoWidth; c.height = video.videoHeight; c.getContext('2d').drawImage(video, 0, 0); const url = c.toDataURL('image/jpeg', .85); if (onSnapshot) onSnapshot(url); else { await saveAssets({ avatar: await A.resizeImage(url, 96) }); await refresh(); toast('Display picture updated.'); } } });
    buttons.push({ label: 'Close', primary: true });
    pageWin({ title: mode === 'webcam' ? 'Webcam Settings' : 'Audio and Video Setup', width: 400, body, buttons, onClose: stop });
  };

  // ====================== activities / games ======================
  const ACTIVITIES = [
    ['Summarize text', 'Summarize the following text in five bullet points:\n\n'], ['Translate', 'Translate the following into English and explain any idioms:\n\n'], ['Explain code', 'Explain what this code does, step by step, and point out any bugs:\n\n'],
    ['Proofread', 'Proofread the following. Show the corrected version and list what you changed:\n\n'], ['Write an e-mail', 'Help me write a clear, friendly e-mail. Ask me what it should say first.'], ['Brainstorm ideas', 'Let\'s brainstorm. Give me 10 creative ideas about: '],
    ['Study buddy', 'Quiz me on a topic of my choice, one question at a time, and tell me whether I was right. Ask me which topic first.'] ];
  const GAMES = [
    ['20 Questions', 'Let\'s play 20 Questions. I\'m thinking of something; you ask yes/no questions to guess it. Start with your first question.'], ['Trivia', 'Let\'s play trivia. Ask me one multiple-choice question at a time, keep score, and make it progressively harder.'],
    ['Word association', 'Let\'s play word association. I say a word, you reply with one related word, and we keep going. Start with "ocean".'], ['Story builder', 'Let\'s write a story together. You write two sentences, then I write two, and so on. Start with something mysterious.'],
    ['Tic-tac-toe', 'Let\'s play tic-tac-toe. Draw the board in a code block using numbers 1-9 and let me go first.'] ];
  P.activities = function (kind) {
    const list = kind === 'games' ? GAMES : ACTIVITIES; const cs = S().contacts.filter((c) => !c.blocked);
    const body = el('div', { style: 'padding:8px' }); const sel = el('select', { style: 'width:100%;margin-bottom:6px' }); cs.forEach((c) => sel.append(el('option', { value: c.id, text: c.name })));
    const box = el('div', { style: 'height:180px;overflow:auto;border:1px solid #7f9db9;background:#fff' }); let chosen = null;
    box.append(table([kind === 'games' ? 'Game' : 'Activity'], list.map(([n, p]) => ({ cells: [n], p, onDbl: () => go(p) })), { onSelect: (r) => { chosen = r.p; } }));
    function go(p) { if (!sel.value) return toast('Add a contact first.'); w.close(); A.hooks.openConv(sel.value, { prefill: p }); }
    body.append(el('div', { text: 'Play with:' }), sel, box); const w = pageWin({ title: kind === 'games' ? 'Play a Game' : 'Start an Activity', width: 360, body, buttons: [{ label: 'Start', primary: true, onClick: () => { if (!chosen) { toast('Pick one first.'); return false; } go(chosen); return false; } }, { label: 'Cancel' }] });
  };

  // ====================== logs / files ======================
  P.alerts = async function () {
    const l = await API.alerts();
    pageWin({ title: 'Alerts History', width: 520, height: 330, body: el('div', { style: 'padding:6px;height:100%' }, table(['When', 'Contact', 'Event'], l.map((a) => ({ cells: [new Date(a.t).toLocaleString(), a.contact || '', a.kind === 'error' ? 'Error: ' + a.text : a.text] })), { empty: 'No alerts yet.' })), buttons: [{ label: 'Clear', onClick: async () => { await API.clearAlerts(); toast('Alerts cleared.'); } }, { label: 'Close', primary: true }] });
  };
  P.received = async function () {
    let list = await API.received(); let selName = null; const holder = el('div', { style: 'padding:6px;height:100%' });
    const draw = () => holder.replaceChildren(table(['File', 'Size', 'Saved'], list.map((f) => ({ name: f.name, cells: [f.name, (f.size / 1024).toFixed(1) + ' KB', new Date(f.t).toLocaleString()], onDbl: () => open(f.name) })), { onSelect: (r) => { selName = r.name; }, empty: 'No received files. Files you save (File > Save) are kept here.' })); draw();
    const open = async (n) => A.download(n, await API.downloadReceived(n));
    pageWin({ title: 'Received Files', width: 540, height: 330, body: holder, buttons: [{ label: 'Download', onClick: () => { if (!selName) { toast('Select a file.'); return false; } open(selName); return false; } }, { label: 'Delete', onClick: async () => { if (!selName) { toast('Select a file.'); return false; } await API.deleteReceived(selName); list = await API.received(); selName = null; draw(); return false; } }, { label: 'Close', primary: true }] });
  };

  // ====================== options ======================
  P.options = async function (tab0) {
    const s = { ...S().settings }; const prof = { name: S().profile.name, psm: S().profile.psm || '' };
    const ses = await API.session(); const me = ses.profiles.find((p) => p.id === S().profileId) || {}; let autoSign = ses.auto === S().profileId;
    const tabs = ['Personal', 'General', 'Sounds', 'Messages', 'Contacts', 'Privacy', 'Connection']; const pane = el('div', { style: 'padding:10px;min-height:250px' }); const bar = el('div', { class: 'tabs' });
    const chk = (key, label, obj = s) => el('label', { style: 'display:flex;gap:6px;align-items:center;margin:4px 0' }, el('input', { type: 'checkbox', checked: !!obj[key], onchange: (e) => { obj[key] = e.target.checked; } }), label);
    const field = (label, obj, key, type = 'text') => el('label', { style: 'display:block;margin:6px 0' }, label, el('br'), el('input', { type, value: obj[key] || '', style: 'width:100%', oninput: (e) => { obj[key] = e.target.value; } }));
    const sel = (label, key, opts) => el('label', { style: 'display:block;margin:6px 0' }, label + ' ', el('select', { onchange: (e) => { s[key] = e.target.value; } }, ...opts.map(([v, t]) => el('option', { value: v, text: t, selected: s[key] === v }))));
    const views = {
      Personal: () => [field('Display name:', prof, 'name'), field('Personal message:', prof, 'psm'), el('div', { style: 'margin:8px 0' }, el('button', { class: 'btn', text: 'Change Display Picture...', onclick: () => P.displayPicture() }), ' ', el('button', { class: 'btn', text: me.locked ? 'Change / remove password...' : 'Set a password...', onclick: async () => { const r = await dialog({ title: 'Profile password', rows: [{ html: 'A password is only checked when signing in on this computer.' }, ...(me.locked ? [{ key: 'old', label: 'Current password:', type: 'password' }] : []), { key: 'pw', label: 'New password (blank removes):', type: 'password' }] }); if (!r) return; try { const o = await API.setPassword({ old: r.old, password: r.pw }); me.locked = o.locked; toast(o.locked ? 'Password set.' : 'Password removed.'); } catch (e) { toast(e.message); } } }))],
      General: () => [chk('sounds', 'Play sounds'), chk('soundOnReply', 'Play a sound when a reply arrives'), chk('readAloud', 'Read replies aloud (uses your system voice, offline)'), el('label', { style: 'display:flex;gap:6px;align-items:center;margin:4px 0' }, el('input', { type: 'checkbox', checked: autoSign, onchange: (e) => { autoSign = e.target.checked; } }), 'Sign me in automatically on startup'), el('div', { style: 'margin-top:10px' }, el('button', { class: 'btn', text: 'Color Scheme...', onclick: () => P.themes() }), ' ', el('button', { class: 'btn', text: 'Audio and Video Setup...', onclick: () => P.avSetup() }))],
      Sounds: () => [chk('sounds', 'Play sounds'), chk('soundOnReply', 'Play a sound when a reply arrives'), el('div', { style: 'margin:6px 0 4px', text: 'The original MSN Messenger 7.5 sounds (click Play to preview):' }),
        ...[['newalert', 'New message (window in background)'], ['type', 'Reply arrived (window in focus)'], ['online', 'Signed in / contact joined / download finished'], ['nudge', 'Nudge'], ['ring', 'Incoming call / video'], ['phone', 'Voice call'], ['newemail', 'Message could not be delivered'], ['vimdone', 'File saved / download finished']]
          .map(([n, d]) => el('div', { style: 'display:flex;gap:8px;align-items:center;margin:2px 0' }, el('button', { class: 'btn', text: 'Play', style: 'min-width:46px;padding:1px 8px', onclick: () => { const a = new Audio(`assets/sounds/${n}.wav`); a.volume = .8; a.play().catch(() => {}); } }), el('span', { text: d })))],
      Messages: () => [chk('timestamps', 'Show the time before each message'), chk('enterSends', 'Press Enter to send (otherwise Ctrl+Enter)'), el('div', { style: 'margin:8px 0' }, el('button', { class: 'btn', text: 'Change Font...', onclick: () => P.fontDialog() }), ' ', el('button', { class: 'btn', text: 'My Backgrounds...', onclick: () => P.backgrounds() }), ' ', el('button', { class: 'btn', text: 'My Emoticons...', onclick: () => P.emoticons() }))],
      Contacts: () => [sel('Display pictures:', 'pictures', [['large', 'Large'], ['small', 'Small'], ['none', 'None']]), sel('Sort contacts by:', 'sortBy', [['status', 'Online / offline status'], ['groups', 'Groups']]), sel('Show contacts by:', 'labelBy', [['name', 'Display name'], ['model', 'Model name']])],
      Privacy: () => { const blocked = S().contacts.filter((c) => c.blocked); const l = el('div', null, el('b', { text: 'Blocked contacts' }), ...(blocked.length ? blocked.map((c) => el('div', null, c.name + ' ', el('a', { href: '#', text: 'Unblock', style: 'color:#0645ad', onclick: async (e) => { e.preventDefault(); await API.saveContact({ ...c, blocked: false, config: c.config }); await refresh(); e.target.parentNode.remove(); } }))) : [el('div', { text: 'None', style: 'color:#888' })])); return [l, el('div', { style: 'margin:10px 0' }, el('button', { class: 'btn', text: 'Delete all message history', onclick: async () => { if (await confirmBox('Delete history', 'Delete the history of every conversation?', 'Delete')) { for (const c of S().contacts) await API.clearHistory(c.id); toast('All history deleted.'); } } })), el('div', { html: `Your data lives in <code>${esc(S().dataDir)}</code> (profile <code>${esc(S().profileId)}</code>). Nothing is sent anywhere except to the AI endpoint of the contact you are chatting with.`, style: 'color:#444;line-height:1.4' })]; },
      Connection: () => [el('div', { style: 'line-height:1.5', html: `<b>MSN servers:</b> not used. This edition never connects to MSN, Passport or Hotmail.<br><b>Local server:</b> 127.0.0.1 only, random per-launch token.<br><b>AI providers installed:</b><ul>${S().providers.map((p) => `<li>${esc(p.name)}</li>`).join('')}</ul>Add more by dropping a <code>.js</code> file into <code>${esc(S().dataDir)}/plugins</code>.` })],
    };
    let cur = tab0 || 'Personal';
    const show = (t) => { cur = t; [...bar.children].forEach((b) => b.classList.toggle('on', b.textContent === t)); pane.replaceChildren(...views[t]()); };
    tabs.forEach((t) => bar.append(el('div', { class: 'tab', text: t, onclick: () => show(t) }))); show(cur);
    pageWin({ title: 'Options', width: 520, body: el('div', null, bar, pane), buttons: [{ label: 'OK', primary: true, onClick: async () => {
      const patch = { ...s }; await saveSettings(patch);
      if (prof.name !== S().profile.name || prof.psm !== S().profile.psm) S().profile = await API.profile({ name: prof.name.trim() || S().profile.name, psm: prof.psm });
      if (autoSign !== (ses.auto === S().profileId)) { try { await API.signIn({ id: S().profileId, password: autoSign && me.locked ? ((await dialog({ title: 'Confirm password', rows: [{ key: 'p', label: 'Password:', type: 'password' }] })) || {}).p : '', makeDefault: autoSign }); } catch (e) { toast(e.message); } }
      await refresh(); } }, { label: 'Cancel' }] });
  };

  // ====================== help ======================
  P.help = function () {
    pageWin({ title: 'AI Messenger Help', width: 520, height: 420, body: section(`<h3>Getting started</h3><p>Choose <b>File &gt; Add a Contact (or the + next to Models)</b> and pick a provider (OpenAI-compatible, Anthropic or your own plug-in). Local models such as Ollama need no key.</p>
      <h3>Chatting</h3><p>Double-click a contact. <b>Enter</b> sends, <b>Shift+Enter</b> adds a line, <b>Esc</b> stops a reply. Attach images or files with <b>Actions &gt; Send a File or Photo</b>, drag-and-drop or paste.</p>
      <h3>Group chats</h3><p><b>Actions &gt; Invite a Contact to Join This Conversation</b> adds another AI. Every reply is shown with the speaker's name.</p>
      <h3>Nudge, winks and emoticons</h3><p>The nudge shakes the window and plays the original sound. Winks are sent as stickers; custom emoticons live in Tools &gt; My Emoticons.</p>
      <h3>Offline edition</h3><p>Windows Live / MSN services (Hotmail, mobile messaging, MSN Direct, remote assistance, always-on-top) need servers or the original program and are replaced by local equivalents or are marked unavailable.</p>
      <h3>Profiles</h3><p>Sign Out returns to the sign-in screen where you can pick or create another local profile. Each profile has its own contacts, history and settings.</p>`), buttons: [{ label: 'Close', primary: true }] });
  };
  P.about = function () {
    info('About AI Messenger', `<div style="padding:12px;line-height:1.5"><div style="font-size:14pt;font-weight:bold;color:#003399">AI Messenger 0.3.26</div>A local, offline-first AI chat client with the classic MSN Messenger 7.5 interface.<br><br>Interface resources &copy; Microsoft Corporation (extracted for personal use). The layout engine and all behavior are new code.<br><br>No telemetry. No MSN servers. Data folder:<br><code>${esc(S().dataDir)}</code></div>`);
  };
  P.signInHelp = () => info('Sign in', '<div style="padding:12px">Profiles are local to this computer. There is no password recovery because nothing is stored online. If you forget a profile password, remove the profile with "Forget me".</div>');

  g.Pages = P; A.P = P;
})(window);
