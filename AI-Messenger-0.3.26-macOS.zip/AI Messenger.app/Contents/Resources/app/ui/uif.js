/* uif.js - runtime for Microsoft DirectUI ".uif" layout files (as shipped in MSN Messenger 7.5).
 * Parses the original XML-ish markup + style sheets and builds a live DOM from it.
 * The layouts, images and strings are the original resources; only the engine is new.
 */
(function (g) {
  'use strict';
  const SYS = { window: '#ffffff', windowtext: '#000000', buttonface: '#ece9d8', buttontext: '#000000', buttonshadow: '#aca899',
    captiontext: '#ffffff', scrollbar: '#d4d0c8', graytext: '#aca899', highlight: '#316ac5', highlighttext: '#ffffff', menu: '#ffffff',
    threedlightshadow: '#f1efe2', black: '#000000', white: '#ffffff', infobackground: '#ffffe1', infotext: '#000000', hotlight: '#0000ff' };
  const FONT_MAP = { 'ms shell dlg 2': 'Tahoma, "Segoe UI", Verdana, sans-serif', 'ms shell dlg': 'Tahoma, "Segoe UI", Verdana, sans-serif' };

  // Several resource sets (one per MSN version) can be loaded; a node is always built with the images and strings of the set it came from.
  const sets = {}; let curSet = '7.5'; const BASE = '7.5';
  let strings = new Proxy({}, { get: (_, k) => { const a = sets[curSet] && sets[curSet].strings; const b = sets[BASE] && sets[BASE].strings; return a && a[k] != null ? a[k] : b ? b[k] : undefined; } });
  const registry = { styles: {}, roots: {} };
  const handlers = { cmd: null };
  let imgBase = 'assets/img/';

  // ---------- value language ----------
  function splitArgs(s) {
    const out = []; let d = 0, cur = '', q = false;
    for (const ch of s) {
      if (ch === '"') q = !q;
      if (!q) { if (ch === '(') d++; else if (ch === ')') d--; else if (ch === ',' && d === 0) { out.push(cur); cur = ''; continue; } }
      cur += ch;
    }
    out.push(cur);
    return out.map((x) => x.trim());
  }
  function val(s) {
    if (s == null) return '';
    if (typeof s !== 'string') return s;
    s = s.trim();
    const m = /^([A-Za-z_][A-Za-z0-9_]*)\((.*)\)(.*)$/s.exec(s);
    if (m) {
      const fn = m[1].toLowerCase(); const a = splitArgs(m[2]); const suf = m[3] || '';
      let r;
      switch (fn) {
        case 'ifhc': r = val(a[1]); break;
        case 'rcstr': r = strings[a[0]] != null ? strings[a[0]] : ''; break;
        case 'rcint': r = strings[a[0]] != null ? Number(strings[a[0]]) : 0; break;
        case 'rgb': r = `rgb(${a.map((x) => parseInt(x, 10)).join(',')})`; break;
        case 'argb': r = `rgba(${parseInt(a[1], 10)},${parseInt(a[2], 10)},${parseInt(a[3], 10)},${(parseInt(a[0], 10) / 255).toFixed(3)})`; break;
        case 'gradient': r = `linear-gradient(${String(val(a[2])) === '1' ? 'to right' : 'to bottom'},${val(a[0])},${val(a[1])})`; break;
        case 'rect': r = a.map((x) => parseInt(val(x), 10) || 0); break;
        case 'atom': case 'styleref': r = a[0]; break;
        case 'rcbmp': r = `url(${imgBase}bmp_${a[0]}.bmp)`; break;
        case 'sysmetric': r = -1; break;
        case 'sysmetricstr': r = 'Tahoma'; break;
        case 'point': case 'size': r = a.map((x) => parseInt(x, 10)); break;
        default: r = s; suf && (r = s + suf); return r;
      }
      return suf && typeof r !== 'object' ? String(r) + suf : r;
    }
    if (/^-?\d+(\.\d+)?$/.test(s)) return Number(s);
    if (s[0] === '"' && s[s.length - 1] === '"') return s.slice(1, -1);
    if (SYS[s.toLowerCase()]) return SYS[s.toLowerCase()];
    return s;
  }

  // ---------- parsing ----------
  function parseAttrs(src, i) {
    const attrs = {};
    for (;;) {
      while (i < src.length && /\s/.test(src[i])) i++;
      if (src[i] === '>' || (src[i] === '/' && src[i + 1] === '>') || i >= src.length) break;
      let k = ''; while (i < src.length && /[A-Za-z0-9_:\-]/.test(src[i])) k += src[i++];
      if (!k) { i++; continue; }
      let v = '';
      if (src[i] === '=') {
        i++;
        if (src[i] === '"') { i++; while (i < src.length && src[i] !== '"') v += src[i++]; i++; }
        else {
          let d = 0;
          while (i < src.length) {
            const ch = src[i];
            if (ch === '(') d++; else if (ch === ')') d--;
            else if (d <= 0 && (/\s/.test(ch) || ch === '>' || (ch === '/' && src[i + 1] === '>'))) break;
            v += ch; i++;
          }
        }
      }
      attrs[k.toLowerCase()] = v;
    }
    return { attrs, i };
  }
  function parseNodes(src) {
    let i = 0; const roots = [];
    function parseOne() { // at '<'
      i++;
      let name = ''; while (i < src.length && /[A-Za-z0-9_]/.test(src[i])) name += src[i++];
      const pa = parseAttrs(src, i); i = pa.i;
      const node = { tag: name.toLowerCase(), attrs: pa.attrs, kids: [] };
      if (src[i] === '/') { i += 2; return node; }
      i++; // '>'
      if (node.tag === 'style') { // raw body
        const end = src.toLowerCase().indexOf('</style>', i);
        node.css = src.slice(i, end < 0 ? src.length : end); i = end < 0 ? src.length : end + 8; return node;
      }
      for (;;) {
        const lt = src.indexOf('<', i);
        if (lt < 0) { i = src.length; return node; }
        if (src.startsWith('<!--', lt)) { const e = src.indexOf('-->', lt); i = e < 0 ? src.length : e + 3; continue; }
        if (src[lt + 1] === '/') { const gt = src.indexOf('>', lt); i = gt + 1; return node; }
        i = lt; node.kids.push(parseOne());
      }
    }
    for (;;) {
      const lt = src.indexOf('<', i); if (lt < 0) break;
      if (src.startsWith('<!--', lt)) { const e = src.indexOf('-->', lt); i = e < 0 ? src.length : e + 3; continue; }
      i = lt; roots.push(parseOne());
    }
    return roots;
  }
  function parseSelector(sel) {
    sel = sel.trim(); let i = 0; let tag = '';
    while (i < sel.length && /[A-Za-z0-9_]/.test(sel[i])) tag += sel[i++];
    const conds = [];
    while (sel[i] === '[') { const e = sel.indexOf(']', i); const c = sel.slice(i + 1, e); i = e + 1;
      const eq = c.indexOf('='); conds.push(eq < 0 ? { k: c.trim().toLowerCase() } : { k: c.slice(0, eq).trim().toLowerCase(), v: String(val(c.slice(eq + 1))).toLowerCase() }); }
    return { tag: tag.toLowerCase(), conds };
  }
  function parseStyle(css) {
    const rules = []; const re = /([^{}]+)\{([^{}]*)\}/g; let m;
    while ((m = re.exec(css))) {
      const props = {};
      for (const decl of m[2].split(';')) { const c = decl.indexOf(':'); if (c > 0) props[decl.slice(0, c).trim().toLowerCase()] = decl.slice(c + 1).trim(); }
      for (const s of m[1].split(',')) if (s.trim()) rules.push({ sel: parseSelector(s), props });
    }
    return rules;
  }
  function addFile(text, setId) {
    for (const n of parseNodes(text)) {
      const rid = n.attrs.resid && n.attrs.resid.toLowerCase();
      if (!rid) continue;
      n._set = setId || BASE;
      if (n.tag === 'style') (registry.styles[rid] = registry.styles[rid] || {})[n._set] = parseStyle(n.css); else registry.roots[rid] = n;
    }
  }

  // ---------- style application ----------
  const STATE = { mousefocused: ':hover', pressed: ':active', keyfocused: ':focus-within', selected: '.sel', default: '.def', mouse: ':hover' };
  let ruleCss = [], ruleCount = 0, propCache = new Map(), styleEl = null;
  function emit(css) { ruleCss.push(css); if (!styleEl) { styleEl = document.createElement('style'); document.head.appendChild(styleEl); } flush(); }
  let flushT = 0; function flush() { if (flushT) return; flushT = setTimeout(() => { flushT = 0; styleEl.textContent += ruleCss.join('\n'); ruleCss = []; }, 0); }

  const rectCss = (v, order) => Array.isArray(v) ? `${v[1]}px ${v[2]}px ${v[3]}px ${v[0]}px` : '';
  function decls(props) { // computed DUI props -> css declaration string
    let out = '';
    for (const k in props) {
      const v = props[k];
      switch (k) {
        case 'background': if (v === 'none' || v === '') break;
          out += typeof v === 'string' && v.startsWith('url(') ? `background:${v} 0 0/100% 100% no-repeat;` : `background:${v};`; break;
        case 'foreground': out += `color:${v};`; break;
        case 'fontface': out += `font-family:"${v}",${FONT_MAP[String(v).toLowerCase()] || 'Tahoma,Verdana,sans-serif'};`; if (FONT_MAP[String(v).toLowerCase()]) out = out.replace(`"${v}",`, ''); break;
        case 'fontsize': if (typeof v === 'string' && /pt|px/.test(v)) out += `font-size:${v};`; break;
        case 'fontweight': out += `font-weight:${v};`; break;
        case 'borderthickness': if (Array.isArray(v)) out += `border-style:solid;border-color:transparent;border-width:${rectCss(v)};`; break;
        case 'bordercolor': out += `border-color:${v};`; break;
        case 'padding': if (Array.isArray(v)) out += `padding:${rectCss(v)};`; break;
        case 'margin': if (Array.isArray(v)) out += `margin:${rectCss(v)};`; break;
        case 'width': if (typeof v === 'number' && v >= 0) out += `width:${v}px;`; break;
        case 'height': if (typeof v === 'number' && v >= 0) out += `height:${v}px;`; break;
        case 'cursor': out += `cursor:${v === 'hand' ? 'pointer' : v === 'ibeam' ? 'text' : 'default'};`; break;
        case 'alpha': out += `opacity:${(Number(v) / 255).toFixed(2)};`; break;
        case 'contentalign': {
          const s = String(v).toLowerCase();
          const vert = s.includes('top') ? 'flex-start' : s.includes('bottom') ? 'flex-end' : 'center';
          const hor = s.includes('right') ? 'flex-end' : s.includes('center') ? 'center' : 'flex-start';
          out += `display:flex;align-items:${vert};justify-content:${hor};`;
          if (s.includes('ellipsis')) out += 'overflow:hidden;';
          break;
        }
        default:
      }
    }
    return out;
  }
  function condStatic(c, node, ctx) {
    switch (c.k) {
      case 'id': return (node.attrs.id ? String(val(node.attrs.id)).toLowerCase() : '') === c.v;
      case 'class': return (node.attrs.class || '').toLowerCase().split(/\s+/).includes(c.v);
      case 'vertical': return /vertical/.test(node.attrs.orientationstyle || '') || node.attrs.orientationstyle === '1';
      default: return null; // not static
    }
  }
  function computeProps(node, sheetRules) {
    const props = {}; const stateRules = [];
    for (const r of sheetRules) {
      if (r.sel.tag !== 'element' && r.sel.tag !== node.tag) continue;
      let ok = true; const st = [];
      for (const c of r.sel.conds) {
        const s = condStatic(c, node);
        if (s === true) continue;
        if (s === false) { ok = false; break; }
        if (c.k === 'enabled' && c.v === 'false') { st.push('.dis'); continue; }
        if (c.k === 'enabled' && (c.v == null || c.v === 'true')) continue; // enabled is the normal state
        if (STATE[c.k] && c.v == null) { st.push(STATE[c.k]); continue; }
        ok = false; break; // unsupported dynamic condition
      }
      if (!ok) continue;
      if (st.length) stateRules.push({ r, st }); else for (const k in r.props) props[k] = r.props[k];
    }
    return { props, stateRules };
  }
  const SKIP_ATTR = new Set(['id', 'class', 'layout', 'resid', 'sheet', 'idres', 'cmdid', 'accname', 'accdesc', 'accrole', 'accdefaction', 'active', 'colorize', 'blendmode', 'flip', 'isbackground', 'content', 'visible', 'enabled', 'layoutpos', 'selected', 'tooltip', 'shortcut', 'shortcutstring', 'showampersand', 'richeditstyle', 'maxvisiblelines', 'label', 'xscrollable', 'yscrollable']);

  // ---------- building ----------
  function resolveSheet(name) { const e = registry.styles[String(val(name)).toLowerCase()]; return e ? (e[curSet] || e[BASE] || e[Object.keys(e)[0]] || []) : []; }
  function layoutOf(spec) {
    if (!spec) return { name: 'fill', a: [] };
    const m = /^([a-z]+)\((.*)\)$/i.exec(String(spec).trim());
    if (!m) return { name: 'fill', a: [] };
    return { name: m[1].toLowerCase(), a: m[2] ? m[2].split(',').map((x) => parseInt(x, 10)) : [] };
  }
  const POS = { client: 'client', nineclient: 'client', top: 'top', ninetop: 'top', left: 'left', nineleft: 'left', right: 'right', nineright: 'right', bottom: 'bottom', ninebottom: 'bottom', none: 'none' };

  function build(node, sheet) {
    if (node.attrs.sheet) sheet = resolveSheet(node.attrs.sheet);
    const comp = computeProps(node, sheet);
    const props = comp.props;
    const A = node.attrs;
    // attributes override style props
    for (const k in A) if (!SKIP_ATTR.has(k)) props[k] = val(A[k]);
    for (const k of ['visible', 'enabled', 'layout', 'layoutpos', 'content', 'idres', 'isbackground', 'cmdid', 'selected']) if (A[k] != null) props[k] = A[k];
    for (const k in props) if (typeof props[k] === 'string' && k !== 'layout' && k !== 'layoutpos' && k !== 'content' && k !== 'idres' && !(k in A)) props[k] = val(props[k]);

    const id = A.id ? String(val(A.id)) : '';
    const isPng = node.tag === 'png' || node.tag === 'image';
    const hasKids = node.kids.some((k) => k.tag !== 'style');
    const isBox = isPng && hasKids; // a png that holds children is a container that also paints an image
    const bgPng = isPng && !hasKids && String(val(props.isbackground)).toLowerCase() === 'true';
    const el = document.createElement(isPng && !bgPng && !isBox ? 'img' : 'div');
    el.className = `u t-${node.tag}` + (A.class ? ' ' + A.class.replace(/"/g, '').split(/\s+/).map((c) => 'c-' + c.toLowerCase()).join(' ') : '');
    if (id) el.dataset.uid = id;
    if (A.class) el.dataset.cls = A.class.replace(/"/g, '');
    const rawPos = String(val(props.layoutpos || '')).toLowerCase();
    el._raw = rawPos; el._pos = POS[rawPos] || null;
    if (String(props.visible) === 'false') el.style.display = 'none';
    if (String(props.enabled) === 'false') el.classList.add('dis');
    if (A.selected === 'true') el.classList.add('sel');
    if (A.tooltip && A.tooltip !== 'true') el.title = String(val(A.tooltip));

    // image
    if (isPng) {
      const rid = val(props.idres);
      if (rid && rid !== 0 && rid !== '0') {
        const url = imgUrl(rid);
        if (bgPng) {
          const bt = props.borderthickness;
          el.classList.add('bgpng');
          if (Array.isArray(bt) && bt.some((x) => x > 0)) {
            el.style.borderImage = `url(${url}) ${bt[1]} ${bt[2]} ${bt[3]} ${bt[0]} fill / ${bt[1]}px ${bt[2]}px ${bt[3]}px ${bt[0]}px stretch`;
            el.style.borderStyle = 'solid';
            delete props.borderthickness;
          } else el.style.background = `url(${url}) 0 0/100% 100% no-repeat`;
        } else if (isBox) { const bt = props.borderthickness; if (Array.isArray(bt) && bt.some((x) => x > 0) && String(val(props.isbackground)).toLowerCase() === 'true') { el.style.borderImage = `url(${url}) ${bt[1]} ${bt[2]} ${bt[3]} ${bt[0]} fill / ${bt[1]}px ${bt[2]}px ${bt[3]}px ${bt[0]}px stretch`; el.style.borderStyle = 'solid'; delete props.borderthickness; } else { el.style.background = `url(${url}) 0 0/100% 100% no-repeat`; } } else { el.src = url; el.draggable = false; el.alt = ''; }
      }
    }
    // a toolbar row paints its own background strip (e.g. the typing box toolbar's top border and gradient)
    if (!isPng && node.tag === 'mtoolbar' && String(val(props.isbackground)).toLowerCase() === 'true') {
      const rid = val(props.idres);
      if (rid && rid !== 0 && rid !== '0') { el.style.background = `url(${imgUrl(rid)}) 0 0/100% 100% no-repeat`; el.classList.add('bgpng'); }
    }
    // buttons paint their artwork from a stylesheet idres (nine-grid border image); hover / pressed / disabled use other ids
    if (!isPng && node.tag === 'cmdbutton' && Array.isArray(props.borderthickness) && props.borderthickness.some((x) => x > 0)) {
      const rid = val(props.idres); const bt = props.borderthickness;
      if ((rid && rid !== 0 && rid !== '0') || comp.stateRules.some((x) => x.r.props.idres && val(x.r.props.idres) != 0)) {
        el.style.borderImageSlice = `${bt[1]} ${bt[2]} ${bt[3]} ${bt[0]} fill`; el.style.borderImageWidth = `${bt[1]}px ${bt[2]}px ${bt[3]}px ${bt[0]}px`; el.style.borderImageRepeat = 'stretch';
        if (rid && rid !== 0 && rid !== '0') el.style.borderImageSource = `url(${imgUrl(rid)})`;
        el.style.borderStyle = 'solid'; el.style.borderWidth = `${bt[1]}px ${bt[2]}px ${bt[3]}px ${bt[0]}px`; el.style.borderColor = 'transparent'; el.style.background = 'none';
        delete props.borderthickness; delete props.bordercolor; delete props.background; el._btnArt = true;
      }
    }
    // computed css as class + state rules
    const cssText = decls(props);
    if (cssText) {
      let cls = propCache.get(cssText);
      if (!cls) { cls = 'p' + propCache.size; propCache.set(cssText, cls); emit(`.${cls}{${cssText}}`); }
      el.classList.add(cls);
    }
    for (const { r, st } of comp.stateRules) {
      const rp = Object.fromEntries(Object.entries(r.props).map(([k, v]) => [k, val(v)]));
      if (el._btnArt) { delete rp.background; delete rp.borderthickness; delete rp.bordercolor; delete rp.borderstyle; }
      let d = decls(rp);
      if (el._btnArt && rp.idres && rp.idres !== 0 && rp.idres !== '0') d += `;border-image-source:url(${imgUrl(rp.idres)})`;
      if (!d) continue;
      const key = 'S' + st.join('') + d; let cls = propCache.get(key);
      if (!cls) { cls = 'r' + (ruleCount++); propCache.set(key, cls); emit(`.${cls}${st.join('')}{${d}}`); }
      el.classList.add(cls);
    }
    if (bgPng) { if (typeof props.height === 'number') el._minH = props.height; if (typeof props.width === 'number') el._minW = props.width; }

    // content (text)
    if (A.content != null) {
      const t = String(val(A.content));
      if (t) setText(el, t, props);
    }
    if (A.cmdid) { el.dataset.cmd = A.cmdid; el.classList.add('cmd'); }
    if (/button|checkbox|splitbutton/.test(node.tag)) el.tabIndex = 0;

    // children
    if (el.tagName !== 'IMG') {
      const kids = [];
      for (const k of node.kids) { if (k.tag === 'style') continue; const c = build(k, sheet); kids.push(c); }
      arrange(el, layoutOf(props.layout || A.layout), kids, node.tag);
      for (const c of kids) { if (c._minH) el.style.minHeight = c._minH + 'px'; if (c._minW) el.style.minWidth = c._minW + 'px'; }
    }
    return el;
  }
  function setText(el, t, props) {
    const span = document.createElement('span'); span.className = 'tx';
    const amp = /&(.)/.exec(t);
    if (amp) { const i = t.indexOf('&'); span.append(t.slice(0, i)); const u = document.createElement('u'); u.textContent = amp[1]; span.append(u, t.slice(i + 2)); }
    else span.textContent = t;
    el.prepend(span);
  }
  let imap = null; // optional {base, map}: 7.5 image id -> equivalent image of another MSN version (theme re-skin)
  function imgUrl(rid) {
    rid = String(rid);
    if (imap && curSet === BASE && imap.map[rid]) return imap.base + imap.map[rid];
    return `${imgBase}${rid}.png`;
  }
  g.__imgFallback = function (img) { // the originals shipped PNG, GIF and JPG resources under one id space
    const order = ['png', 'gif', 'jpg']; const m = /^(.*\/)(\d+)\.(png|gif|jpg)$/.exec(img.getAttribute('src') || ''); if (!m) return;
    const i = order.indexOf(m[3]) + 1; if (i >= order.length) return; img.src = `${m[1]}${m[2]}.${order[i]}`;
  };

  function arrange(el, L, kids, tag) {
    kids = kids.filter((k) => { if (k._pos === 'none') { k.style.display = 'none'; } return true; });
    const bgs = kids.filter((k) => k.classList.contains('bgpng'));
    if (bgs.length) el.classList.add('hasbg');
    const normal = kids.filter((k) => !k.classList.contains('bgpng'));
    for (const b of bgs) el.append(b);
    if (tag === 'viewer') { el.classList.add('L-fill', 'scroll'); for (const k of normal) { if (/scrollbar/.test(k.className)) k.style.display = 'none'; el.append(k); } return; }
    const n = L.name;
    if (n === 'ninegridlayout') {
      el.classList.add('L-nine');
      for (const k of normal) {
        const r = k._raw || 'nineclient';
        if (r === 'none') { k.style.display = 'none'; el.append(k); continue; }
        const row = /top/.test(r) ? 1 : /bottom/.test(r) ? 3 : 2; const col = /left/.test(r) ? 1 : /right/.test(r) ? 3 : 2;
        k.style.gridRow = row; k.style.gridColumn = col; el.append(k);
      }
      return;
    }
    if (n === 'borderlayout') {
      // DirectUI border layout: each child claims an edge of what is left, in child order.
      let seenClient = false;
      for (const k of normal) { if (!k._pos) k._pos = seenClient ? 'bottom' : 'left'; if (k._pos === 'client') seenClient = true; }
      const vis = normal.filter((k) => { if (k._pos === 'none') { el.append(k); return false; } return true; });
      const list = vis.filter((k) => k._pos !== 'client').concat(vis.filter((k) => k._pos === 'client'));
      const nest = (host, ks) => {
        if (!ks.length) return;
        const k = ks[0];
        const side = k._pos || 'left';
        if (side === 'client') { host.classList.add('L-fill'); for (const c of ks) { c.style.gridArea = ''; host.append(c); } return; }
        const horiz = side === 'left' || side === 'right';
        host.classList.add('L-edge'); host.style.flexDirection = horiz ? 'row' : 'column';
        k.style.flex = '0 0 auto';
        let rest = null;
        if (ks.length > 1) { rest = document.createElement('div'); rest.className = 'u L-rest'; nest(rest, ks.slice(1)); }
        if (side === 'left' || side === 'top') { host.append(k); if (rest) host.append(rest); } else { if (rest) host.append(rest); else if (side === 'right') k.style.marginLeft = 'auto'; else if (side === 'bottom') k.style.marginTop = 'auto'; host.append(k); }
      };
      nest(el, list);
      return;
    }
    if (n === 'flowlayout' || n === 'verticalflowlayout') {
      const vert = n === 'verticalflowlayout';
      el.classList.add(vert ? 'L-vflow' : 'L-flow');
      const a2 = L.a[2];
      el.style.alignItems = a2 === 3 ? 'stretch' : a2 === 1 ? 'center' : (!vert && a2 === 2) ? 'flex-end' : 'flex-start';
      if (L.a[0] === 1 && !vert) el.style.flexWrap = 'wrap';
      for (const k of normal) el.append(k);
      return;
    }
    if (n === 'gridlayout') {
      el.classList.add('L-grid'); el.style.gridTemplateColumns = `repeat(${L.a[0] || 1},1fr)`; el.style.gridTemplateRows = `repeat(${L.a[1] || 1},1fr)`;
      for (const k of normal) el.append(k); return;
    }
    el.classList.add('L-fill'); // filllayout and default
    for (const k of normal) el.append(k);
  }

  // ---------- public ----------
  function create(resid) {
    const n = registry.roots[String(resid).toLowerCase()];
    if (!n) throw new Error('uif resource not found: ' + resid);
    curSet = n._set || BASE; imgBase = (sets[curSet] && sets[curSet].img) || imgBase;
    const pc = curSet, pi = imgBase;
    try { return build(n, []); } finally { curSet = pc; imgBase = pi; }
  }
  // load(files) keeps the old signature (the 7.5 set); loadSet() adds another version's resources on top.
  async function loadSet(id, { dir, files, img, strings: surl }) {
    sets[id] = { img, strings: await (await fetch(surl)).json() };
    const texts = await Promise.all(files.map(async (f) => (await fetch(dir + f)).text()));
    texts.forEach((t) => addFile(t, id));
  }
  const load = (files) => loadSet(BASE, { dir: 'assets/uif/', files, img: 'assets/img/', strings: 'assets/strings.json' }).then(() => { imgBase = sets[BASE].img; });
  document.addEventListener('error', (e) => { if (e.target && e.target.tagName === 'IMG') g.__imgFallback(e.target); }, true);
  g.UIF = { setImageMap: (m) => { imap = m; }, load, loadSet, create, val, str: (id) => strings[id] || '', strings: () => strings, registry, sets };
})(window);
