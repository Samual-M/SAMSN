/* hf.js - "Add a Contact": browse Hugging Face models, download local ones, add online ones.
 * Nothing connects to Hugging Face until the user presses Allow in the consent panel. */
(function (g) {
  'use strict';
  const A = AIM; const { el, pageWin, toast, info, confirmBox } = A; const P = g.Pages;
  const api = (m, p, b) => fetch('/api/hf/' + p, { method: m, headers: { 'X-Token': sessionStorage.getItem('tok') || '', 'Content-Type': 'application/json' }, body: b ? JSON.stringify(b) : undefined })
    .then(async (r) => { const j = await r.json().catch(() => ({})); if (!r.ok) { const e = new Error(j.error || r.statusText); e.code = j.error; throw e; } return j; });
  const num = (n) => n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : n >= 1e3 ? (n / 1e3).toFixed(1) + 'k' : String(n);
  const badge = (t, bg, fg) => el('span', { text: t, style: `background:${bg};color:${fg};border-radius:3px;padding:0 4px;margin-right:3px;font-size:7pt` });

  // "Find models on this computer": scans common folders for GGUF files you already have. Local only.
  P.scanModels = function () {
    return new Promise((resolve) => {
      const root = el('div', { style: 'display:flex;flex-direction:column;height:100%;padding:8px;gap:6px;box-sizing:border-box' });
      const info = el('div', { style: 'font-size:8pt;color:#44608f;line-height:1.35', text: 'Looks for models you already have: those in a running Ollama, and model files (.gguf) in the usual places: the Hugging Face cache, LM Studio, GPT4All, Jan, Downloads, Documents and your models folders. This only talks to programs on this computer; nothing is sent anywhere.' });
      const dir = el('input', { type: 'text', placeholder: 'Another folder to search (full path, optional)', style: 'flex:1;min-width:0', onkeydown: (e) => { if (e.key === 'Enter') scan(); } });
      const go = el('button', { class: 'btn', text: 'Search', onclick: () => scan() });
      const box = el('div', { style: 'flex:1;min-height:120px;overflow:auto;border:1px solid #7f9db9;background:#fff' }); const status = el('div', { style: 'font-size:8pt;color:#6a7ea8', text: '' });
      root.append(info, el('div', { style: 'display:flex;gap:4px' }, dir, go), box, status);
      let items = [], olNote = ''; const checked = new Set();
      const gb = (n) => (n / 1024 ** 3).toFixed(n > 1024 ** 3 ? 1 : 2) + ' GB';
      function draw() {
        box.replaceChildren();
        if (!items.length) return box.append(el('div', { style: 'padding:12px;color:#888;font-style:italic', text: 'No model files found yet. If yours are somewhere else, type that folder above and press Search.' }));
        for (const f of items) {
          const cb = el('input', { type: 'checkbox', style: 'width:auto;flex:none;margin:2px 0 0', checked: checked.has(f.path), disabled: f.added, onchange: () => { cb.checked ? checked.add(f.path) : checked.delete(f.path); upd(); } });
          box.append(el('div', { style: `display:flex;gap:6px;align-items:flex-start;padding:4px 6px;border-bottom:1px solid #eef;cursor:${f.added ? 'default' : 'pointer'};${f.added ? 'opacity:.55' : ''}`, title: f.path, onclick: (e) => { if (!f.added && e.target !== cb) { cb.checked = !cb.checked; cb.onchange(); } } }, cb,
            el('div', { style: 'min-width:0;flex:1' }, el('div', { style: 'font-weight:bold;overflow:hidden;text-overflow:ellipsis;white-space:nowrap', text: f.name + (f.added ? '  (already a contact)' : '') }), el('div', { style: 'font-size:7.5pt;color:#6a7ea8;overflow:hidden;text-overflow:ellipsis;white-space:nowrap', text: `${gb(f.size)}  -  ${f.dir}` }))));
        }
      }
      const upd = () => { addBtn.textContent = checked.size ? `Add selected (${checked.size})` : 'Add selected'; };
      async function scan() {
        status.textContent = 'Searching...'; go.disabled = true; box.replaceChildren(el('div', { style: 'padding:12px;color:#888', text: 'Searching this computer...' }));
        try { const r = await api('GET', 'scan' + (dir.value.trim() ? '?dir=' + encodeURIComponent(dir.value.trim()) : '')); const ol = r.ollama || { models: [] }; items = [...ol.models.map((x) => ({ path: 'ollama:' + x.name, name: x.name.replace(/:latest$/, ''), model: x.name, size: x.size, dir: 'Ollama (' + ol.base + ')', added: x.added, ollama: true })), ...r.found]; olNote = !ol.running && ol.blobs ? ' Ollama models are on this computer, but Ollama is not running: start Ollama and press Search to add them.' : ''; checked.clear(); items.filter((f) => !f.added).forEach((f) => checked.add(f.path)); status.textContent = `${items.length} model${items.length === 1 ? '' : 's'} found.` + olNote; }
        catch (e) { items = []; status.textContent = e.message; }
        go.disabled = false; draw(); upd();
      }
      let addBtn; let added = 0;
      const win = A.pageWin({ title: 'Find models on this computer', width: 600, height: 470, body: root, onClose: () => { A.hooks.refresh && A.hooks.refresh(); resolve(added); }, buttons: [
        { label: 'Add selected', onClick: async () => { if (!checked.size) { toast('Tick the models you want to add.'); return false; } let n = 0, last = ''; for (const f of items.filter((x) => checked.has(x.path))) { try { await (f.ollama ? api('POST', 'addollama', { name: f.model }) : api('POST', 'addfile', { file: f.path, name: f.name })); n++; f.added = true; last = f.name; } catch (e) { toast(f.name + ': ' + e.message); } } checked.clear(); added += n; draw(); upd(); if (n) { toast(n === 1 ? `${last.split('/').pop()} added as an offline contact.` : `${n} models added as offline contacts.`); A.sound('online'); A.hooks.refresh && A.hooks.refresh(); } return false; } },
        { label: 'Close', primary: true }] });
      addBtn = win.footer.querySelector('button'); scan();
    });
  };

  // "Set up local runtime": downloads llama.cpp's llama-server from GitHub after asking.
  P.runtimeSetup = function () {
    return new Promise(async (resolve) => {
      const call = (m, p) => fetch('/api/runtime/' + p, { method: m, headers: { 'X-Token': sessionStorage.getItem('tok') || '', 'Content-Type': 'application/json' }, body: m === 'POST' ? '{}' : undefined });
      let st; try { st = await (await call('GET', 'status')).json(); } catch (e) { toast(e.message); return resolve(false); }
      if (st.found) { A.info('Local runtime', `<div style="padding:12px;line-height:1.4">llama.cpp is already set up:<br><code>${A.esc(st.found)}</code><br><br>Local models will use it automatically.</div>`); return resolve(true); }
      if (!st.supported) { A.info('Local runtime', `<div style="padding:12px;line-height:1.4">There is no ready-made llama.cpp build for ${A.esc(st.platform)}. Install llama.cpp yourself (for example with your package manager or by building it) so that <b>llama-server</b> is on your PATH, or copy it into:<br><code>${A.esc(st.dir)}</code></div>`); return resolve(false); }
      const body = el('div', { class: 'pgtext', style: 'padding:8px;line-height:1.4', html: `<div style="font-weight:bold;font-size:11pt;margin:2px 0 6px;color:#0f2f66">Install llama.cpp?</div><p>Local models need <b>llama-server</b> from the free llama.cpp project. This window can download it for you. Nothing has been sent yet.</p>
        <table class="tbl" style="margin:6px 0"><tbody>
        <tr><td><b>Servers</b></td><td style="white-space:normal">github.com and its release-file network (the list of versions and the download), plus api.github.com (an optional checksum to verify it)</td></tr>
        <tr><td><b>Operated by</b></td><td style="white-space:normal">GitHub, Inc. (Microsoft). The program is published by the llama.cpp project (ggml-org).</td></tr>
        <tr><td><b>Sent</b></td><td style="white-space:normal">An ordinary web request, which includes your IP address. No chats, profile, contacts or model names.</td></tr>
        <tr><td><b>Received</b></td><td style="white-space:normal">A release list, then one archive (about 20-40 MB, CPU version) that is unpacked into <code>${A.esc(st.dir)}</code>. Its checksum is verified when GitHub provides one.</td></tr>
        <tr><td><b>Why</b></td><td style="white-space:normal">Without it, models that run on this computer cannot answer.</td></tr>
        <tr><td><b>If you decline</b></td><td style="white-space:normal">Everything else keeps working. You can install llama.cpp yourself and the app will find it.</td></tr></tbody></table>
        <p>It is the CPU build; if you have a graphics card, you can install a GPU build of llama.cpp yourself instead.</p>` });
      const bar = el('div', { style: 'display:none;height:14px;border:1px solid #7f9db9;background:#fff;margin:6px 8px' }, el('div', { style: 'height:100%;width:0;background:#4a86d8' })); const msg = el('div', { style: 'padding:0 8px 6px;font-size:8pt;color:#44608f;min-height:14px' });
      const root = el('div', {}, body, bar, msg); let running = false, ok = false; let ctrl = null;
      const win = A.pageWin({ title: 'Set up local runtime (llama.cpp)', width: 560, body: root, onClose: () => { ctrl && ctrl.abort(); resolve(ok); }, buttons: [{ label: 'Download and install', primary: true, onClick: async () => {
        if (running) return false; running = true; ctrl = new AbortController(); bar.style.display = 'block'; const fillEl = bar.firstChild; const btn = win.footer.querySelector('.primary'); btn.disabled = true; msg.textContent = 'Connecting...';
        try {
          const r = await fetch('/api/runtime/install', { method: 'POST', headers: { 'X-Token': sessionStorage.getItem('tok') || '', 'Content-Type': 'application/json' }, body: '{}', signal: ctrl.signal }); if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || r.statusText);
          const rd = r.body.getReader(); const dec = new TextDecoder(); let buf = '';
          for (;;) { const { value, done } = await rd.read(); if (done) break; buf += dec.decode(value, { stream: true }); let i; while ((i = buf.indexOf('\n\n')) >= 0) { const line = buf.slice(0, i); buf = buf.slice(i + 2); if (!line.startsWith('data: ')) continue; const o = JSON.parse(line.slice(6));
            if (o.step) msg.textContent = o.step; else if (o.total != null) { fillEl.style.width = (o.total ? Math.round(o.got / o.total * 100) : 0) + '%'; msg.textContent = `Downloading... ${(o.got / 1048576).toFixed(1)} of ${(o.total / 1048576).toFixed(1)} MB`; }
            else if (o.error) throw new Error(o.error); else if (o.done) { ok = true; fillEl.style.width = '100%'; msg.textContent = `Installed llama.cpp ${o.tag}. Local models can answer now.`; A.sound('vimdone'); btn.textContent = 'Done'; btn.disabled = false; btn.onclick = () => win.close(); } } }
        } catch (e) { if (e.name !== 'AbortError') msg.textContent = 'Could not install: ' + e.message; btn.disabled = false; running = false; }
        return false; } }, { label: 'Not now' }] });
    });
  };

  P.hfBrowser = function () {
    return new Promise(async (resolve) => {
      let st; try { st = await api('GET', 'status'); } catch (e) { return toast(e.message); }
      const root = el('div', { style: 'display:flex;flex-direction:column;height:100%;padding:6px;gap:6px;box-sizing:border-box' });
      const win = pageWin({ title: 'Add a Contact - Hugging Face models', width: 680, height: 560, body: root, onClose: () => { A.hooks.refresh && A.hooks.refresh(); resolve(); },
        buttons: [
          { label: 'Find models on this PC...', onClick: async () => { await P.scanModels(); return false; } },
          { label: 'Add manually (any provider)...', onClick: async () => { const c = await P.contactDialog(); if (c) { A.hooks.refresh && await A.hooks.refresh(); toast(`${c.name} added.`); } return false; } },
          { label: 'Hugging Face token...', onClick: async () => { await tokenDialog(); return false; } },
          { label: 'Close', primary: true } ] });

      async function tokenDialog() {
        const r = await A.dialog({ title: 'Hugging Face token', width: 420, rows: [
          { html: '<div style="width:100%;line-height:1.4">Stored only on this computer and sent only to Hugging Face, for gated downloads and online models. Leave empty and press OK to remove it. Create one at huggingface.co/settings/tokens (read access).</div>' },
          { key: 'token', label: 'Token:', type: 'password', value: '' }] });
        if (!r) return; const x = await api('POST', 'token', { token: r.token }); st.hasToken = x.hasToken; toast(x.hasToken ? 'Token saved.' : 'Token removed.'); detail && detail();
      }

      // ---------- consent ----------
      if (!st.consent) {
        root.append(el('div', { class: 'pgtext', style: 'overflow:auto', html:
          `<h3>Connect to Hugging Face?</h3><p>To browse and download models, this window needs to connect to the internet. Nothing has been sent yet.</p>
          <table class="tbl" style="margin:6px 0"><tbody>
          <tr><td><b>Server</b></td><td style="white-space:normal">huggingface.co and its file-download network</td></tr>
          <tr><td><b>Operated by</b></td><td style="white-space:normal">Hugging Face, Inc.</td></tr>
          <tr><td><b>Sent</b></td><td style="white-space:normal">The words you type in the search box, the model you pick, and your normal IP address (as with any website). Your Hugging Face token only if you choose to save one. <b>Never</b> your chats, contacts, profile or name.</td></tr>
          <tr><td><b>Received</b></td><td style="white-space:normal">Model lists and model files you choose to download.</td></tr>
          <tr><td><b>Why</b></td><td style="white-space:normal">Hugging Face is where the models are published.</td></tr>
          <tr><td><b>If you decline</b></td><td style="white-space:normal">Everything else keeps working. You can still add a contact manually with any provider or a model file you already have.</td></tr></tbody></table>
          <p>No analytics or tracking is added by this app. You can turn this off later by choosing Deny when this window asks again.</p>` }));
        win.footer.prepend(el('button', { class: 'btn primary', text: 'Allow connection', onclick: async () => { await api('POST', 'consent', { allow: true }); win.close(); P.hfBrowser().then(resolve); } }));
        return;
      }

      // ---------- browser ----------
      let detail = null;
      const q = el('input', { type: 'text', placeholder: 'Search models (e.g. llama, qwen, mistral)', style: 'flex:1;min-width:0' });
      const kind = el('select', { style: 'width:auto;flex:1;min-width:0' }, el('option', { value: 'local', text: 'Run on this computer (offline)' }), el('option', { value: 'online', text: 'Online (Hugging Face servers)' }), el('option', { value: 'all', text: 'All models' }));
      const use = el('select', { style: 'width:auto;flex:1;min-width:0' }, ...[['', 'Any purpose'], ['coding', 'Coding'], ['reasoning', 'Reasoning & math'], ['chat', 'Chat / assistant'], ['writing', 'Writing & roleplay'], ['multilingual', 'Multilingual']].map(([v, t]) => el('option', { value: v, text: 'For: ' + t })));
      const size = el('select', { style: 'width:auto;flex:1;min-width:0' }, ...[['0', 'Any size'], ['1.5', 'Tiny (up to 1.5B)'], ['4', 'Small (up to 4B)'], ['9', 'Medium (up to 9B)'], ['14', 'Large (up to 14B)'], ['40', 'Very large (up to 40B)']].map(([v, t]) => el('option', { value: v, text: 'Size: ' + t })));
      const sort = el('select', { style: 'width:auto;flex:1;min-width:0' }, el('option', { value: 'biggest', text: 'Best my computer can run' }), el('option', { value: 'trending', text: 'Trending' }), el('option', { value: 'downloads', text: 'Most downloaded' }), el('option', { value: 'likes', text: 'Most liked' }), el('option', { value: 'new', text: 'Newest' }), el('option', { value: 'updated', text: 'Recently updated' }), el('option', { value: 'smallest', text: 'Smallest first' }));
      const S = 'width:auto;flex:1;min-width:0';
      const minSize = el('select', { style: S }, ...[['0', 'Any'], ['1', '1B and up'], ['3', '3B and up'], ['7', '7B and up'], ['13', '13B and up'], ['30', '30B and up']].map(([v, t]) => el('option', { value: v, text: 'Min size: ' + t })));
      const upd = el('select', { style: S }, ...[['0', 'Any time'], ['90', 'last 3 months'], ['180', 'last 6 months'], ['365', 'last year']].map(([v, t]) => el('option', { value: v, text: 'Updated: ' + t })));
      const pop = el('select', { style: S }, ...[['0', 'Any'], ['1000', '1,000+'], ['10000', '10,000+'], ['100000', '100,000+']].map(([v, t]) => el('option', { value: v, text: 'Downloads: ' + t })));
      const chk = (label, on, tip) => { const i = el('input', { type: 'checkbox', checked: on, style: 'width:auto;margin:0;flex:none' }); return [i, el('label', { style: 'display:flex;gap:5px;align-items:center;font-size:8pt;cursor:pointer;white-space:nowrap', title: tip || '' }, i, label)]; };
      const [fits, fitsL] = chk(`Only models that fit this computer (${st.ramGB} GB memory)`, true);
      const [openLic, openL] = chk('Open licences only', false, 'Apache, MIT, Llama, Gemma, Qwen and similar');
      const [noGate, noGateL] = chk('Hide models that need approval', false, 'Gated models need you to accept a licence on Hugging Face first');
      const mk = (label, opts) => el('select', { style: S }, ...opts.map(([v, t]) => el('option', { value: v, text: label + ': ' + t })));
      const task = mk('Task', [['text-generation', 'Text generation'], ['image-text-to-text', 'Image + text to text (vision)'], ['any-to-any', 'Any-to-any'], ['text-to-speech', 'Text to speech'], ['automatic-speech-recognition', 'Speech recognition'], ['feature-extraction', 'Embeddings'], ['translation', 'Translation'], ['summarization', 'Summarization'], ['question-answering', 'Question answering'], ['text-classification', 'Text classification']]);
      const lib = mk('Library', [['', 'Any'], ['gguf', 'GGUF'], ['safetensors', 'Safetensors'], ['transformers', 'Transformers'], ['pytorch', 'PyTorch'], ['mlx', 'MLX'], ['onnx', 'ONNX'], ['jax', 'JAX']]);
      const app = mk('App', [['', 'Any'], ['llama.cpp', 'llama.cpp'], ['lm-studio', 'LM Studio'], ['ollama', 'Ollama'], ['jan', 'Jan'], ['vllm', 'vLLM'], ['mlx-lm', 'MLX LM']]);
      const lang = mk('Language', [['', 'Any'], ['en', 'English'], ['zh', 'Chinese'], ['es', 'Spanish'], ['fr', 'French'], ['de', 'German'], ['ja', 'Japanese'], ['ko', 'Korean'], ['ru', 'Russian'], ['pt', 'Portuguese'], ['it', 'Italian'], ['ar', 'Arabic'], ['hi', 'Hindi']]);
      const lic = mk('Licence', [['', 'Any'], ['apache-2.0', 'Apache 2.0'], ['mit', 'MIT'], ['llama3.1', 'Llama 3.1'], ['llama3.3', 'Llama 3.3'], ['gemma', 'Gemma'], ['cc-by-4.0', 'CC BY 4.0'], ['cc-by-nc-4.0', 'CC BY-NC 4.0'], ['openrail', 'OpenRAIL'], ['other', 'Other']]);
      const prov = mk('Provider', [['', 'Any'], ['groq', 'Groq'], ['novita', 'Novita'], ['cerebras', 'Cerebras'], ['together', 'Together AI'], ['fireworks-ai', 'Fireworks'], ['featherless-ai', 'Featherless AI'], ['nscale', 'Nscale'], ['fal-ai', 'fal']]);
      const go = el('button', { class: 'btn', text: 'Search' });
      const row = (...c) => el('div', { style: 'display:flex;gap:4px;align-items:center' }, ...c);
      const adv = el('div', { style: 'display:none;flex-direction:column;gap:4px' }, row(minSize, upd, pop), row(task, lib, app), row(lang, lic, prov));
      const tgl = el('a', { href: '#', style: 'font-size:8pt;color:#003399;align-self:flex-start', text: 'More filters \u25BE', onclick: (e) => { e.preventDefault(); const o = adv.style.display === 'none'; adv.style.display = o ? 'flex' : 'none'; tgl.textContent = o ? 'Fewer filters \u25B4' : 'More filters \u25BE'; } });
      const more = el('div', { style: 'display:flex;flex-direction:column;gap:4px' }, tgl, adv);
      root.append(el('div', { style: 'display:flex;gap:4px' }, q, go), row(kind, sort), row(use, size), more,
        el('div', { style: 'display:flex;gap:14px;align-items:center;flex-wrap:wrap;padding:2px 2px 0' }, fitsL, openL, noGateL));
      const runtime = el('div', { style: 'font-size:7.5pt;color:#6a7ea8;cursor:pointer', title: st.runtime ? '' : 'Click to set up the local runtime', onclick: () => { if (!st.runtime) P.runtimeSetup(); }, text: st.runtime ? 'Local runtime found: ' + st.runtime : 'Local runtime not found. Downloaded models need llama.cpp\'s "llama-server" on this computer to run (free, offline). Online models do not.' });
      const listBox = el('div', { style: 'flex:1;min-height:90px;overflow:auto;border:1px solid #7f9db9;background:#fff' });
      const detBox = el('div', { style: 'height:230px;overflow:auto;border:1px solid #7f9db9;background:#f6f8fc;padding:6px;box-sizing:border-box;font-size:8pt' });
      root.append(runtime, listBox, detBox);
      const syncFit = () => { fits.disabled = kind.value === 'online'; fitsL.style.opacity = fits.disabled ? .5 : 1; };
      kind.onchange = () => { syncFit(); search(); }; for (const c of [task, lib, app, lang, lic, prov, sort, use, size, minSize, upd, pop, fits, openLic, noGate]) c.onchange = () => search();
      go.onclick = () => search(); q.onkeydown = (e) => { if (e.key === 'Enter') search(); };

      let results = [], sel = null;
      async function search() {
        listBox.replaceChildren(el('div', { style: 'padding:10px;color:#6a7ea8', text: 'Searching Hugging Face...' })); sel = null; detBox.replaceChildren(el('div', { style: 'color:#6a7ea8', text: 'Select a model to see its files and options.' }));
        try { results = await api('GET', `search?q=${encodeURIComponent(q.value.trim())}&kind=${kind.value}&sort=${sort.value}&use=${use.value}&maxb=${size.value}&fits=${fits.checked && kind.value !== 'online' ? 1 : 0}&task=${task.value}&lib=${lib.value}&app=${app.value}&lang=${lang.value}&lic=${lic.value}&prov=${prov.value}&minb=${minSize.value}&days=${upd.value}&mindl=${pop.value}&open=${openLic.checked ? 1 : 0}&nogate=${noGate.checked ? 1 : 0}`); }
        catch (e) { if (e.code === 'consent') { win.close(); return; } listBox.replaceChildren(el('div', { style: 'padding:10px;color:#a00', text: 'Could not reach Hugging Face: ' + e.message })); return; }
        if (!results.length) return listBox.replaceChildren(el('div', { style: 'padding:10px;color:#6a7ea8', text: 'No models found.' }));
        const t = el('table', { class: 'tbl' }); t.append(el('thead', null, el('tr', null, ...['Model', 'Size', 'Downloads', 'Likes', 'Updated', 'Licence', 'Works'].map((h) => el('th', { text: h })))));
        const tb = el('tbody');
        for (const r of results) {
          const tr = el('tr'); const w = el('td');
          if (r.gguf) w.append(r.fits === false ? badge('too big for this PC', '#f3d6d6', '#800') : badge('offline', '#dcefd9', '#164'));
          if (r.online) w.append(badge('online', '#d9e6fa', '#134'));
          if (r.gated) w.append(badge('needs licence', '#f6ecc8', '#640'));
          tr.append(el('td', { text: r.id, title: r.id }), el('td', { text: r.paramsB ? r.paramsB + 'B' : '?' }), el('td', { text: num(r.downloads) }), el('td', { text: num(r.likes) }), el('td', { text: r.updated ? r.updated.slice(0, 10) : '' }), el('td', { text: r.license || '?', title: r.license || 'Licence not stated' }), w);
          tr.onclick = () => { tb.querySelectorAll('.sel').forEach((x) => x.classList.remove('sel')); tr.classList.add('sel'); sel = r; showDetail(r); }; tb.append(tr);
        }
        t.append(tb); listBox.replaceChildren(t);
      }

      async function showDetail(r) {
        detail = () => showDetail(r);
        const head = el('div', { style: 'font-weight:bold;color:#003399;margin-bottom:4px', text: r.id });
        const body = el('div');
        const kv = (k, v) => v ? el('tr', null, el('td', { style: 'color:#6a7ea8;padding:1px 10px 1px 0;white-space:nowrap;vertical-align:top', text: k }), el('td', { style: 'padding:1px 0', text: String(v) })) : null;
        const need = r.estGB ? `about ${r.estGB} GB of memory at 4-bit (${r.fits ? 'fits' : 'too big for'} this computer's ${st.ramGB} GB)` : '';
        const info = el('table', { style: 'border-collapse:collapse;margin-bottom:6px' }, ...[kv('By', r.author), kv('Parameters', r.paramsB ? r.paramsB + ' billion' + (r.caps && r.caps.includes('mixture-of-experts') ? ' (mixture of experts: only part is active per word, so it runs faster than its size suggests)' : '') : 'unknown'), kv('Memory needed', need), kv('Licence', r.license ? r.license + (r.open ? ' (open)' : '') : 'not stated'), kv('Good for', (r.caps || []).join(', ')), kv('Languages', (r.langs || []).join(', ')), kv('Based on', r.base), kv('Context hint', r.ctxK ? r.ctxK + 'K tokens (from name)' : ''), kv('Popularity', `${num(r.downloads)} downloads, ${num(r.likes)} likes`), kv('Last updated', r.updated ? r.updated.slice(0, 10) : ''), kv('Access', r.gated ? 'Needs approval on Hugging Face first' : 'Open download'), kv('Runs', [r.gguf ? 'offline (GGUF)' : '', r.online ? 'online' : ''].filter(Boolean).join(' and '))].filter(Boolean));
        detBox.replaceChildren(head, info, body);
        if (r.online) {
          const b = el('button', { class: 'btn', text: 'Add as online contact (uses Hugging Face servers)', onclick: async () => {
            st = Object.assign(st, await api('GET', 'status')); if (!st.hasToken) { await tokenDialog(); if (!st.hasToken) return; }
            if (!await confirmBox('Online model', `Messages you send to this contact will be sent to Hugging Face's servers (router.huggingface.co) to be answered. Continue?`)) return;
            try { const c = await api('POST', 'add', { id: r.id, mode: 'online' }); toast(`${c.name} added as an online contact.`); A.hooks.refresh && A.hooks.refresh(); } catch (e) { toast(e.code === 'token' ? 'Save a Hugging Face token first.' : e.message); } } });
          body.append(el('div', { style: 'margin:2px 0 6px' }, b));
        }
        if (!r.gguf) { if (!r.online) body.append(el('div', { text: 'This model has no downloadable offline version (GGUF) and is not offered online right now.' })); return; }
        body.append(el('div', { style: 'color:#6a7ea8;margin-bottom:3px', text: 'Offline files (smaller = faster, lower quality). Green ones fit this computer\'s memory.' }));
        const fl = el('div', { text: 'Loading file list...' }); body.append(fl);
        let files; try { files = await api('GET', 'files?id=' + encodeURIComponent(r.id)); } catch (e) { fl.textContent = e.message; fl.style.color = '#a00'; return; }
        st = Object.assign(st, await api('GET', 'status'));
        const have = (f) => st.downloaded.includes(r.id.replace('/', '__') + '/' + f.path.split('/').pop());
        if (!files.length) return (fl.textContent = 'No .gguf files found in this repository.');
        const tb = el('div');
        for (const f of files) {
          const act = el('div', { style: 'margin-top:3px' }); const row = el('div', { style: 'padding:4px 2px;border-bottom:1px solid #dde3f0;' + (f.fits ? '' : 'opacity:.6') });
          const bar = el('div', { style: 'display:none;width:150px;height:10px;border:1px solid #7f9db9;background:#fff' }, el('div', { style: 'height:100%;width:0;background:#4a8be0' }));
          const addBtn = () => { act.replaceChildren(el('button', { class: 'btn', text: 'Add as contact', onclick: async () => { try { const c = await api('POST', 'add', { id: r.id, mode: 'local', file: f.path }); toast(`${c.name} added (offline).`); A.hooks.refresh && A.hooks.refresh(); } catch (e) { toast(e.message); } } }),
            el('button', { class: 'btn', text: 'Delete file', style: 'margin-left:4px', onclick: async () => { if (!await confirmBox('Delete file', 'Delete the downloaded model file from this computer? Contacts using it will stop working.')) return; await api('DELETE', 'model?file=' + encodeURIComponent(r.id.replace('/', '__') + '/' + f.path.split('/').pop())); st.downloaded = st.downloaded.filter((x) => !x.endsWith('/' + f.path.split('/').pop())); dlBtn(); } })); };
          const dlBtn = () => { if (have(f) || st.downloaded.some((x) => x === r.id.replace('/', '__') + '/' + f.path.split('/').pop())) return addBtn();
            act.replaceChildren(el('button', { class: 'btn', text: f.split ? 'Split file (not supported)' : 'Download', disabled: f.split, onclick: () => download(f, act, bar, addBtn, dlBtn) }), bar); };
          dlBtn();
          row.append(el('div', { style: 'display:flex;gap:6px;align-items:center' }, el('b', { text: (f.recommended ? '★ ' : '') + f.path.split('/').pop(), style: 'flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap', title: f.path }), el('span', { text: f.sizeGB + ' GB' }), f.fits ? badge('fits', '#dcefd9', '#164') : badge('too big', '#f3d6d6', '#800')), act); tb.append(row);
        }
        fl.replaceWith(tb);
      }

      async function download(f, act, bar, done, reset) {
        bar.style.display = 'block'; const inner = bar.firstChild; const btn = act.querySelector('button'); btn.textContent = 'Cancel';
        const ac = new AbortController(); btn.onclick = () => ac.abort();
        const label = el('span', { style: 'margin-left:6px', text: 'Starting...' }); act.append(label);
        try {
          const r = await fetch('/api/hf/download', { method: 'POST', signal: ac.signal, headers: { 'X-Token': sessionStorage.getItem('tok') || '', 'Content-Type': 'application/json' }, body: JSON.stringify({ id: sel.id, file: f.path }) });
          if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || r.statusText);
          const rd = r.body.getReader(); const dec = new TextDecoder(); let buf = '', ok = false;
          for (;;) { const { value, done: d } = await rd.read(); if (d) break; buf += dec.decode(value, { stream: true }); let i;
            while ((i = buf.indexOf('\n\n')) >= 0) { const line = buf.slice(0, i); buf = buf.slice(i + 2); if (!line.startsWith('data: ')) continue; const o = JSON.parse(line.slice(6));
              if (o.error) throw new Error(o.error); inner.style.width = (o.total ? Math.round(o.got / o.total * 100) : 0) + '%'; label.textContent = o.total ? `${Math.round(o.got / 1048576)} / ${Math.round(o.total / 1048576)} MB` : '';
              if (o.done) ok = true; } }
          if (!ok) throw new Error('Download was interrupted.');
          st.downloaded.push(sel.id.replace('/', '__') + '/' + f.path.split('/').pop());
          const c = await api('POST', 'add', { id: sel.id, mode: 'local', file: f.path }); // finished: add the offline contact automatically
          toast(`Download finished. ${c.name} was added as an offline contact.`); A.sound('vimdone'); A.hooks.refresh && A.hooks.refresh(); done();
        } catch (e) { if (e.name !== 'AbortError') toast('Download failed: ' + e.message); reset(); }
      }
      syncFit(); search();
    });
  };
})(window);
