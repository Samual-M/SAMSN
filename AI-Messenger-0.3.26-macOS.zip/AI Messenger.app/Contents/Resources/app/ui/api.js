/* thin client for the local backend */
(function (g) {
  const q = new URLSearchParams(location.search);
  if (q.get('t')) { try { sessionStorage.setItem('tok', q.get('t')); } catch (e) {} history.replaceState(null, '', location.pathname + location.search.replace(/[?&]t=[^&]*/, '').replace(/^&/, '?')); }
  const tok = () => { try { return sessionStorage.getItem('tok') || ''; } catch (e) { return ''; } };
  async function raw(method, path, body) {
    const r = await fetch('/api/' + path, { method, headers: { 'X-Token': tok(), 'Content-Type': 'application/json' }, body: body !== undefined ? JSON.stringify(body) : undefined });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || r.statusText);
    return r;
  }
  const call = async (m, p, b) => (await raw(m, p, b)).json();
  async function chat(id, payload, h) { // SSE over fetch; h = { delta(text, from), start(from), end(from), error(msg, from) }
    const r = await fetch('/api/chat/' + id, { method: 'POST', headers: { 'X-Token': tok(), 'Content-Type': 'application/json' }, body: JSON.stringify(payload), signal: payload.signal });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || r.statusText);
    const reader = r.body.getReader(); const dec = new TextDecoder(); let buf = '';
    for (;;) {
      const { value, done } = await reader.read(); if (done) break;
      buf += dec.decode(value, { stream: true }); let i;
      while ((i = buf.indexOf('\n\n')) >= 0) {
        const line = buf.slice(0, i); buf = buf.slice(i + 2);
        if (!line.startsWith('data: ')) continue;
        const o = JSON.parse(line.slice(6));
        if (o.error) h.error && h.error(o.error, o.from);
        else if (o.start) h.start && h.start(o.start);
        else if (o.end) h.end && h.end(o.end);
        else if (o.reasoning) h.reasoning && h.reasoning(o.reasoning, o.from);
        else if (o.delta) h.delta(o.delta, o.from);
      }
    }
  }
  g.API = {
    session: () => call('GET', 'session'), signIn: (b) => call('POST', 'signin', b), signOut: () => call('POST', 'signout', {}),
    createProfile: (b) => call('POST', 'profiles', b), deleteProfile: (id) => call('DELETE', 'profiles/' + id),
    state: () => call('GET', 'state'), profile: (p) => call('PUT', 'profile', p), settings: (s) => call('PUT', 'settings', s), setPassword: (b) => call('PUT', 'password', b),
    assets: (a) => call('PUT', 'assets', a), groups: (b) => call('POST', 'groups', b),
    saveContact: (c) => call('POST', 'contacts', c), delContact: (id) => call('DELETE', 'contacts/' + id),
    chats: () => call('GET', 'chats'), newChat: (b) => call('POST', 'chats', b), saveChat: (id, b) => call('PUT', 'chats/' + id, b), delChat: (id) => call('DELETE', 'chats/' + id),
    projects: () => call('GET', 'projects'), newProject: (b) => call('POST', 'projects', b), saveProject: (id, b) => call('PUT', 'projects/' + id, b), delProject: (id) => call('DELETE', 'projects/' + id),
    history: (id) => call('GET', 'history/' + id), clearHistory: (id) => call('DELETE', 'history/' + id), removeMessage: (id, i) => call('PUT', 'history/' + id, { remove: i }),
    overview: () => call('GET', 'overview'), search: (q, contact) => call('GET', 'search?q=' + encodeURIComponent(q) + (contact ? '&contact=' + encodeURIComponent(contact) : '')),
    alerts: () => call('GET', 'alerts'), addAlert: (a) => call('POST', 'alerts', a), clearAlerts: () => call('DELETE', 'alerts'),
    received: () => call('GET', 'received'), saveReceived: (b) => call('POST', 'received', b), deleteReceived: (n) => call('DELETE', 'received/' + encodeURIComponent(n)),
    downloadReceived: async (n) => { const r = await raw('GET', 'received/' + encodeURIComponent(n)); return r.blob(); },
    ui: () => call('GET', 'ui'), setUi: (b) => call('PUT', 'ui', b),
    models: (b) => call('POST', 'models', b), chat, ping: () => call('GET', 'ping').catch(() => {}),
  };
})(window);
