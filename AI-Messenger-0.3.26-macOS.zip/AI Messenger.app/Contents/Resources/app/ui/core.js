/* core.js - shared helpers: dialogs, page windows, sounds, images, theme. */
(function (g) {
  'use strict';
  const AIM = { state: null, hooks: {} };
  g.AIM = AIM;
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const $ = (scope, uid) => scope.querySelector(`[data-uid="${uid}"]`);
  const $$ = (scope, uid) => [...scope.querySelectorAll(`[data-uid="${uid}"]`)];
  const hide = (scope, ...uids) => uids.forEach((u) => $$(scope, u).forEach((e) => { e.style.display = 'none'; }));
  const el = (tag, props, ...kids) => { const e = document.createElement(tag); if (props) for (const k in props) { if (k === 'style') e.style.cssText = props[k]; else if (k === 'class') e.className = props[k]; else if (k.startsWith('on')) e.addEventListener(k.slice(2), props[k]); else if (k === 'text') e.textContent = props[k]; else if (k === 'html') e.innerHTML = props[k]; else e[k] = props[k]; } for (const c of kids) if (c != null) e.append(c); return e; };
  const settings = () => (AIM.state && AIM.state.settings) || {};
  const fmtTime = (t) => { const d = new Date(t); const same = d.toDateString() === new Date().toDateString(); return same ? d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); };

  function toast(msg) {
    const t = el('div', { text: msg, style: 'position:fixed;left:50%;bottom:14px;transform:translateX(-50%);background:#ffffe1;border:1px solid #000;padding:3px 8px;z-index:900;font-size:8pt;box-shadow:2px 2px 3px rgba(0,0,0,.3);max-width:90%' });
    document.body.append(t); setTimeout(() => t.remove(), 2600);
  }
  function sound(name) { if (!settings().sounds) return; try { const a = new Audio(g.Themes ? Themes.soundUrl(name) : `assets/sounds/${name}.wav`); a.volume = .8; a.play().catch(() => {}); } catch (e) {} }
  function speak(text) { try { if (!settings().readAloud || !g.speechSynthesis) return; g.speechSynthesis.cancel(); g.speechSynthesis.speak(new SpeechSynthesisUtterance(String(text).replace(/```[\s\S]*?```/g, ' code block ').slice(0, 1500))); } catch (e) {} }

  // ---------- images ----------
  // The original MSN Messenger 7.5 display pictures (assets 298-308) and the classic buddy figure (1048).
  const PICS = [298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308].map((n) => `assets/img/${n}.png`); const BUDDY = 'assets/img/1048.png';
  function defaultPic(name, mine) { return mine ? BUDDY : PICS[[...String(name)].reduce((a, ch) => a + ch.charCodeAt(0), 0) % PICS.length]; }
  function avatar(name, size, hue, dataUrl) {
    if (!dataUrl) dataUrl = defaultPic(name, hue === 210);
    if (dataUrl) { const i = new Image(); i.src = dataUrl; i.style.cssText = `width:${size}px;height:${size}px;display:block;object-fit:cover;border-radius:${Math.round(size * .12)}px`; i.draggable = false; return i; }
    const c = document.createElement('canvas'); c.width = c.height = size * 2; const x = c.getContext('2d');
    const h = hue != null ? hue : [...String(name)].reduce((a, ch) => a + ch.charCodeAt(0), 0) % 360;
    const gr = x.createLinearGradient(0, 0, 0, c.height); gr.addColorStop(0, `hsl(${h},70%,72%)`); gr.addColorStop(1, `hsl(${h},65%,45%)`);
    x.fillStyle = gr; x.beginPath(); x.roundRect(0, 0, c.width, c.height, size * .35); x.fill();
    x.fillStyle = '#fff'; x.font = `bold ${size * 1.1}px Tahoma,sans-serif`; x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText((String(name).trim()[0] || '?').toUpperCase(), c.width / 2, c.height / 2 + size * .05);
    const img = new Image(); img.src = c.toDataURL(); img.style.cssText = `width:${size}px;height:${size}px;display:block`; img.draggable = false; return img;
  }
  const readDataUrl = (file) => new Promise((r, j) => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.onerror = j; fr.readAsDataURL(file); });
  async function resizeImage(fileOrUrl, max, type = 'image/jpeg', q = .85) {
    const url = typeof fileOrUrl === 'string' ? fileOrUrl : await readDataUrl(fileOrUrl);
    const img = await new Promise((r, j) => { const i = new Image(); i.onload = () => r(i); i.onerror = j; i.src = url; });
    const k = Math.min(1, max / Math.max(img.width, img.height)); const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); return c.toDataURL(type, q);
  }
  function pickFile(accept, multiple) { return new Promise((resolve) => { const f = el('input', { type: 'file', accept, multiple: !!multiple }); f.onchange = () => resolve([...f.files]); f.oncancel = () => resolve([]); f.click(); }); }
  function download(name, blobOrText, type = 'text/plain') { const b = blobOrText instanceof Blob ? blobOrText : new Blob([blobOrText], { type }); const a = el('a', { href: URL.createObjectURL(b), download: name }); a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); }

  // ---------- theme ----------
  function applyTheme() { const r = document.getElementById('root'); if (r) r.style.filter = settings().hue ? `hue-rotate(${settings().hue}deg)` : ''; }

  // ---------- emoticons ----------
  function richText(text) { // safe markdown-ish + custom emoticons
    const parts = String(text).split(/```/); let html = '';
    parts.forEach((p, i) => { if (i % 2) html += '<pre>' + ((window.Msn80 && Msn80.on()) ? '<span class="precopy" contenteditable="false">Copy code</span>' : '') + esc(p.replace(/^\w*\n/, '')) + '</pre>'; else { const seg = esc(p).replace(/`([^`\n]+)`/g, '<code>$1</code>').replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>'); html += (window.Msn80 && Msn80.on()) ? Msn80.emo(seg) : seg; } });
    for (const e of (AIM.state && AIM.state.assets && AIM.state.assets.emoticons) || []) {
      const sc = esc(e.shortcut); if (!sc) continue;
      html = html.split(sc).join(`<img src="${e.dataUrl}" alt="${sc}" title="${sc}" style="height:1.4em;vertical-align:middle">`);
    }
    return html;
  }

  // ---------- dialogs ----------
  function pageWin({ title, width = 420, height, body, buttons, onClose, icon }) {
    const shade = el('div', { class: 'dlg-shade' }); const d = el('div', { class: 'dlg', style: `width:${width}px;max-width:96vw` + (height ? `;height:${height}px;max-height:94vh;display:flex;flex-direction:column` : '') });
    const bar = el('h3', { text: title }); const x = el('span', { text: '✕', style: 'float:right;cursor:pointer;padding:0 4px' }); bar.prepend(x);
    const bd = el('div', { class: 'pg' }); if (height) bd.style.cssText = 'flex:1;min-height:0;overflow:auto'; if (typeof body === 'string') bd.innerHTML = body; else if (body) bd.append(body);
    const ft = el('div', { class: 'ft' });
    const close = (v) => { shade.remove(); document.removeEventListener('keydown', onKey, true); onClose && onClose(v); };
    function onKey(e) { if (e.key === 'Escape' && shade.parentNode && [...document.querySelectorAll('.dlg-shade')].pop() === shade) { e.stopPropagation(); close(null); } }
    document.addEventListener('keydown', onKey, true); x.onclick = () => close(null);
    for (const b of buttons || [{ label: 'Close' }]) { const bt = el('button', { class: 'btn' + (b.primary ? ' primary' : ''), text: b.label }); bt.onclick = async () => { if (b.onClick) { const r = await b.onClick({ close, body: bd }); if (r === false) return; } close(b.value !== undefined ? b.value : b.label); }; ft.append(bt); }
    d.append(bar, bd, ft); shade.append(d); document.body.append(shade); AIM.sound && 0;
    return { el: d, body: bd, close, footer: ft };
  }
  function dialog({ title, rows, ok = 'OK', cancel = 'Cancel', extra, onBuilt, width }) {
    return new Promise((resolve) => {
      const bd = el('div', { class: 'bd' }); const inputs = {};
      for (const r of rows) {
        if (r.html) { bd.append(el('div', { class: 'full', html: r.html })); continue; }
        let inp;
        if (r.type === 'select') { inp = el('select'); for (const o of r.options) inp.append(el('option', { value: o.value, text: o.label })); }
        else if (r.type === 'textarea') inp = el('textarea');
        else if (r.type === 'checkbox') { inp = el('input', { type: 'checkbox' }); inp.style.width = 'auto'; inp.checked = !!r.value; }
        else { inp = el('input', { type: r.type || 'text' }); if (r.type === 'range' || r.type === 'number') { if (r.min != null) inp.min = r.min; if (r.max != null) inp.max = r.max; if (r.step) inp.step = r.step; } if (r.list) { const dl = el('datalist', { id: 'dl' + Math.random().toString(36).slice(2) }); r.list.forEach((m) => dl.append(el('option', { value: m }))); inp.setAttribute('list', dl.id); bd.append(dl); inputs['__dl_' + r.key] = dl; } }
        if (r.type !== 'checkbox') inp.value = r.value != null ? r.value : '';
        if (r.placeholder) inp.placeholder = r.placeholder;
        inputs[r.key] = inp;
        if (r.type === 'checkbox') { const l = el('label', { class: 'full', style: 'display:flex;gap:6px;align-items:center' }, inp, document.createTextNode(r.label || '')); if (r.group) { l.dataset.group = r.group; } bd.append(l); continue; }
        const lab = el('label', { text: r.label || '' }); if (r.full) lab.className = 'full';
        if (r.group) { lab.dataset.group = r.group; inp.dataset.group = r.group; }
        bd.append(lab); if (r.full) { inp.className += ' full'; bd.append(inp); } else bd.append(inp);
      }
      const win = pageWin({ title, width: width || 420, body: bd, buttons: [], onClose: (v) => resolve(v === undefined ? null : v) });
      const ft = win.footer; const done = (v) => win.close(v);
      if (extra) for (const e of extra) ft.append(el('button', { class: 'btn', text: e.label, onclick: () => e.onClick(inputs) }));
      const collect = () => Object.fromEntries(Object.entries(inputs).filter(([k]) => !k.startsWith('__')).map(([k, v]) => [k, v.type === 'checkbox' ? v.checked : v.value]));
      const okb = el('button', { class: 'btn primary', text: ok, onclick: () => done(collect()) }); ft.append(okb);
      if (cancel) ft.append(el('button', { class: 'btn', text: cancel, onclick: () => done(null) }));
      win.el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA' && e.target.tagName !== 'BUTTON') okb.click(); });
      if (onBuilt) onBuilt(win.el, inputs);
      (Object.values(inputs).find((i) => i.focus && i.type !== 'checkbox') || okb).focus();
    });
  }
  const info = (title, html, w = 420) => new Promise((res) => pageWin({ title, width: w, body: html, buttons: [{ label: 'OK', primary: true }], onClose: res }));
  const confirmBox = (title, text, ok = 'OK') => new Promise((res) => pageWin({ title, width: 380, body: `<div style="padding:12px;line-height:1.4">${esc(text)}</div>`, buttons: [{ label: ok, value: true, primary: true }, { label: 'Cancel', value: false }], onClose: (v) => res(v === true) }));
  const notApplicable = (label, why) => info('Not available offline', `<div style="padding:12px;line-height:1.45"><b>${esc(String(label).replace(/&|\t.*$/g, '').replace(/\.\.\.$/, ''))}</b><br><br>${why || 'This feature depends on the MSN online service, which this offline edition does not connect to.'}</div>`);

  Object.assign(AIM, { PICS, BUDDY, esc, $, $$, hide, el, toast, sound, speak, avatar, readDataUrl, resizeImage, pickFile, download, applyTheme, richText, pageWin, dialog, info, confirmBox, notApplicable, settings, fmtTime });
})(window);
