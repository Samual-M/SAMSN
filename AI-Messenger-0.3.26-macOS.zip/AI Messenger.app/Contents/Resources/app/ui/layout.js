/* layout.js - "Align layout" tool: drag, nudge and resize any block of the interface, then save.
   Everything stays on this computer (saved in your profile's settings as layoutTweaks). */
(function (g) {
  'use strict';
  const A = g.AIM; const { el, toast } = A;
  const tweaks = () => Object.assign({}, (A.settings().layoutTweaks) || {});
  const byUid = (u) => [...document.querySelectorAll(`[data-uid="${CSS.escape(u)}"]`)];
  const keyOf = (e) => { const u = e.dataset.uid; const l = byUid(u); return l.length < 2 ? u : u + '~' + l.indexOf(e); };
  const all = (key) => { const m = /^(.*)~(\d+)$/.exec(key); if (m) { const e = byUid(m[1])[Number(m[2])]; return e ? [e] : []; } return byUid(key); };
  // artwork pieces (the little png tiles) have no name of their own: give each a stable one so it can be selected and moved on its own
  const tagAnon = () => {
    const cnt = new Map();
    document.querySelectorAll('.t-png, .bgpng').forEach((e) => {
      if (e.dataset.uid || e.closest('[data-layout-panel]')) return;
      const p = e.parentElement && e.parentElement.closest('[data-uid]'); const base = p ? (p.dataset.uid || 'x') : 'root';
      const n = (cnt.get(base) || 0) + 1; cnt.set(base, n); e.dataset.uid = `${base}.art${n}`; e.dataset.anon = '1';
    });
  };
  // layout revision 2 moved the msn logo by default: drop old saved offsets for it so they do not stack on top of the new position
  const migrate = () => { const S = A.settings(); if ((S.layoutRev || 0) >= 2) return; const t = tweaks(); let ch = false; for (const k of Object.keys(t)) if (/^msnlogo/.test(k)) { delete t[k]; ch = true; } A.state.settings.layoutRev = 2; A.state.settings.layoutTweaks = t; g.API.settings({ layoutRev: 2, layoutTweaks: t }).catch(() => {}); return ch; };
  const apply = (map) => {
    if (!map) migrate();
    tagAnon();
    const t = map || tweaks();
    for (const uid of Object.keys(t)) for (const e of all(uid)) {
      const v = t[uid] || {};
      if (e.__lw === undefined) { e.__lw = null; }
      if (v.z != null) { if (getComputedStyle(e).position === 'static') e.style.position = 'relative'; e.style.zIndex = String(v.z); } else if (e.__z) { e.style.zIndex = ''; }
      e.__z = v.z != null;
      { const f = []; if (v.br != null && v.br !== 100) f.push(`brightness(${v.br}%)`); if (v.co != null && v.co !== 100) f.push(`contrast(${v.co}%)`); if (v.sa != null && v.sa !== 100) f.push(`saturate(${v.sa}%)`); if (v.hu) f.push(`hue-rotate(${v.hu}deg)`);
        if (f.length) { e.style.filter = f.join(' '); e.__flt = true; } else if (e.__flt) { e.style.filter = ''; e.__flt = false; }
        if (v.op != null && v.op !== 100) { e.style.opacity = String(v.op / 100); e.__op = true; } else if (e.__op) { e.style.opacity = ''; e.__op = false; } }
      if (v.hide) { e.style.visibility = 'hidden'; e.__hid = true; } else if (e.__hid) { e.style.visibility = ''; e.__hid = false; }
      let tf = (v.x || v.y) ? `translate(${v.x || 0}px,${v.y || 0}px)` : '';
      if (v.lock) { // locked group: keeps the size it had when locked, so everything inside stays exactly as designed; optionally scales with the window
        const L = v.lock; e.style.width = L.w + 'px'; e.style.height = L.h + 'px'; e.style.minWidth = '0'; e.style.minHeight = '0'; e.style.maxWidth = 'none'; e.style.flex = 'none'; e.__lock = true;
        let k = 1; if (L.mode === 'scale' && e.parentElement && L.pw) k = Math.min(3, Math.max(0.4, e.parentElement.clientWidth / L.pw));
        if (k !== 1) { tf += ` scale(${k})`; e.style.transformOrigin = '0 0'; e.style.marginBottom = ((k - 1) * L.h) + 'px'; e.style.marginRight = ((k - 1) * L.w) + 'px'; } else { e.style.transformOrigin = ''; e.style.marginBottom = ''; e.style.marginRight = ''; }
        watch(e.parentElement);
      } else if (e.__lock) { e.style.width = ''; e.style.height = ''; e.style.flex = ''; e.style.transformOrigin = ''; e.style.marginBottom = ''; e.style.marginRight = ''; e.__lock = false; }
      e.style.transform = tf;
      if (!v.lock && (v.w || v.h)) { // size changes are relative to the natural size
        e.style.width = ''; e.style.height = ''; const r = e.getBoundingClientRect();
        if (v.w) { e.style.width = Math.max(1, r.width + v.w) + 'px'; e.style.minWidth = '0'; e.style.flex = 'none'; }
        if (v.h) { e.style.height = Math.max(1, r.height + v.h) + 'px'; e.style.minHeight = '0'; e.style.flex = 'none'; }
      } else if (e.__sized) { e.style.width = ''; e.style.height = ''; }
      e.__sized = !v.lock && !!(v.w || v.h);
    }
  };
  const watched = new WeakSet(); let ro = null; let rq = 0;
  const watch = (p) => { if (!p || watched.has(p) || !g.ResizeObserver) return; watched.add(p); ro = ro || new ResizeObserver(() => { cancelAnimationFrame(rq); rq = requestAnimationFrame(() => apply()); }); ro.observe(p); };
  let timer = null; const later = () => { clearTimeout(timer); timer = setTimeout(() => apply(), 120); };
  addEventListener('resize', later);
  const clear = (uid) => { for (const e of all(uid)) { e.style.transform = ''; if (e.__lock) { e.style.width = ''; e.style.height = ''; e.style.flex = ''; e.style.transformOrigin = ''; e.style.marginBottom = ''; e.style.marginRight = ''; e.__lock = false; } if (e.__flt) { e.style.filter = ''; e.__flt = false; } if (e.__op) { e.style.opacity = ''; e.__op = false; } if (e.__hid) { e.style.visibility = ''; e.__hid = false; } if (e.__z) { e.style.zIndex = ''; e.__z = false; } if (e.__sized) { e.style.width = ''; e.style.height = ''; e.style.flex = ''; e.__sized = false; } } };

  let editing = null;
  function edit() {
    if (editing) return editing.stop(false);
    tagAnon();
    const work = tweaks(); const saved = JSON.stringify(work); let sel = null; let drag = null;
    const hov = el('div', { style: 'position:fixed;z-index:99998;pointer-events:none;border:1px dashed #d22;display:none;font:9px sans-serif;color:#d22' });
    const hovLab = el('span', { style: 'position:absolute;left:0;top:-12px;background:#fff;padding:0 2px' }); hov.append(hovLab);
    const box = el('div', { style: 'position:fixed;z-index:99998;pointer-events:none;border:2px solid #25f;display:none;background:rgba(40,80,255,.08)' });
    const num = (k) => { const i = el('input', { type: 'number', value: 0, style: 'width:52px;font:inherit' }); i.oninput = () => { if (!sel) return; const v = work[sel] = work[sel] || {}; v[k] = Number(i.value) || 0; refresh(true); }; return i; };
    const nx = num('x'), ny = num('y'), nw = num('w'), nh = num('h');
    const title = el('div', { style: 'font-weight:bold;color:#fff;background:linear-gradient(#2a56b0,#1a3d8a);margin:-8px -8px 6px;padding:4px 8px;cursor:move;display:flex;align-items:center;user-select:none', title: 'Drag to move this panel. Double-click to fold it.' }, el('span', { style: 'flex:1', text: 'Align layout  (drag me)' }), el('span', { text: '\u2013', style: 'cursor:pointer;padding:0 4px', onclick: () => fold() }));
    const body = el('div');
    const layersBox = el('div', { style: 'max-height:150px;overflow:auto;border:1px solid #7f9db9;background:#fff;margin:3px 0;font-size:10px' });
    const layersHead = el('div', { style: 'font-weight:bold', text: 'Layers: click a block to list what is inside it' });
    let root = null;
    const fold = () => { body.style.display = body.style.display === 'none' ? '' : 'none'; };
    const sliders = {}; const sl = (k, label, min, max, def) => { const out = el('span', { style: 'width:34px;text-align:right', text: String(def) }); const i = el('input', { type: 'range', min, max, value: def, style: 'flex:1;width:100px;margin:0' });
      i.oninput = () => { if (!sel) return; const v = work[sel] = work[sel] || {}; v[k] = Number(i.value); out.textContent = i.value; refresh(true); };
      sliders[k] = { i, out, def }; return el('div', { style: 'display:flex;align-items:center;gap:4px;margin:1px 0' }, el('span', { style: 'width:62px', text: label }), i, out); };
    const colourBox = el('div', { style: 'border-top:1px solid #aab;margin-top:4px;padding-top:3px' }, el('div', { style: 'font-weight:bold', text: 'Colour of the selected block' }),
      sl('op', 'Opacity', 0, 100, 100), sl('br', 'Brightness', 40, 160, 100), sl('co', 'Contrast', 40, 160, 100), sl('sa', 'Saturation', 0, 200, 100), sl('hu', 'Hue shift', -180, 180, 0),
      el('button', { class: 'btn', text: 'Reset colour', onclick: () => { if (!sel || !work[sel]) return; for (const k of ['op', 'br', 'co', 'sa', 'hu']) delete work[sel][k]; refresh(true); } }));
    const lockSel = (mode) => { if (!sel) return; const e = all(sel).find((q) => q.getClientRects().length); if (!e) return; const v = work[sel] = work[sel] || {}; const L = v.lock;
      v.lock = { w: L ? L.w : e.offsetWidth, h: L ? L.h : e.offsetHeight, pw: L ? L.pw : (e.parentElement ? e.parentElement.clientWidth : 0), mode }; refresh(true); toast(mode === 'scale' ? 'Locked: this block and everything in it now scales together with the window.' : 'Locked: this block keeps its size; everything in it stays together.'); };
    const unlockSel = () => { if (!sel || !work[sel]) return; delete work[sel].lock; clear(sel); apply({ [sel]: work[sel] }); refresh(); };
    const stackBox = el('div', { style: 'max-height:110px;overflow:auto;border:1px solid #7f9db9;background:#fff;margin:3px 0;font-family:monospace;font-size:10px' });
    const zin = el('input', { type: 'number', value: 0, style: 'width:52px;font:inherit' }); zin.oninput = () => { if (!sel) return; (work[sel] = work[sel] || {}).z = Number(zin.value) || 0; refresh(true); };
    const info = el('div', { style: 'color:#334;margin-bottom:4px', text: 'Click a block, then drag it. Arrow keys nudge 1px (Shift = 10px). Alt+arrows resize.' });
    const selLab = el('div', { style: 'margin-bottom:4px;font-family:monospace', text: 'Nothing selected' });
    const row = (...c) => el('div', { style: 'display:flex;gap:4px;align-items:center;margin:3px 0;flex-wrap:wrap' }, ...c);
    const btn = (t, f, tip) => el('button', { class: 'btn', text: t, onclick: f, title: tip || '' });
    const panel = el('div', { style: 'position:fixed;right:10px;bottom:10px;z-index:99999;width:268px;max-height:92vh;overflow:auto;background:#ece9d8;border:1px solid #003399;box-shadow:2px 2px 8px rgba(0,0,0,.35);padding:8px;font:11px sans-serif;color:#000' },
      title, body);
    body.append(info, el('div', { style: 'font-weight:bold' , text: 'Blocks under the pointer (top first):' }), stackBox, layersHead, layersBox, selLab,
      row('X', nx, 'Y', ny), row('W', nw, 'H', nh), row('Layer', zin, btn('Forward', () => zStep(1)), btn('Back', () => zStep(-1))), row(btn('To front', () => zTo(true)), btn('To back', () => zTo(false)), btn('Next underneath', () => cycle())),
      el('div', { style: 'border-top:1px solid #aab;margin-top:4px;padding-top:3px' }, el('div', { style: 'font-weight:bold', text: 'Lock this block and everything inside it' }), row(btn('Lock size', () => lockSel('fixed'), 'Freeze the size so the pieces inside never drift apart'), btn('Lock + scale', () => lockSel('scale'), 'Freeze the layout and scale it in proportion when the window is resized'), btn('Unlock', unlockSel))), colourBox, row(btn('Parent block', () => { if (!sel) return; const p = (all(sel)[0] || {}).parentElement; const q = p && p.closest('[data-uid]'); if (q) select(keyOf(q)); }), btn('Reset this', () => { if (!sel) return; delete work[sel]; clear(sel); refresh(); })),
      row(btn('Reset all', () => { for (const k of Object.keys(work)) { clear(k); delete work[k]; } refresh(); }), btn('Copy values', () => { const t = JSON.stringify(work, null, 1); (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => toast('Copied to the clipboard.'), () => toast(t)); })),
      row(btn('Save', async () => { await g.API.settings({ layoutTweaks: work }); A.state.settings.layoutTweaks = work; toast('Layout saved.'); stop(true); }), btn('Cancel', () => stop(false))));
    panel.setAttribute('data-layout-panel', '1');
    const uidAt = (t) => { const e = t && t.closest && t.closest('[data-uid]'); return e && !e.closest('[data-layout-panel]') ? e : null; };
    const place = (b, e) => { if (!e) { b.style.display = 'none'; return; } const r = e.getBoundingClientRect(); Object.assign(b.style, { display: 'block', left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px' }); };
    const kids = (e) => { const out = []; const walk = (n) => { for (const c of n.children) { if (c.closest('[data-layout-panel]')) continue; if (c.dataset && keyOf(c)) out.push(c); else walk(c); } }; walk(e); return out; };
    const depthOf = (e, top) => { let d = 0; let n = e.parentElement; while (n && n !== top) { if (n.dataset && n.dataset.uid) d++; n = n.parentElement; } return d; };
    const renderLayers = () => {
      const se = sel && all(sel).find((q) => q.getClientRects().length); const inRoot = se && root && root.contains(se);
      if (se && !inRoot) root = se; else if (se && se === root) root = se;
      if (!root || !root.isConnected) { layersHead.textContent = 'Layers: select a block first'; layersBox.replaceChildren(); return; }
      layersHead.textContent = 'Layers inside ' + (keyOf(root) || 'block') + ':';
      const rows = []; const add = (e, depth) => { for (const c of kids(e)) { rows.push([c, depth]); if (depth < 1) add(c, depth + 1); } }; add(root, 0);
      const up = el('div', { style: 'padding:1px 4px;cursor:pointer;color:#003399', text: '\u2191 up one level', onclick: () => { const q = root.parentElement && root.parentElement.closest('[data-uid]'); if (q) { root = q; select(keyOf(q)); } } });
      layersBox.replaceChildren(up, ...rows.map(([e, d]) => {
        const uid = keyOf(e); const hidden = !!(work[uid] && work[uid].hide); const r = e.getBoundingClientRect();
        const eye = el('span', { text: hidden ? '\u25CC' : '\u25C9', title: hidden ? 'Hidden: click to show' : 'Visible: click to hide', style: 'cursor:pointer;width:14px;display:inline-block;text-align:center;color:' + (hidden ? '#999' : '#234'), onclick: (ev) => { ev.stopPropagation(); const v = work[uid] = work[uid] || {}; v.hide = !v.hide; if (!v.hide) delete v.hide; apply({ [uid]: work[uid] }); if (!work[uid].hide && e.style.visibility) e.style.visibility = ''; renderLayers(); } });
        const into = el('span', { text: '\u25B8', title: 'Open this block\u2019s contents', style: 'cursor:pointer;float:right;padding:0 4px;color:#003399', onclick: (ev) => { ev.stopPropagation(); root = e; select(uid); } });
        const row = el('div', { style: `padding:1px 4px 1px ${4 + d * 12}px;cursor:pointer;white-space:nowrap;${uid === sel ? 'background:#cfe0ff;font-weight:bold;' : ''}${hidden ? 'color:#999;text-decoration:line-through;' : ''}`, onclick: () => select(uid) }, eye, ` ${uid}  ${Math.round(r.width)}x${Math.round(r.height)}`, kids(e).length ? into : '');
        row.onmouseenter = () => { place(hov, e); hovLab.textContent = uid; }; row.onmouseleave = () => { hov.style.display = 'none'; }; return row; }));
    };
    function refresh(live) { const v = (sel && work[sel]) || {}; nx.value = v.x || 0; ny.value = v.y || 0; nw.value = v.w || 0; nh.value = v.h || 0; zin.value = v.z != null ? v.z : curZ(); for (const [k, o] of Object.entries(sliders)) { const val = v[k] != null ? v[k] : o.def; o.i.value = val; o.out.textContent = val; } selLab.textContent = (sel || 'Nothing selected') + ((sel && work[sel] && work[sel].lock) ? '   [locked: ' + work[sel].lock.mode + ']' : ''); if (live) apply({ [sel]: work[sel] }); place(box, sel ? all(sel).find((e) => e.getClientRects().length) : null); }
    function select(uid) { sel = uid; refresh(); renderLayers(); }
    let stack = []; let last = null; let drag2 = null;
    const stackAt = (x, y) => { const seen = []; for (const t of document.elementsFromPoint(x, y)) { const e = t.closest && t.closest('[data-uid]'); if (e && !e.closest('[data-layout-panel]') && !seen.includes(e)) seen.push(e); if (t.hasAttribute && t.hasAttribute('data-uid') && !t.closest('[data-layout-panel]') && !seen.includes(t)) seen.push(t); } return seen; };
    const showStack = () => { stackBox.replaceChildren(...stack.map((e, i) => { const r = e.getBoundingClientRect(); const d = el('div', { style: 'padding:1px 4px;cursor:pointer;white-space:nowrap;' + (keyOf(e) === sel ? 'background:#cfe0ff;font-weight:bold' : ''), text: `${i + 1}. ${keyOf(e)}  ${Math.round(r.width)}x${Math.round(r.height)}`, onclick: () => select(keyOf(e)) }); d.onmouseenter = () => { place(hov, e); hovLab.textContent = keyOf(e); }; d.onmouseleave = () => { hov.style.display = 'none'; }; return d; })); if (!stack.length) stackBox.textContent = ' (move over the window)'; };
    const cycle = () => { if (!stack.length) return; const i = stack.findIndex((e) => keyOf(e) === sel); select(keyOf(stack[(i + 1) % stack.length])); showStack(); };
    const curZ = () => { const e = sel && all(sel)[0]; const z = e ? parseInt(getComputedStyle(e).zIndex, 10) : 0; return Number.isNaN(z) ? 0 : z; };
    const zStep = (d) => { if (!sel) return; const v = work[sel] = work[sel] || {}; v.z = (v.z != null ? v.z : curZ()) + d; refresh(true); };
    const zTo = (front) => { if (!sel) return; const zs = (stack.length ? stack : all(sel)).map((e) => { const z = parseInt(getComputedStyle(e).zIndex, 10); return Number.isNaN(z) ? 0 : z; }); const v = work[sel] = work[sel] || {}; v.z = front ? Math.max(0, ...zs) + 1 : Math.min(0, ...zs) - 1; refresh(true); };
    const inSel = (x, y) => { const e = sel && all(sel).find((q) => q.getClientRects().length); if (!e) return false; const r = e.getBoundingClientRect(); return x >= r.left && x <= r.right && y >= r.top && y <= r.bottom; };
    const down = (e) => {
      if (e.target.closest('[data-layout-panel]')) return; e.preventDefault(); e.stopPropagation();
      stack = stackAt(e.clientX, e.clientY); if (!stack.length) return;
      const same = last && Math.abs(last.x - e.clientX) < 4 && Math.abs(last.y - e.clientY) < 4; last = { x: e.clientX, y: e.clientY };
      if (e.altKey || (same && !drag)) { const i = stack.findIndex((q) => keyOf(q) === sel); select(keyOf(stack[(i + 1) % stack.length])); }
      else if (!(sel && inSel(e.clientX, e.clientY) && stack.some((q) => keyOf(q) === sel))) select(keyOf(stack[0]));
      showStack(); const v = work[sel] = work[sel] || {}; drag = { px: e.clientX, py: e.clientY, x: v.x || 0, y: v.y || 0, moved: false };
    };
    const move = (e) => {
      if (drag2) { const top = Math.max(0, Math.min(innerHeight - 60, e.clientY - drag2.dy)); panel.style.left = Math.max(0, Math.min(innerWidth - 80, e.clientX - drag2.dx)) + 'px'; panel.style.top = top + 'px'; panel.style.right = 'auto'; panel.style.bottom = 'auto'; panel.style.maxHeight = (innerHeight - top - 8) + 'px'; return; }
      if (drag && sel) { const v = work[sel]; const nx2 = Math.round(drag.x + e.clientX - drag.px), ny2 = Math.round(drag.y + e.clientY - drag.py); if (nx2 !== (v.x || 0) || ny2 !== (v.y || 0)) { drag.moved = true; last = null; } v.x = nx2; v.y = ny2; refresh(true); return; }
      if (e.target.closest('[data-layout-panel]')) return;
      stack = stackAt(e.clientX, e.clientY); showStack(); if (stack[0]) { place(hov, stack[0]); hovLab.textContent = keyOf(stack[0]); } else hov.style.display = 'none'; };
    const up = () => { drag = null; drag2 = null; };
    title.addEventListener('mousedown', (e) => { if (e.target.textContent === '\u2013') return; const r = panel.getBoundingClientRect(); drag2 = { dx: e.clientX - r.left, dy: e.clientY - r.top }; e.preventDefault(); e.stopPropagation(); });
    title.addEventListener('dblclick', (e) => { e.stopPropagation(); fold(); });
    const swallow = (e) => { if (!e.target.closest('[data-layout-panel]')) { e.preventDefault(); e.stopPropagation(); } };
    const key = (e) => {
      if (e.key === 'Escape') { stop(false); e.preventDefault(); return; }
      if (!sel || !/^Arrow/.test(e.key) || e.target.closest('[data-layout-panel] input')) return; e.preventDefault(); e.stopPropagation();
      const st = e.shiftKey ? 10 : 1; const v = work[sel] = work[sel] || {}; const dx = e.key === 'ArrowRight' ? st : e.key === 'ArrowLeft' ? -st : 0; const dy = e.key === 'ArrowDown' ? st : e.key === 'ArrowUp' ? -st : 0;
      if (e.altKey) { v.w = (v.w || 0) + dx; v.h = (v.h || 0) + dy; } else { v.x = (v.x || 0) + dx; v.y = (v.y || 0) + dy; } refresh(true); };
    document.addEventListener('mousedown', down, true); document.addEventListener('mousemove', move, true); document.addEventListener('mouseup', up, true);
    document.addEventListener('click', swallow, true); document.addEventListener('dblclick', swallow, true); document.addEventListener('keydown', key, true);
    document.body.append(hov, box, panel);
    function stop(keep) {
      document.removeEventListener('mousedown', down, true); document.removeEventListener('mousemove', move, true); document.removeEventListener('mouseup', up, true);
      document.removeEventListener('click', swallow, true); document.removeEventListener('dblclick', swallow, true); document.removeEventListener('keydown', key, true);
      hov.remove(); box.remove(); panel.remove(); editing = null;
      if (!keep) { const old = JSON.parse(saved); for (const k of new Set([...Object.keys(work), ...Object.keys(old)])) { clear(k); } apply(old); }
    }
    editing = { stop };
  }
  A.layout = { apply, edit };
  document.addEventListener('keydown', (e) => { if (e.ctrlKey && e.altKey && (e.key === 'l' || e.key === 'L')) { e.preventDefault(); edit(); } });
})(window);
