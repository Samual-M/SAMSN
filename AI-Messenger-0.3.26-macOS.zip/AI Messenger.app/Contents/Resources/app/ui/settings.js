/* settings.js - the Settings window (inspired by opencode's settings) and configurable keyboard shortcuts. */
(function (g) {
  'use strict';
  const A = g.AIM; const { el, toast, pageWin } = A; const P = g.Pages;

  // ---------- keyboard shortcuts ----------
  const ACTIONS = [['newChat', 'New conversation', 'Ctrl+Shift+O'], ['cycleEffort', 'Cycle reasoning effort', 'Alt+T'], ['regenerate', 'Regenerate last reply', 'Ctrl+R'], ['toggleSidebar', 'Show / hide conversations column', 'Ctrl+B'], ['focusSearch', 'Search conversations', 'Ctrl+K'], ['settings', 'Open Settings', 'Ctrl+,']];
  const combo = (e) => {
    if (['Control', 'Shift', 'Alt', 'Meta'].includes(e.key)) return '';
    let key = e.key.length === 1 ? e.key.toUpperCase() : e.key; if (key === ' ') key = 'Space';
    if (e.altKey && /^Key[A-Z]$/.test(e.code)) key = e.code.slice(3); else if (e.altKey && /^Digit\d$/.test(e.code)) key = e.code.slice(5);
    const m = []; if (e.ctrlKey || e.metaKey) m.push('Ctrl'); if (e.altKey) m.push('Alt'); if (e.shiftKey) m.push('Shift');
    return [...m, key].join('+');
  };
  const current = () => Object.assign(Object.fromEntries(ACTIONS.map((a) => [a[0], a[2]])), (A.settings().keybinds) || {});
  A.keybinds = { ACTIONS, combo, current, match(e) { const c = combo(e).toLowerCase(); if (!c || !/\+|^F\d+$/.test(c)) return null; const k = current(); return (ACTIONS.find((a) => (k[a[0]] || '').toLowerCase() === c) || [])[0] || null; } };

  // ---------- window ----------
  const EFFORTS = [['', 'Default (let the model decide)'], ['off', 'Off (no extended thinking)'], ['low', 'Low'], ['medium', 'Medium'], ['high', 'High'], ['max', 'Max']];
  P.settings = function (startTab) {
    const S = A.settings(); const st = A.state; const d = { // staged values
      defaultContact: S.defaultContact || '', defaultEffort: S.defaultEffort || '', showReasoning: S.showReasoning || 'collapsed', instructions: S.instructions || '',
      contextMessages: S.contextMessages || 0, keybinds: Object.assign({}, S.keybinds || {}), fontPx: S.fontPx || 13 };
    const sel = (opts, val, on) => { const s = el('select', { style: 'width:100%;font:inherit' }, ...opts.map(([v, t]) => el('option', { value: v, text: t, selected: String(v) === String(val) }))); s.onchange = () => on(s.value); return s; };
    const row = (label, ctl, note) => el('div', { style: 'margin:0 0 12px' }, el('div', { style: 'font-weight:bold;margin-bottom:3px', text: label }), ctl, note ? el('div', { style: 'font-size:8pt;color:#6a7ea8;margin-top:3px;line-height:1.35', text: note }) : '');
    const panels = {
      General: () => [
        row('Default model for new conversations', sel([['', 'The one I used last'], ...st.contacts.filter((c) => !c.blocked).map((c) => [c.id, `${c.name}  <${c.model}>`])], d.defaultContact, (v) => { d.defaultContact = v; }), 'The model a fresh conversation starts with. You can still change it in the "To:" box.'),
        row('Default reasoning effort', sel(EFFORTS, d.defaultEffort, (v) => { d.defaultEffort = v; }), 'Used by new conversations. Change it for one conversation with the Reasoning box above the chat, or press Alt+T. Only models that support it (Claude with extended thinking, OpenAI reasoning models, Ollama thinking models) use it; others ignore it.'),
        row('Show the model\'s thinking', sel([['collapsed', 'Collapsed (click to open)'], ['open', 'Always open'], ['hidden', 'Hidden']], d.showReasoning, (v) => { d.showReasoning = v; }), 'Some models stream their reasoning before the answer.'),
        el('div', { style: 'display:flex;gap:6px;flex-wrap:wrap' }, el('button', { class: 'btn', text: 'More options (messages, sounds, privacy)...', onclick: () => P.options() }), el('button', { class: 'btn', text: 'Themes...', onclick: () => P.versionThemes() }))],
      Instructions: () => { const ta = el('textarea', { style: 'width:100%;height:230px;box-sizing:border-box;font:inherit;user-select:text', placeholder: 'For example: Answer briefly. Use metric units. I am a Linux user.' }); ta.value = d.instructions; ta.oninput = () => { d.instructions = ta.value; };
        return [row('Custom instructions for every conversation', ta, 'Sent to the model before project instructions and the contact\'s own system prompt. Stored only on this computer.')]; },
      Context: () => { const n = el('input', { type: 'number', min: 0, max: 1000, value: d.contextMessages, style: 'width:100px;font:inherit' }); n.oninput = () => { d.contextMessages = Math.max(0, Math.min(1000, Number(n.value) || 0)); };
        return [row('Send only the last N messages (0 = everything)', n, 'Keeps very long conversations inside a model\'s context window and lowers cost. Older messages stay in your history; the model just stops seeing them.')]; },
      'Keyboard shortcuts': () => { const rows = A.keybinds.ACTIONS.map(([k, label, def]) => { const inp = el('input', { readonly: true, value: d.keybinds[k] != null ? d.keybinds[k] : def, style: 'width:150px;font:inherit;text-align:center;cursor:pointer', title: 'Click, then press the new shortcut. Backspace clears it.' });
          inp.onkeydown = (e) => { e.preventDefault(); e.stopPropagation(); if (e.key === 'Backspace' || e.key === 'Delete') { d.keybinds[k] = ''; inp.value = ''; return; } if (e.key === 'Escape') { inp.blur(); return; } const c = A.keybinds.combo(e); if (!c || !/\+|^F\d+$/.test(c)) return; d.keybinds[k] = c; inp.value = c; };
          return el('div', { style: 'display:flex;align-items:center;gap:8px;margin:0 0 7px' }, el('div', { style: 'flex:1', text: label }), inp, el('button', { class: 'btn', text: 'Reset', onclick: () => { delete d.keybinds[k]; inp.value = def; } })); });
        return [...rows, el('div', { style: 'font-size:8pt;color:#6a7ea8', text: 'Your browser keeps a few shortcuts for itself (Ctrl+T, Ctrl+N, Ctrl+W), so those cannot be used here.' })]; },
      Appearance: () => [row('Chat text size', sel([[11, 'Small'], [13, 'Normal'], [17, 'Large'], [22, 'Huge']], d.fontPx, (v) => { d.fontPx = Number(v); })), el('div', { style: 'display:flex;gap:6px' }, el('button', { class: 'btn', text: 'Themes (MSN versions, MSN 8.0)...', onclick: () => P.versionThemes() }), el('button', { class: 'btn', text: 'Font and colour...', onclick: () => P.fontDialog() })),
        el('div', { style: 'font-size:8pt;color:#6a7ea8;margin-top:8px', text: 'Drag the line between the conversations column and the chat to resize it; double-click the line to reset.' })],
    };
    const names = Object.keys(panels); let tab = names.includes(startTab) ? startTab : names[0];
    const nav = el('div', { style: 'width:150px;flex:none;border-right:1px solid #b4c8e6;padding:6px 0;overflow:auto' }); const panel = el('div', { style: 'flex:1;min-width:0;padding:10px 14px;overflow:auto' });
    const root = el('div', { style: 'display:flex;height:100%' }, nav, panel);
    const draw = () => { nav.replaceChildren(...names.map((n) => el('div', { text: n, style: `padding:6px 12px;cursor:pointer;${n === tab ? 'background:#c9dcf6;font-weight:bold' : ''}`, onclick: () => { tab = n; draw(); } }))); panel.replaceChildren(...panels[tab]()); };
    draw();
    pageWin({ title: 'Settings', width: 700, height: 470, body: root, buttons: [
      { label: 'Save', primary: true, onClick: async () => {
        const patch = { defaultContact: d.defaultContact, defaultEffort: d.defaultEffort, showReasoning: d.showReasoning, instructions: d.instructions, contextMessages: d.contextMessages, keybinds: d.keybinds, fontPx: d.fontPx };
        try { await g.API.settings(patch); Object.assign(A.state.settings, patch); A.hooks.styleChanged && A.hooks.styleChanged(); A.hooks.refresh && A.hooks.refresh(); toast('Settings saved.'); } catch (e) { toast('Could not save: ' + e.message); return false; } } },
      { label: 'Cancel' }] });
  };
})(window);
