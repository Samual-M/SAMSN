/* AI Messenger behaviour layer (offline edition).
 * Look = original MSN Messenger 7.5 resources. Every command ID is bound to a local feature; nothing contacts MSN.
 */
(async () => {
  'use strict';
  const { el, esc, $, $$, hide, toast, dialog, info, confirmBox, notApplicable, avatar, sound, speak, applyTheme, richText, pageWin } = AIM;
  const P = Pages;
  const qs = new URLSearchParams(location.search);
  const CONV = qs.get('conv');
  const root = document.getElementById('root');
  root.style.cssText = 'position:absolute;inset:0;display:flex;flex-direction:column';
  const bc = new BroadcastChannel('aim');
  bc.addEventListener('message', (e) => { if (e.data && e.data.t === 'reload') location.reload(); });
  const tokenParam = () => { try { return sessionStorage.getItem('tok') || ''; } catch (e) { return ''; } };

  await Themes.boot();
  await Menus.load();
  setInterval(() => API.ping(), 5000); API.ping();

  // ---- extra menu entries (Help menu text is runtime-generated in the original) ----
  (function extendMenus() {
    const defs = Menus.raw(); const help = [['item', 'AI Messenger &Help Topics', 90001], ['item', '', 0], ['item', '&Home Page', 90002], ['item', '&Alerts History', 90003], ['item', 'My &Received Files', 90004], ['item', '', 0], ['item', 'Check for &Updates...', 90060], ['item', '', 0], ['item', '&About AI Messenger', 90005]];
    for (const id of ['200', '109', '110']) { const top = defs[id]; if (!top) continue; const h = top.find((x) => x[0] === 'popup' && /Help/.test(x[1])); if (h) h[2] = help; }
    for (const id of ['200', '109', '110']) { const top = defs[id]; if (!top) continue; const tl = top.find((x) => x[0] === 'popup' && /Tools/.test(x[1])); if (tl && !tl[2].some((x) => x[2] === 90020)) tl[2].unshift(['item', '&Settings...\tCtrl+,', 90040], ['item', '&Themes...', 90020], ['item', 'A&lign layout...\tCtrl+Alt+L', 90050], ['item', '', 0]); }
    const act = defs['109'] && defs['109'].find((x) => x[0] === 'popup' && /Actions/.test(x[1])); if (act) act[2].unshift(['item', 'Re&generate Last Reply', 90010], ['item', '', 0]);
  })();

  const STATUS = { 40166: ['Online', 2022], 40168: ['Busy', 2025], 40169: ['Be Right Back', 2024], 40170: ['Away', 2024], 40171: ['On The Phone', 2025], 40172: ['Out To Lunch', 2024], 40167: ['Appear Offline', 216] };
  const commonCmd = (id, label) => {
    switch (id) {
      case 90001: P.help(); return true; case 90020: P.versionThemes(); return true; case 90040: P.settings(); return true; case 90050: AIM.layout.edit(); return true; case 90002: case 40278: P.home(); return true; case 90003: case 40303: P.alerts(); return true; case 90004: case 40229: P.received(); return true; case 90005: P.about(); return true; case 90060: P.updates(); return true;
      case 40268: P.options(); return true; case 310: P.displayPicture(); return true; case 40350: P.emoticons(); return true; case 40260: P.backgrounds(); return true; case 40359: P.winks(); return true;
      case 40231: P.avSetup('audio'); return true; case 40243: P.avSetup('webcam'); return true; case 40198: P.inbox(); return true; case 40207: P.offline(); return true; case 40234: P.today(); return true;
      case 40204: P.activities('games'); return true; case 40329: case 40311: P.activities('activities'); return true;
      case 40266: case 40267: case 40261: return notApplicable(label, 'Mobile phones and MSN Direct watches are services run by MSN servers, so there is nothing to configure offline.'), true;
      case 690: case 691: case 692: return notApplicable(label, 'Mobile messaging billing was an MSN online service. There is no account or balance in this offline edition.'), true;
      case 40230: return notApplicable(label, 'Local profiles have no e-mail address to verify.'), true;
      case 40330: return notApplicable(label, 'Remote Assistance connected two people through Microsoft servers. It is not part of the offline edition.'), true;
      case 40294: return notApplicable(label, 'Contacts here are AI models, not MSN accounts, so there is nothing to upgrade.'), true;
      case 40232: case 40228: return notApplicable(label, 'Sending to mobile devices or MSN Direct watches used MSN gateways. Use a normal conversation instead.'), true;
      case 40027: case 40044: return notApplicable(label, 'Web-based windows cannot pin themselves above other windows. Most desktops offer this: right-click the window title bar and choose "Always on Top".'), true;
      case 40256: P.addressBook(); return true; case 40301: P.searchContacts('advanced'); return true; case 40302: P.searchContacts('interest'); return true;
    }
    return false;
  };
  const alertSound = () => { if (AIM.settings().soundOnReply) sound('newalert'); };

  // ====================================================================
  //                           SIGN-IN SCREEN
  // ====================================================================
  async function showLogon(session) {
    document.title = 'Sign In - AI Messenger'; root.replaceChildren();
    const w = UIF.create('logonFrameResID'); w.style.cssText = 'position:relative;flex:1;min-height:0'; root.append(w);
    hide(w, 'idLinksContent', 'logonstatuschooser', 'idlogonStatus', 'idShiftLock', 'idMakeDefaultUserChk', 'idRememberPasswordChk', 'idConnectNow', 'idSigningOut', 'idLogonProgressGroup', 'idForgotPasswordLink', 'idCantSignInLink');
    const hint = $(w, 'idSignInHint'); if (hint) hint.replaceChildren(el('span', { class: 'tx', text: 'Choose a local profile. Nothing is sent to MSN.', style: 'color:#000080' }));
    const emailBox = $(w, 'idEmailInput'); const pwBox = $(w, 'idPasswordInput'); const ut = $(w, 'idUserTile');
    const sel = el('select', { style: 'width:100%;font:inherit;border:1px solid #7f9db9;padding:2px;box-sizing:border-box' });
    const pw = el('input', { type: 'password', style: 'width:100%;font:inherit;border:1px solid #7f9db9;padding:2px;box-sizing:border-box;user-select:text' });
    const err = el('div', { class: 'logon-err' });
    const redraw = (s) => { sel.replaceChildren(...s.profiles.map((p) => el('option', { value: p.id, text: p.name + (p.locked ? ' (password)' : ''), selected: p.id === (s.last || s.profiles[0]?.id) })), el('option', { value: '__new', text: 'Create a new profile...' })); fit(); };
    const fit = () => { const cur = session.profiles.find((p) => p.id === sel.value); pw.disabled = !cur || !cur.locked; pw.style.opacity = pw.disabled ? .5 : 1; if (ut) ut.replaceChildren(avatar(cur ? cur.name : '?', 48)); };
    if (emailBox) emailBox.replaceChildren(sel); if (pwBox) pwBox.replaceChildren(pw);
    if (emailBox) emailBox.style.minWidth = '180px'; if (pwBox) pwBox.style.minWidth = '180px';
    const autoChk = $(w, 'idRememberMeChk'); if (autoChk) { const t = autoChk.querySelector('.tx'); if (t) t.textContent = 'Sign me in automatically'; autoChk.addEventListener('click', () => autoChk.classList.toggle('sel')); }
    const lbl = $(w, 'idPasswordLabel'); if (lbl) lbl.append(err);
    redraw(session); sel.onchange = () => { fit(); err.textContent = ''; };
    async function createProfile() {
      const r = await dialog({ title: 'New profile', rows: [{ key: 'name', label: 'Name:' }, { key: 'password', label: 'Password (optional):', type: 'password' }] }); if (!r || !r.name.trim()) { redraw(session); return; }
      session = await API.createProfile({ name: r.name.trim(), password: r.password }); sel.replaceChildren(...session.profiles.map((p) => el('option', { value: p.id, text: p.name + (p.locked ? ' (password)' : '') })), el('option', { value: '__new', text: 'Create a new profile...' })); sel.value = session.profiles[session.profiles.length - 1].id; fit();
    }
    async function go() {
      if (sel.value === '__new') return createProfile();
      err.textContent = ''; try { await API.signIn({ id: sel.value, password: pw.value, makeDefault: autoChk ? autoChk.classList.contains('sel') : false }); location.reload(); } catch (e) { err.textContent = e.message; }
    }
    $(w, 'idSignInBtn').addEventListener('click', go); pw.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    sel.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    const cancel = $(w, 'idCancelBtn'); if (cancel) cancel.addEventListener('click', () => window.close());
    const forget = $(w, 'idForgetMeBtn'); if (forget) { const t = forget.querySelector('.tx'); if (t) t.textContent = 'Forget me'; forget.addEventListener('click', async () => { const p = session.profiles.find((x) => x.id === sel.value); if (!p) return; if (await confirmBox('Forget me', `Delete the profile "${p.name}" with all its contacts and history?`, 'Delete')) { session = await API.deleteProfile(p.id); if (!session.profiles.length) await API.createProfile({ name: 'Default' }), (session = await API.session()); redraw(session); } }); }
    const gp = $(w, 'idGetPassportLink'); if (gp) { gp.style.display = ''; const t = gp.querySelector('.tx'); if (t) t.textContent = 'Create a new profile'; gp.addEventListener('click', createProfile); }
    const ln = $(w, 'idLinksContent'); if (ln) { ln.style.display = ''; hide(ln, 'idLinksContentColumn1'); }
    w.querySelectorAll('.tx').forEach((t) => { const x = t.textContent; if (/E-?mail address/i.test(x)) t.textContent = 'Profile:'; else if (/^Status:/.test(x)) { t.parentElement.style.display = 'none'; } else if (/Passport/i.test(x)) t.textContent = 'Offline edition - nothing is sent to MSN'; });
    sel.focus();
  }

  // ====================================================================
  //                           MAIN WINDOW
  // ====================================================================
  async function mainWindow() {
    setTimeout(() => sound('online'), 300); // the original played this when you signed in
    const state = AIM.state; document.title = 'AI Messenger';
    const w = UIF.create('mainwndresid'); w.style.cssText = 'position:relative;flex:1;min-height:0';
    const content = $(w, 'content');
    const mc = UIF.create('mainContentResID'); mc.style.flex = '1 1 0'; mc.style.minHeight = '0';
    const tg = $(w, 'togglecont'); const wrap = el('div', { class: 'u L-wrap col', style: 'grid-area:top' });
    content.insertBefore(wrap, tg); wrap.append(tg); tg.style.gridArea = '';
    let selected = null;
    const mb = await Menus.bar('200', (id, label) => cmd(id, label), { checked: (id) => (STATUS[id] && STATUS[id][0] === (AIM.state.profile.status || 'Online')) || (id === 40074 && AIM.settings().pictures === 'large') || (id === 40075 && AIM.settings().pictures === 'small') || (id === 40076 && AIM.settings().pictures === 'none') || (id === 40285 && AIM.settings().sortBy === 'groups') || (id === 40286 && AIM.settings().sortBy === 'status') || (id === 40307 && AIM.settings().labelBy === 'name') || (id === 40308 && AIM.settings().labelBy === 'model') });
    wrap.append(mb); content.append(mc); root.replaceChildren(w); applyTheme();
    w.addEventListener('click', (e) => { const b = e.target.closest('[data-cmd]'); if (!b) return; const id = Number(b.dataset.cmd); if (id === 1110) cmd(40003); else if (id === 40320 || id === 40321) { try { id === 40320 ? (window.resizeTo(330, 640)) : window.resizeTo(screen.availWidth, screen.availHeight); } catch (e2) {} } }, true);
    hide(w, 'adbannercontainer', 'statuscontainer', 'idZeroBuddyBubble', 'maininfobarholder', 'tabmanager', 'idSearchVerticals', 'idSearchVerticalPopup', 'browserstatus', 'adbrowser');
    $$(w, 'adbannercontainer').forEach((e) => e.remove());

    // --- "Me" area ---
    const ut = $(w, 'idMainWndUserTile'); const span = (t, css) => el('span', { class: 'tx', text: t, style: css });
    const fill = async () => {
      const s = AIM.state; ut.replaceChildren(avatar(s.profile.name || 'You', 48, 210, s.assets.avatar));
      $(w, 'idFriendlyName').replaceChildren(span(s.profile.name || 'You', 'font-weight:bold;color:#000080;cursor:pointer'));
      $(w, 'idStatus').replaceChildren(span(`(${s.profile.status || 'Online'})`, 'color:#000080'));
      $(w, 'idPSMText').replaceChildren(span(s.profile.psm || '<Type a personal message>', 'color:#6a7ea8;cursor:text;font-style:italic'));
      try { const ov = await API.overview(); const mail = $(w, 'mailcount'); const oim = $(w, 'oimcount'); const nm = ov.reduce((a, o) => a + o.undelivered, 0); if (mail) mail.replaceChildren(span(`(${ov.filter((o) => o.count).length})`, '')); if (oim) { oim.replaceChildren(span(nm ? `(${nm})` : '', '')); oim.style.display = nm ? '' : 'none'; } } catch (e) {}
    };
    const reload = async () => { AIM.state = await API.state(); await fill(); renderList(); applyTheme(); };
    AIM.hooks.refresh = reload;
    ut.addEventListener('click', () => P.displayPicture());
    $(w, 'idFriendlyName').addEventListener('click', async () => { const r = await dialog({ title: 'Change Display Name', rows: [{ key: 'name', label: 'Name:', value: AIM.state.profile.name }] }); if (r && r.name.trim()) { AIM.state.profile = await API.profile({ name: r.name.trim() }); fill(); } });
    $(w, 'idPSMText').addEventListener('click', async () => { const r = await dialog({ title: 'Personal Message', rows: [{ key: 'psm', label: 'Message:', value: AIM.state.profile.psm }] }); if (r) { AIM.state.profile = await API.profile({ psm: r.psm }); fill(); } });
    $(w, 'statuschooser').addEventListener('click', (e) => { const r = e.currentTarget.getBoundingClientRect(); Menus.closeAll(); const m = el('div', { class: 'menu', style: `left:${r.left}px;top:${r.bottom}px` }); for (const [id, [n]] of Object.entries(STATUS)) m.append(el('div', { class: 'it', text: n, onclick: () => { m.remove(); cmd(Number(id)); } })); document.body.append(m); setTimeout(() => document.addEventListener('mousedown', () => m.remove(), { once: true }), 0); });

    // --- toolbar buttons keep their original jobs (local versions of those pages) ---
    for (const [uid, c] of [['mailbtn', 40198], ['oimbtn', 40207], ['spacebtn', 90006], ['msntodaybtn', 40234]]) { const b = $(w, uid); if (b) b.dataset.cmd = c; }
    $(w, 'idAddContact').dataset.cmd = 40282;

    // --- contact list ---
    const list = $(w, 'buddylistview'); const scroll = el('div', { style: 'overflow-y:auto;position:absolute;inset:0;padding:2px 0' }); list.style.position = 'relative'; list.append(scroll);
    let filter = ''; const collapsed = new Set(); const busy = new Set();
    function renderList() {
      const S = AIM.settings(); const cs = AIM.state.contacts.filter((c) => (c.name + c.model).toLowerCase().includes(filter));
      scroll.replaceChildren(); if (selected && !AIM.state.contacts.some((c) => c.id === selected)) selected = null;
      const tpl = S.pictures === 'large' ? 'largebuddyitemtemplate' : 'smallbuddyitemtemplate';
      const mk = (c) => {
        const row = UIF.create(tpl); row.dataset.id = c.id; const set = (uid, text, css) => { const e = $(row, uid); if (e) e.replaceChildren(el('span', { class: 'tx', text, style: css || '' })); };
        set('buddyname', S.labelBy === 'model' ? c.model || c.name : c.name, 'font-weight:normal'); set('buddystatus', c.blocked ? ' (Blocked)' : busy.has(c.id) ? ' (Busy)' : c.presence === 'offline' ? ' (Offline)' : ' (Online)', 'color:#888'); set('idPSMText', c.psm || '', 'color:#6a7ea8');
        const bi = $(row, 'buddyicon'); if (bi) { if (S.pictures === 'none') bi.style.display = 'none'; else bi.replaceChildren(avatar(c.name, S.pictures === 'large' ? 32 : 20, null, c.avatar)); }
        const sel = $(row, 'listitemsel'); const li = $(row, 'listitem'); if (c.id === selected) sel.classList.add('sel');
        li.addEventListener('click', () => { selected = c.id; scroll.querySelectorAll('.sel').forEach((e) => e.classList.remove('sel')); sel.classList.add('sel'); });
        li.addEventListener('dblclick', () => openConv(c.id));
        li.addEventListener('contextmenu', (e) => { e.preventDefault(); selected = c.id; scroll.querySelectorAll('.sel').forEach((x) => x.classList.remove('sel')); sel.classList.add('sel'); contactMenu(e.clientX, e.clientY, c); });
        if (c.blocked) row.style.opacity = '.55'; else if (c.presence === 'offline') { row.style.opacity = '.7'; const nm = $(row, 'buddyname'); if (nm) nm.style.color = '#808080'; } return row;
      };
      const head = (text, key) => { const g = UIF.create('groupitemtemplate'); const n = $(g, 'groupname'); if (n) n.replaceChildren(el('span', { class: 'tx', text })); const gi = $(g, 'groupicon'); if (gi) { gi.src = collapsed.has(key) ? 'assets/img/1052.png' : 'assets/img/1051.png'; gi.style.margin = '0 2px'; } g.addEventListener('click', () => { collapsed.has(key) ? collapsed.delete(key) : collapsed.add(key); renderList(); }); return g; };
      const groups = S.sortBy === 'groups' ? [...AIM.state.groups, ''] : ['__online', '__offline', '__blocked'];
      for (const gname of groups) {
        const members = cs.filter((c) => S.sortBy === 'groups' ? (c.group || '') === gname : gname === '__blocked' ? c.blocked : c.blocked ? false : gname === '__offline' ? c.presence === 'offline' : c.presence !== 'offline');
        if (!members.length && (S.sortBy !== 'groups' || gname === '')) { if (gname === '__blocked' || gname === '') continue; }
        const title = S.sortBy === 'groups' ? (gname || 'Other Contacts') : gname === '__blocked' ? 'Blocked' : gname === '__offline' ? 'Offline' : 'Online'; if (!members.length && S.sortBy !== 'groups') continue;
        scroll.append(head(`${title} (${members.length})`, gname)); if (!collapsed.has(gname)) members.forEach((c) => scroll.append(mk(c)));
      }
      if (!cs.length) scroll.append(el('div', { style: 'padding:8px 10px;color:#6a7ea8;font-style:italic', text: filter ? 'No matching contacts.' : 'Click "Add a Contact" to find an AI model on Hugging Face.' }));
    }
    function contactMenu(x, y, c) {
      const m = el('div', { class: 'menu', style: `left:${x}px;top:${y}px` }); const item = (label, fn, bold) => m.append(el('div', { class: 'it', text: label, style: bold ? 'font-weight:bold' : '', onclick: () => { m.remove(); fn(); } }));
      item('Send an Instant Message', () => openConv(c.id), true); item('Send a File or Photo...', () => openConv(c.id, { attach: true })); item('View Message History', () => P.history(c.id));
      m.append(el('div', { class: 'sep' })); item(c.blocked ? 'Unblock' : 'Block', async () => { await API.saveContact({ ...c, blocked: !c.blocked, config: c.config }); reload(); });
      const gs = AIM.state.groups; if (gs.length) { m.append(el('div', { class: 'sep' })); gs.forEach((gname) => item(`Move to ${gname}`, async () => { await API.saveContact({ ...c, group: gname, config: c.config }); reload(); })); if (c.group) item('Remove from group', async () => { await API.saveContact({ ...c, group: '', config: c.config }); reload(); }); }
      m.append(el('div', { class: 'sep' })); item('Properties...', async () => { await P.contactDialog(c); reload(); }); item('Delete Contact', () => cmd(40289)); item('Clear Message History', async () => { await API.clearHistory(c.id); toast('History cleared.'); });
      document.body.append(m); const r = m.getBoundingClientRect(); m.style.left = Math.min(x, innerWidth - r.width - 2) + 'px'; m.style.top = Math.min(y, innerHeight - r.height - 2) + 'px'; setTimeout(() => document.addEventListener('mousedown', () => m.remove(), { once: true }), 0);
    }

    // --- search box: filters contacts live; Enter / button searches all conversations ---
    const sbg = $(w, 'idSearchTextBackground'); if (sbg) { const t = sbg.querySelector('.tx'); if (t) t.textContent = 'Search contacts and messages...'; }
    const st = $(w, 'idSearchText'); const inp = el('input', { style: 'border:0;background:transparent;outline:none;width:100%;font:inherit;color:#000;position:relative;user-select:text' });
    const doSearch = () => { if (inp.value.trim()) P.searchHistory(inp.value.trim()); };
    if (st) { st.replaceChildren(inp); inp.addEventListener('input', () => { filter = inp.value.toLowerCase(); if (sbg) sbg.style.visibility = inp.value ? 'hidden' : 'visible'; renderList(); }); inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') doSearch(); }); }
    const sb = $(w, 'idSearchButton'); if (sb) sb.addEventListener('click', doSearch);

    window.addEventListener('focus', reload);
    bc.onmessage = (e) => { const d = e.data; if (d && d.busy !== undefined) { d.busy ? busy.add(d.id) : busy.delete(d.id); renderList(); } else if (d === 'reload') reload(); };

    function openConv(id, opts = {}) {
      const win = window.open(`/?conv=${encodeURIComponent(id)}&t=${tokenParam()}${opts.attach ? '&attach=1' : ''}${opts.resend ? '&resend=1' : ''}${opts.prefill ? '&prefill=' + encodeURIComponent(opts.prefill) : ''}`, 'conv_' + id, 'popup,width=640,height=560');
      if (win) win.focus(); else toast('Popup blocked - allow popups for this window.');
    }
    AIM.hooks.openConv = openConv;
    const need = () => { const c = AIM.state.contacts.find((x) => x.id === selected); if (!c) toast('Select a contact first.'); return c; };

    async function cmd(id, label) {
      if (commonCmd(id, label)) return;
      const sc = AIM.state.contacts.find((c) => c.id === selected); const set = async (patch) => { await API.settings(patch); AIM.state.settings = Object.assign(AIM.state.settings, patch); renderList(); };
      switch (id) {
        case 90006: return P.space();
        case 40282: { await P.hfBrowser(); await reload(); return; }
        case 40289: { const c = need(); if (c && await confirmBox('Delete a Contact', `Delete "${c.name}" and its message history?`, 'Delete')) { await API.delContact(c.id); selected = null; reload(); } return; }
        case 40283: { const c = need(); if (c) { await P.contactDialog(c); reload(); } return; }
        case 40292: return P.history(selected || undefined);
        case 40004: { const c = need(); if (c) openConv(c.id); return; }
        case 40225: case 40275: { const c = need(); if (c) openConv(c.id, { attach: true }); return; }
        case 40205: { const c = need(); if (c) openConv(c.id); return; }
        case 40328: { const c = need(); if (c) P.winks((k) => openConv(c.id, { prefill: `*sends a wink: ${k.name}*` })); return; }
        case 40273: P.avSetup('audio'); return; case 40279: case 40049: P.avSetup('webcam'); return;
        case 40210: await API.signOut(); bc.postMessage({ signout: true }); location.reload(); return;
        case 40003: window.close(); return;
        case 40074: return set({ pictures: 'large' }); case 40075: return set({ pictures: 'small' }); case 40076: return set({ pictures: 'none' });
        case 40285: return set({ sortBy: 'groups' }); case 40286: return set({ sortBy: 'status' }); case 40307: return set({ labelBy: 'name' }); case 40308: return set({ labelBy: 'model' });
        case 40271: await P.groupOp('create'); return; case 40272: await P.groupOp('delete'); return; case 40295: await P.groupOp('rename'); return;
        case 40287: return P.exportContacts(); case 40288: await P.importContacts(); return reload();
        case 40306: case 40291: return toast('Contacts are sorted into Online (internet models) and Offline (models on this computer).');
        default:
          if (STATUS[id]) { AIM.state.profile = await API.profile({ status: STATUS[id][0] }); fill(); return; }
          return notApplicable(label);
      }
    }
    w.addEventListener('click', (e) => { const b = e.target.closest('[data-cmd]'); if (!b) return; const id = Number(b.dataset.cmd); if ([40282, 40198, 40207, 90006, 40234].includes(id)) cmd(id); });
    document.addEventListener('keydown', (e) => { const typing = /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName); if (typing) return; if (e.key === 'Delete' && selected) cmd(40289); if (e.key === 'Enter' && selected) openConv(selected); });
    bc.addEventListener('message', (e) => { if (e.data && e.data.signout) location.reload(); });
    await fill(); renderList();
    API.alerts().catch(() => {});
  }

  // ====================================================================
  //                        CONVERSATION WINDOW
  // ====================================================================
  // chat0 = a saved conversation, or a draft { id: null, participants: [contactId], project } that is saved when the first message is sent.
  // host = element to build into; shell = the workspace (null when opened as a stand-alone popup); opts = { attach, prefill, resend }.
  async function convWindow(chat0, root, shell, opts) {
    const state = AIM.state; let chat = chat0; let id = chat.id;
    const offs = []; const on = (t, ev, fn, o) => { t.addEventListener(ev, fn, o); offs.push(() => t.removeEventListener(ev, fn, o)); };
    const closeChat = () => { if (shell) shell.newChat(); else window.close(); };
    let creating = false;
    let effort = chat.effort || (AIM.settings().defaultEffort || '');
    const EFF_LABEL = { '': 'Default', off: 'Off', low: 'Low', medium: 'Medium', high: 'High', max: 'Max' };
    const provOf = () => (AIM.state.providers || []).find((p) => p.id === (contact && contact.provider));
    const efforts = () => { const e = (provOf() || {}).efforts || []; return e.length ? ['', ...e] : []; };
    const byId = (i) => AIM.state.contacts.find((c) => c.id === i);
    let participants = (chat.participants || []).filter(byId); if (!participants.length && AIM.state.contacts[0]) participants = [AIM.state.contacts[0].id];
    let contact = byId(participants[0]);
    if (!contact) { root.textContent = 'Add a contact first (File > Add a Contact (or the + next to Models)).'; return null; }
    const saveParts = () => { contact = byId(participants[0]); if (id) API.saveChat(id, { participants }).then(() => shell && shell.refresh()).catch(() => {}); try { localStorage.setItem('lastContact', participants[0]); } catch (e) {} };
    const names = () => participants.map((p) => byId(p).name).join(', ');
    if (!shell) document.title = `${names()} - Conversation`;
    const w = UIF.create('convframeresid'); w.style.cssText = 'position:relative;flex:1;min-height:0';
    let attachments = []; let controller = null; let streaming = false;
    const checkedFn = (c) => (c === 44026 && AIM.settings().showStd !== false) || (c === 40450 && AIM.settings().showFmt !== false) || (c === 40154 && hist.dir !== 'rtl') || (c === 40155 && hist.dir === 'rtl');
    const mb = shell ? null : await Menus.bar('109', (cid, label) => cmd(cid, label), { checked: checkedFn });
    root.replaceChildren(...(mb ? [mb] : []), w); applyTheme();
    w.addEventListener('click', (e) => { const b = e.target.closest('[data-cmd]'); if (b && Number(b.dataset.cmd) === 1110) closeChat(); }, true);
    hide(w, 'VoiceIMinputarea', 'adbrowsercontainer', 'p4appcontainerright1', 'p4taskbar', 'p4appcontainer', 'infobar', 'FlashWink', 'adbannercont', 'preroll', 'ink2textsendbtnbk', 'gripper', 'wallpaper', 'convhistorymimic', 'UsWebcamBtnSpacer', 'UsWebcamBtn', 'tomobileicon', 'mobiletaskbar', 'youfullscreen', 'YouWebCam', 'GetaWebcamLink', 'togglecont', 'inksendastextelem', 'inkpen', 'inkpensizedropdownbtn', 'inkeraser', 'inkerasersizedropdownbtn', 'inkundobtn', 'inkredobtn', 'inkcolordropdownbtn', 'inkbgnddropdownbtn', 'inkseparator');
    const tb = UIF.create('taskbar'); const topbar = $(w, 'topbarbase'); if (topbar) { topbar.after(tb); topbar.style.display = 'none'; } const tbs = [tb];
    hide(tb, 'blockbtn'); if (shell) hide(tb, 'minmaxclosetaskbar'); const bb = $(tb, 'blockbtn'); if (bb) bb.style.display = '';
    // right column: just the two display pictures, centred inside their frames (like the original window)
    hide(w, 'meaudio', 'youaudio', 'MeWebCam', 'GetaWebcamLink', 'exbtnme', 'exbtnyou', 'youhost', 'mehost');
    for (const u of ['clipperhyou', 'youcontainer', 'youview', 'youcontrol']) w.querySelectorAll(`[data-uid="${u}"]`).forEach((e) => { e.style.width = '100%'; e.style.minWidth = '0'; });
    w.querySelectorAll('[data-uid="avatarviewcontainer"]').forEach((e) => { e.style.justifyContent = 'center'; });
    const rosterBox = $(w, 'rostercontainer');
     // empty webcam row under each picture
        requestAnimationFrame(() => setTimeout(() => { const wr = w.getBoundingClientRect(); w.querySelectorAll('.bgpng').forEach((e) => { const r = e.getBoundingClientRect(); if (r.height > 0 && r.height <= 8 && r.width >= wr.width - 8 && r.top - wr.top < 8) e.style.display = 'none'; else if (r.width > 0 && r.width <= 14 && r.height <= 40 && r.left > wr.right - 16 && r.top - wr.top < 30) e.style.display = 'none'; }); }, 60));
  
    // content toolbar: icon buttons with a drop-down caret, like MSN 7.5 (the labels are shown as tooltips)
    for (const u of ['winkbtn', 'backgroundsbtn', 'themesbtn', 'emoticonbtn']) w.querySelectorAll(`[data-uid="${u}"]`).forEach((b) => {
      const tx = b.querySelector('.tx'); if (tx && u !== 'emoticonbtn') { b.title = tx.textContent.replace(/&/g, ''); tx.remove(); }
      if (!b.querySelector('.caret')) b.append(el('span', { class: 'caret', text: '\u25BE', style: 'font-size:7pt;color:#333;margin:0 3px 0 1px;align-self:center' }));
      b.style.width = 'auto'; b.style.minWidth = '0'; });
    { // bottom status bar, as in the original window (its text there was an advert; here it shows who you are chatting with)
      const cfr = $(w, 'convframeroot') || (w.dataset && w.dataset.uid === 'convframeroot' ? w : null); const hostEl = cfr && cfr.parentElement;
      if (hostEl && !hostEl.querySelector(':scope > .aim-statusbar')) {
        cfr.style.flex = '1 1 0'; cfr.style.minHeight = '0'; cfr.style.height = 'auto';
        const sb = el('div', { class: 'aim-statusbar', text: `Chatting with ${contact.name}` });
        sb.style.cssText = 'flex:none;height:20px;box-sizing:border-box;padding:3px 8px;font:8pt Tahoma,Verdana,sans-serif;color:#1d3f7a;background:linear-gradient(#fff,#e6edfb);border-top:1px solid #7f9db9;white-space:nowrap;overflow:hidden;text-overflow:ellipsis';
        hostEl.append(sb);
      }
    }
    { const iac0 = $(w, 'inputareacont'); if (iac0) iac0.style.boxShadow = 'inset 1px 0 0 #4f6ba0, inset -1px 0 0 #4f6ba0'; w.querySelectorAll('[data-uid="inkmodeinkelem"] .c-tabhover').forEach((t) => { t.style.display = 'none'; });
      // ink tab icons hang from the top edge of the strip; drop them so the pen and the orange-topped "A" are not clipped
      w.querySelectorAll('[data-uid="inkmodeinkelem"] [data-uid$=".art2"], [data-uid="inkmodetextelem"] [data-uid$=".art1"], [data-uid="inkmodetextelem"] [data-uid$=".art2"]').forEach((a) => { a.style.position = 'relative'; a.style.top = '4px'; }); }
    { const iac = $(w, 'inputareacont'); if (iac) { iac.style.minHeight = '84px'; iac.parentNode.style.minHeight = '84px'; iac.parentNode.style.height = '84px'; }
      const ia = $(w, 'inputarea'); if (ia) { ia.style.height = 'auto'; ia.style.minHeight = '0'; ia.style.flexShrink = '0'; let n = $(w, 'inputtoolbar'); while (n && n !== ia) { if (n.style) { n.style.height = 'auto'; if (getComputedStyle(n).display === 'grid') n.style.gridTemplateRows = 'auto'; } n = n.parentNode; } } }
    // drop-down arrow under each display picture and the little side tab, like MSN 7.5
    for (const [fu, cu, cmdName] of [['yourightsidecontainer', 'youavatarcaret', 'youMenu'], ['mecontainer', 'meavatarcaret', 'meMenu']]) {
      const fr = $(w, fu); if (!fr) continue; fr.style.position = 'relative'; const cr = $(w, cu);
      if (cr) { cr.style.justifyContent = 'center'; cr.style.alignItems = 'center'; cr.replaceChildren(el('span', { text: '\u25BE', style: 'font-size:8pt;color:#333;cursor:pointer', title: 'Picture options', onclick: () => cmd(cmdName) })); }
      fr.append(el('div', { style: 'position:absolute;right:-1px;top:34px;width:7px;height:22px;background:linear-gradient(#f4f7fd,#d5def2);border:1px solid #7f93c0;border-right:none;border-radius:4px 0 0 4px;font-size:6pt;line-height:22px;text-align:center;color:#334', text: '\u25C2' }));
    }
    // msn logo sits at the left end of the strip, next to the toolbar panel (as in MSN 7.5); the window buttons stay at the right
    w.querySelectorAll('[data-uid="msnlogo"]').forEach((e) => { e.style.marginLeft = '8px'; e.style.marginRight = 'auto'; });
    // stretch the tab curve to the full height of the toolbar panel so the swoosh meets its bottom edge
    { const tbc = $(w, 'tbcurve'); if (tbc) { tbc.style.height = '75px'; tbc.style.minHeight = '75px'; const im = tbc.firstElementChild; if (im && im.style) im.style.height = '100%'; tbc.style.zIndex = '2'; tbc.style.clipPath = 'inset(28px 0 0 0)'; const lay = tbc.previousElementSibling; const edge = lay && lay.querySelector(':scope > .L-edge'); if (edge) { edge.style.left = '30px'; edge.style.top = '-3px';
      const tsc = $(w, 'taskbarseccontainer'); if (tsc) { tsc.style.height = '29px'; tsc.style.minHeight = '29px'; tsc.style.backgroundSize = '100% 100%'; const cap = tsc.nextElementSibling; if (cap && cap.style) { cap.style.height = '40px'; cap.style.width = '39px'; cap.style.flex = 'none'; cap.style.alignSelf = 'flex-start'; cap.style.backgroundSize = '100% 100%'; } } } const strip = lay && lay.firstElementChild; if (strip) { strip.style.height = '28px'; strip.style.minHeight = '28px'; strip.style.flex = 'none'; strip.querySelectorAll('.bgpng').forEach((b) => { b.style.height = '100%'; }); } } }
    setTimeout(() => AIM.layout && AIM.layout.apply(), 250);
    // header
    const refreshHeader = () => {
      contact = byId(participants[0]) || contact; const tolink = $(w, 'tobar');
      if (tolink) {
        if (participants.length > 1) tolink.replaceChildren(el('span', { class: 'tx', text: names(), style: 'font-weight:bold' }));
        else { const sel = el('select', { class: 'modelpick', title: 'Choose the model for this conversation' }); for (const c of AIM.state.contacts.filter((x) => !x.blocked || x.id === participants[0])) sel.append(el('option', { value: c.id, text: `${c.name} <${c.model}>`, selected: c.id === participants[0] })); sel.onchange = () => { participants[0] = sel.value; saveParts(); refreshHeader(); sysLine(`Now talking to ${contact.name}.`); }; tolink.replaceChildren(sel); }
      }
      const inv = $(w, 'invitees'); const t = inv && inv.querySelector('.tx'); if (t) t.textContent = participants.length > 1 ? `${participants.length} in this chat` : (contact.model || 'Online');
      if (rosterBox) rosterBox.style.display = participants.length > 1 ? '' : 'none';
      shell && shell.effortChanged && shell.effortChanged();
      if (!shell) document.title = `${names()} - Conversation`; const yc = $(w, 'youusertile'); if (yc) yc.replaceChildren(avatar(contact.name, 96, null, contact.avatar));
    };
    const mec = $(w, 'meusertile'); if (mec) mec.replaceChildren(avatar(state.profile.name || 'You', 96, 210, state.assets.avatar)); refreshHeader();
    const tolink = $(w, 'tolink'); if (tolink) tolink.dataset.cmd = 35061;

    // history + input
    const hist = el('div', { id: 'history', style: 'position:absolute;inset:0' }); const ch = $(w, 'convhistory'); ch.replaceChildren(hist); ch.style.cssText += ';position:relative;overflow:hidden';
    const ci = $(w, 'convinput'); const ta = el('textarea', { id: 'msginput', style: 'position:absolute;inset:0;width:100%;height:100%' }); ci.replaceChildren(ta); ci.style.cssText += ';position:relative;overflow:hidden;min-height:72px';
    const chips = el('div', { id: 'chips', style: 'display:none' }); ci.parentNode.insertBefore(chips, ci);
    const sbEl = $(w, 'statusbartext'); const setStatus = (t) => { if (sbEl) sbEl.replaceChildren(el('span', { class: 'tx', text: t })); }; setStatus('');
    const sendb = $(w, 'sendbtn'); const sendTx = sendb && sendb.querySelector('.tx');
    const applyStyle = () => { const S = AIM.settings(); for (const e of [hist, ta]) { e.style.fontSize = (S.fontPx || 13) + 'px'; } ta.style.fontFamily = S.fontFamily || ''; ta.style.color = S.fontColor || ''; ta.style.fontWeight = S.bold ? 'bold' : ''; ta.style.fontStyle = S.italic ? 'italic' : ''; hist.style.background = S.background ? `linear-gradient(rgba(255,255,255,.78),rgba(255,255,255,.78)),url(${S.background}) center/cover` : '#fff'; };
    AIM.hooks.styleChanged = applyStyle; applyStyle();
    const showBars = () => { const S = AIM.settings(); tbs.slice(0, 1).forEach((t) => { t.style.display = S.showStd === false ? 'none' : ''; }); const it = $(w, 'inputtoolbar'); if (it) it.style.display = S.showFmt === false ? 'none' : ''; }; showBars();

    // ---- messages ----
    const nameOf = (m) => m.role === 'user' ? (AIM.state.profile.name || 'You') : (byId(m.from) || contact).name;
    function renderMsg(m) {
      const d = el('div', { class: 'm' }); const S = AIM.settings();
      const mine = m.role === 'user';
      d.append(el('div', { class: 'who', text: `${S.timestamps && m.t ? '[' + new Date(m.t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + '] ' : ''}${nameOf(m)} says:` }));
      const rs = AIM.settings().showReasoning || 'collapsed'; if (m.reasoning && rs !== 'hidden') d.append(el('details', { class: 'think', open: rs === 'open' }, el('summary', { text: 'Thought process' }), el('div', { class: 'think-body', text: m.reasoning })));
      const body = el('div', { class: 'body' }); body.innerHTML = richText(m.text);
      if (mine) { body.style.fontFamily = S.fontFamily || ''; body.style.color = S.fontColor || ''; if (S.bold) body.style.fontWeight = 'bold'; if (S.italic) body.style.fontStyle = 'italic'; }
      if (m.sticker) body.prepend(el('img', { src: `assets/winks/${m.sticker}.png`, style: 'height:64px;display:block', alt: 'wink' }));
      for (const a of m.attachments || []) { if (/^data:image/.test(a.dataUrl || '')) body.append(el('img', { class: 'att', src: a.dataUrl })); else body.append(el('div', { class: 'who', text: '\u{1F4CE} ' + a.name })); }
      d.append(body); d.append(el('button', { class: 'copybtn', title: 'Copy message', text: 'Copy', onclick: () => { const t = m.text || body.dataset.raw || body.textContent; (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => toast('Copied.'), () => toast('Copy failed.')); } })); hist.append(d); hist.scrollTop = hist.scrollHeight; return body;
    }
    hist.addEventListener('click', (e) => { const b = e.target.closest && e.target.closest('.precopy'); if (!b) return; const pre = b.parentNode.cloneNode(true); pre.querySelector('.precopy').remove(); (navigator.clipboard ? navigator.clipboard.writeText(pre.textContent) : Promise.reject()).then(() => toast('Code copied.'), () => toast('Copy failed.')); });
    const sysLine = (t) => { hist.append(el('div', { class: 'sys', text: t })); hist.scrollTop = hist.scrollHeight; };
    const history = id ? await API.history(id) : [];
    for (const m of history) if (m.from && byId(m.from) && !participants.includes(m.from)) participants.push(m.from);
    refreshHeader(); history.forEach(renderMsg);
    sysLine(history.length ? `Conversation resumed with ${names()}.` : `You are now chatting with ${names()}. Never give out your password or credit card number in a conversation.`);

    async function send(opts = {}) {
      if (streaming) { controller && controller.abort(); return; }
      if (creating) return;
      if (opts.regenerate && !id) return;
      const text = (opts.text != null ? opts.text : ta.value).trim();
      if (!opts.regenerate && !text && !attachments.length) return;
      const payload = opts.regenerate ? { regenerate: true } : { text, attachments, sticker: opts.sticker }; if (efforts().length) payload.effort = effort;
      if (!opts.regenerate) { renderMsg({ role: 'user', text, attachments, t: Date.now(), sticker: opts.sticker }); if (opts.text == null) ta.value = ''; attachments = []; drawChips(); }
      else { let last; while ((last = [...hist.querySelectorAll('.m')].pop()) && !last.querySelector('.who').textContent.includes((AIM.state.profile.name || 'You') + ' says')) last.remove(); }
      if (!id) { creating = true; try { chat = await API.newChat({ participants, project: shell ? shell.project() : '' }); id = chat.id; shell && shell.created(chat, ctl); } catch (e) { creating = false; sysLine('Could not start the conversation: ' + e.message); return; } creating = false; }
      streaming = true; shell && shell.busy(id, true); controller = new AbortController(); bc.postMessage({ id, busy: true });
      if (sendTx) sendTx.textContent = 'Stop'; const bodies = {}; const accs = {};
      const open = (from) => { if (!bodies[from]) { bodies[from] = renderMsg({ role: 'assistant', from, text: '', t: Date.now() }); accs[from] = ''; } return bodies[from]; };
      let anyOk = false, lastText = '';
      try {
        await API.chat(id, Object.assign(payload, { signal: controller.signal }), {
          start: (from) => { setStatus(`${(byId(from) || contact).name} is typing a message...`); open(from); },
          reasoning: (t, from) => { const rs = AIM.settings().showReasoning || 'collapsed'; if (rs === 'hidden') return; const f = from || participants[0]; const bd = open(f); let det = bd.parentNode.querySelector('details.think'); if (!det) { det = el('details', { class: 'think', open: rs === 'open' }, el('summary', { text: 'Thinking...' }), el('div', { class: 'think-body' })); bd.parentNode.insertBefore(det, bd); } det.lastChild.textContent += t; hist.scrollTop = hist.scrollHeight; },
          delta: (d, from) => { const f = from || participants[0]; open(f); accs[f] += d; bodies[f].dataset.raw = accs[f]; bodies[f].innerHTML = richText(accs[f]); hist.scrollTop = hist.scrollHeight; },
          end: (from) => { anyOk = true; lastText = accs[from] || ''; },
          error: (msg, from) => { const b = open(from || participants[0]); b.append(el('div', { class: 'err', text: 'Error: ' + msg })); if (/llama-server|Set Up Local Runtime/.test(msg)) b.append(el('button', { class: 'btn', text: 'Set up local runtime...', onclick: () => P.runtimeSetup() })); setStatus('Message could not be delivered.'); sound('newemail'); },
        });
        if (anyOk) { setStatus(`Last message received on ${new Date().toLocaleString()}.`); if (!document.hasFocus()) alertSound(); else if (AIM.settings().soundOnReply) sound('type'); speak(lastText); }
      } catch (e) { if (e.name !== 'AbortError') { const b = open(participants[0]); b.append(el('div', { class: 'err', text: 'Error: ' + e.message })); setStatus('Message could not be delivered.'); } else setStatus('Stopped.'); }
      hist.querySelectorAll('details.think > summary').forEach((x) => { if (x.textContent === 'Thinking...') x.textContent = 'Thought process'; });
      streaming = false; controller = null; if (sendTx) sendTx.textContent = 'Send'; bc.postMessage({ id, busy: false }); bc.postMessage('reload'); shell && (shell.busy(id, false), shell.refresh()); ta.focus();
    }
    function drawChips() { chips.replaceChildren(); chips.style.display = attachments.length ? 'flex' : 'none'; attachments.forEach((a, i) => chips.append(el('span', { class: 'chip', text: '\u{1F4CE} ' + a.name + ' ×', style: 'cursor:pointer', onclick: () => { attachments.splice(i, 1); drawChips(); } }))); }
    async function addFiles(files) { for (const file of files) { if (file.size > 8e6) { toast(file.name + ' is too large (8 MB max).'); continue; } if (file.type.startsWith('image/')) attachments.push({ name: file.name, dataUrl: await AIM.readDataUrl(file) }); else attachments.push({ name: file.name, text: await file.text() }); } drawChips(); ta.focus(); }
    const pickFiles = async () => addFiles(await AIM.pickFile('image/*,.txt,.md,.json,.csv,.js,.ts,.py,.html,.css,.log,.xml,.yml,.yaml,.c,.cpp,.java,.go,.rs,.sh', true));
    ta.addEventListener('keydown', (e) => { const enter = e.key === 'Enter' && !e.isComposing; const sendKey = AIM.settings().enterSends === false ? (enter && (e.ctrlKey || e.metaKey)) : (enter && !e.shiftKey); if (sendKey) { e.preventDefault(); send(); } if (e.key === 'Escape' && streaming) controller.abort(); });
    ta.addEventListener('paste', (e) => { for (const it of e.clipboardData.items) if (it.type.startsWith('image/')) { addFiles([it.getAsFile()]); e.preventDefault(); } });
    w.addEventListener('dragover', (e) => e.preventDefault()); w.addEventListener('drop', (e) => { e.preventDefault(); addFiles([...e.dataTransfer.files]); });

    const EMOJI = ['\u{1F600}', '\u{1F642}', '\u{1F609}', '\u{1F60A}', '\u{1F60D}', '\u{1F914}', '\u{1F60E}', '\u{1F622}', '\u{1F44D}', '\u{1F44E}', '\u{1F389}', '\u{2764}\u{FE0F}', '\u{1F525}', '\u{1F4A1}', '\u{2705}', '\u{274C}'];
    function emojiPicker(x, y) { if (window.Msn80 && Msn80.on()) return Msn80.picker(x, y, (t) => { ta.setRangeText(t + ' ', ta.selectionStart, ta.selectionEnd, 'end'); ta.focus(); }); const m = el('div', { class: 'menu', style: `left:${x}px;top:${y}px;display:grid;grid-template-columns:repeat(8,24px);padding:4px` }); const put = (t) => { ta.setRangeText(t, ta.selectionStart, ta.selectionEnd, 'end'); m.remove(); ta.focus(); }; EMOJI.forEach((e) => m.append(el('div', { text: e, style: 'font-size:15px;text-align:center;cursor:pointer;padding:2px', onclick: () => put(e) }))); for (const e of AIM.state.assets.emoticons || []) m.append(el('img', { src: e.dataUrl, title: e.shortcut, style: 'height:20px;margin:2px;cursor:pointer', onclick: () => put(e.shortcut) })); document.body.append(m); setTimeout(() => document.addEventListener('mousedown', () => m.remove(), { once: true }), 0); }
    const transcript = async () => (await API.history(id)).map((m) => `[${new Date(m.t).toLocaleString()}] ${nameOf(m)}:\n${m.text}\n`).join('\n');
    async function save(asDownload) { const text = await transcript(); const name = `${contact.name} - ${new Date().toISOString().slice(0, 10)}.txt`; const r = await API.saveReceived({ name, text }); if (asDownload) AIM.download(name, text); sound('vimdone'); toast(asDownload ? 'Saved and downloaded.' : `Saved to Received Files as "${r.name}".`); }
    const nudge = () => { root.classList.remove('nudging'); void root.offsetWidth; root.classList.add('nudging'); sound('nudge'); setTimeout(() => root.classList.remove('nudging'), 1200); sysLine('You have just sent a nudge.'); };
    async function invite() {
      const cands = AIM.state.contacts.filter((c) => !participants.includes(c.id) && !c.blocked); if (!cands.length) return info('Invite a Contact', '<div style="padding:12px">There are no other contacts to invite. Add more under File &gt; Add a Contact (or the + next to Models).</div>');
      const r = await dialog({ title: 'Invite a Contact to this Conversation', rows: [{ key: 'c', label: 'Contact:', type: 'select', options: cands.map((c) => ({ value: c.id, label: c.name })) }], ok: 'Invite' });
      if (r) { participants.push(r.c); saveParts(); refreshHeader(); sysLine(`${byId(r.c).name} has joined the conversation. Every message now goes to all participants.`); sound('online'); }
    }
    async function toggleBlock() { const c = byId(participants[0]); const nb = !c.blocked; await API.saveContact({ ...c, blocked: nb, config: c.config }); AIM.state = await API.state(); sysLine(nb ? `${c.name} is now blocked.` : `${c.name} was unblocked.`); bc.postMessage('reload'); }
    const snapshot = () => P.avSetup('webcam', (url) => { attachments.push({ name: 'snapshot.jpg', dataUrl: url }); drawChips(); toast('Snapshot attached to your next message.'); });
    const mailTo = async () => { const h = await API.history(id); const last = [...h].reverse().find((m) => m.role === 'assistant'); location.href = `mailto:?subject=${encodeURIComponent('Chat with ' + contact.name)}&body=${encodeURIComponent(last ? last.text.slice(0, 1800) : '')}`; };

    async function cmd(cid, label) {
      if (commonCmd(cid, label)) return;
      const ex = (c) => { ta.focus(); document.execCommand(c); }; const setSz = (px) => { AIM.state.settings.fontPx = px; API.settings({ fontPx: px }); applyStyle(); };
      switch (cid) {
        case 40014: return save(false); case 40015: return save(true);
        case 40017: case 1110: return closeChat();
        case 40292: return P.history(id);
        case 40223: return ex('undo'); case 40218: return ex('cut'); case 40219: return ex('copy');
        case 40220: return navigator.clipboard.readText().then((t) => ta.setRangeText(t, ta.selectionStart, ta.selectionEnd, 'end')).catch(() => ex('paste'));
        case 40221: return ex('delete'); case 40222: ta.focus(); return ta.select();
        case 40211: return P.fontDialog();
        case 40216: return setSz(22); case 40215: return setSz(17); case 40214: return setSz(13); case 40213: return setSz(11); case 40212: return setSz(9);
        case 40154: hist.dir = ta.dir = 'ltr'; return; case 40155: hist.dir = ta.dir = 'rtl'; return;
        case 40275: case 40225: return pickFiles();
        case 40269: return invite();
        case 888: return P.history(id || undefined);
        case 689: return nudge(); case 90010: return send({ regenerate: true });
        case 40328: return P.winks((k) => send({ text: `*sends a wink: ${k.name}*`, sticker: k.id }));
        case 40205: return mailTo();
        case 40259: return P.backgrounds(() => applyStyle());
        case 40273: return P.avSetup('audio'); case 40279: case 40049: return snapshot();
        case 40263: return info('Add to Contacts', `<div style="padding:12px">${esc(contact.name)} is already in your contact list.</div>`);
        case 40276: return toggleBlock();
        case 44026: case 40450: { const k = cid === 44026 ? 'showStd' : 'showFmt'; AIM.state.settings[k] = AIM.settings()[k] === false; API.settings({ [k]: AIM.state.settings[k] }); showBars(); return; }
        case 35061: await P.contactDialog(contact); AIM.state = await API.state(); return;
        case 11034: return snapshot(); case 11033: return toast('No camera is streaming.'); case 11046: case 11047: { const on = !AIM.settings().readAloud; AIM.state.settings.readAloud = on; API.settings({ readAloud: on }); return toast(on ? 'Replies will be read aloud.' : 'Read-aloud is off.'); }
        default: return shell && shell.cmd ? shell.cmd(cid, label) : notApplicable(label);
      }
    }
    // toolbar + taskbar buttons (original ids, local jobs)
    const UIDCMD = { searchbtn: 888, fontbtn: 40211, emoticonbtn: 'emoji', winkbtn: 40328, backgroundsbtn: 40259, themesbtn: 'theme', buzzbtn: 689, invitetoimbtn: 40269, sendfilebtn: 40275, webcambtn: 40049, audiobtn: 40273, appdropdownbtn: 40329, gamesdropdownbtn: 40204, blockbtn: 40276, colorizedropdownbtn: 'theme', exbtnme: 11034, medropdownbtn: 'meMenu', youdropdownbtn: 'youMenu', MeWebcamButton: 11034, tolink: 35061 };
    w.addEventListener('click', (e) => {
      const b = e.target.closest('.cmd'); if (!b) return; const u = b.dataset.uid; if (u === 'sendbtn') return send();
      const c = UIDCMD[u]; if (c == null) return;
      if (c === 'emoji') { const r = b.getBoundingClientRect(); return emojiPicker(r.left, r.top - 70); }
      if (c === 'theme') return P.themes();
      if (c === 'meMenu' || c === 'youMenu') { const r = b.getBoundingClientRect(); return Menus.context(c === 'meMenu' ? '11017' : '11018', r.left, r.bottom, cmd, {}); }
      cmd(c);
    });
    const bz = $(w, 'buzzbtn'); if (bz) bz.title = 'Send a nudge'; const eb = $(w, 'emoticonbtn'); if (eb) eb.title = 'Insert an emoticon';
    // keyboard shortcut for regenerate
    if (!shell) on(document, 'keydown', (e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'r') { e.preventDefault(); send({ regenerate: true }); } });
    if (!shell) {
      on(bc, 'message', async (e) => { if (e.data && e.data.signout) window.close(); if (e.data === 'reload') { try { AIM.state = await API.state(); } catch (x) {} } });
      AIM.hooks.refresh = async () => { AIM.state = await API.state(); applyTheme(); applyStyle(); refreshHeader(); };
      AIM.hooks.openConv = (cid, o) => window.open(`/?conv=${encodeURIComponent(cid)}&t=${tokenParam()}${o && o.prefill ? '&prefill=' + encodeURIComponent(o.prefill) : ''}`, 'conv_' + cid, 'popup,width=640,height=560');
    }
    const o0 = opts || { attach: qs.get('attach'), prefill: qs.get('prefill'), resend: qs.get('resend') };
    if (o0.attach) pickFiles();
    if (o0.prefill) { ta.value = o0.prefill; }
    if (o0.resend) { setTimeout(() => send({ regenerate: true }), 300); }
    ta.focus(); on(window, 'focus', () => ta.focus());
    const setEffort = (v) => { effort = v; if (id) API.saveChat(id, { effort: v }).catch(() => {}); shell && shell.effortChanged(); };
    const cycleEffort = () => { const l = efforts(); if (!l.length) return toast('This model has no reasoning levels.'); effort = l[(l.indexOf(effort) + 1) % l.length]; setEffort(effort); toast('Reasoning: ' + EFF_LABEL[effort]); };
    const ctl = { efforts, effort: () => effort, setEffort, cycleEffort, EFF_LABEL, checked: checkedFn, cmd, id: () => id, chat: () => chat, send, cmd, pickFiles, focus: () => ta.focus(), refreshHeader, applyStyle, contact: () => contact, dispose: () => offs.forEach((f) => f()) };
    return ctl;
  }

  // ====================================================================
  //          WORKSPACE: conversations column + chat, like the Claude desktop app
  // ====================================================================
  async function workspace() {
    document.title = 'AI Messenger';
    const ls = { get: (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set: (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} } };
    let ctl = null, curId = null, draftProject = '', filter = ''; const busy = new Set();
    const closedProj = new Set(ls.get('closedProj', [])); let modelsOpen = ls.get('modelsOpen', true);
    const st = () => AIM.state;
    const contactById = (i) => st().contacts.find((c) => c.id === i);
    const chatById = (i) => (st().chats || []).find((c) => c.id === i);
    const mostRecent = () => (st().chats || []).slice().sort((a, b) => b.updated - a.updated);

    function popMenu(x, y, items) {
      Menus.closeAll(); const m = el('div', { class: 'menu', style: `left:${x}px;top:${y}px` });
      for (const it of items) { if (it === '-') { m.append(el('div', { class: 'sep' })); continue; } m.append(el('div', { class: 'it', text: it[0], onclick: () => { m.remove(); it[1](); } })); }
      document.body.append(m); const r = m.getBoundingClientRect(); m.style.left = Math.max(0, Math.min(x, innerWidth - r.width - 2)) + 'px'; m.style.top = Math.max(0, Math.min(y, innerHeight - r.height - 2)) + 'px';
      const away = (e) => { if (!m.contains(e.target)) { m.remove(); document.removeEventListener('mousedown', away, true); } }; setTimeout(() => document.addEventListener('mousedown', away, true), 0);
    }

    // ---------- layout ----------
    const side = el('aside', { class: 'side' }); const host = el('div', { class: 'pane-host' });
    const strip = el('div', { class: 'pane-top' }); const pane = el('main', { class: 'pane' }, strip, host);
    const split = el('div', { class: 'split', role: 'separator', 'aria-orientation': 'vertical', tabindex: '0', title: 'Drag to resize the conversations column (double-click to reset)' });
    const wsEl = el('div', { class: 'ws' }, side, split, pane);
    const SW0 = 272, clampW = (w) => Math.max(180, Math.min(w, 640, wsEl.clientWidth - 340)); let sideW = ls.get('sideW', SW0);
    const setW = (w, save) => { sideW = clampW(w); wsEl.style.setProperty('--sw', sideW + 'px'); if (save) ls.set('sideW', sideW); };
    split.addEventListener('pointerdown', (e) => { e.preventDefault(); split.setPointerCapture(e.pointerId); wsEl.classList.add('dragging'); });
    split.addEventListener('pointermove', (e) => { if (split.hasPointerCapture(e.pointerId)) setW(e.clientX - wsEl.getBoundingClientRect().left); });
    const endDrag = (e) => { if (split.hasPointerCapture(e.pointerId)) { split.releasePointerCapture(e.pointerId); wsEl.classList.remove('dragging'); ls.set('sideW', sideW); } };
    split.addEventListener('pointerup', endDrag); split.addEventListener('pointercancel', endDrag);
    split.addEventListener('dblclick', () => setW(SW0, true));
    split.addEventListener('keydown', (e) => { if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') { e.preventDefault(); setW(sideW + (e.key === 'ArrowRight' ? 16 : -16), true); } });
    window.addEventListener('resize', () => setW(sideW));
    { const f = (Menus.raw()['109'] || []).find((x) => x[0] === 'popup' && /File/.test(x[1])); if (f && !f[2].some((x) => x[2] === 90030)) f[2].unshift(['item', '&New Conversation\tCtrl+Shift+O', 90030], ['item', 'Add a &Contact...', 40282], ['item', '&Find Models on this Computer...', 90031], ['item', 'Set Up Local &Runtime (llama.cpp)...', 90032], ['item', 'Sign &Out', 40210], ['item', '', 0]); }
    const mb = await Menus.bar('109', (cid, label) => (ctl ? ctl.cmd(cid, label) : wsCmd(cid, label)), { checked: (cid) => ctl && ctl.checked ? ctl.checked(cid) : false });
    root.replaceChildren(mb, wsEl); applyTheme();
    setW(sideW);

    // ---------- top strip over the chat ----------
    const tog = el('button', { class: 'tog', title: 'Show or hide the conversations column', text: '☰', onclick: () => { if (matchMedia('(max-width:720px)').matches) side.classList.toggle('open'); else wsEl.classList.toggle('nosidebar'); } });
    const stTitle = el('span', { class: 'st-title', title: 'Double-click to rename' }); const stPin = el('button', { class: 'st-btn', title: 'Pin or unpin', onclick: () => curId && togglePin(chatById(curId)) });
    const stMenu = el('button', { class: 'st-btn', title: 'More', text: '⋯', onclick: (e) => { const ch = curId && chatById(curId); if (ch) { const r = e.currentTarget.getBoundingClientRect(); chatMenu(r.left - 120, r.bottom, ch); } } });
    stTitle.ondblclick = () => curId && renameChat(chatById(curId));
    const effSel = el('select', { class: 'effort', title: 'Reasoning effort for this conversation (Alt+T cycles)', onchange: () => ctl && ctl.setEffort(effSel.value) });
    const effWrap = el('label', { class: 'effort-wrap' }, el('span', { text: 'Reasoning' }), effSel);
    strip.append(tog, stTitle, effWrap, stPin, stMenu);
    function updateEffort() {
      const l = ctl ? ctl.efforts() : []; effWrap.style.display = l.length ? '' : 'none'; if (!l.length) return;
      effSel.replaceChildren(...l.map((v) => el('option', { value: v, text: ctl.EFF_LABEL[v], selected: v === ctl.effort() })));
    }
    function updateStrip() {
      updateEffort();
      const ch = curId && chatById(curId); stTitle.textContent = ch ? ch.title : 'New conversation';
      const pj = ch && ch.project && (st().projects || []).find((p) => p.id === ch.project); stTitle.title = pj ? `In project: ${pj.name} (double-click to rename)` : 'Double-click to rename';
      stPin.textContent = ch && ch.pinned ? '★' : '☆'; stPin.style.visibility = stMenu.style.visibility = ch ? 'visible' : 'hidden';
    }

    // ---------- sidebar ----------
    const brand = el('div', { class: 'brand' }, el('img', { src: AIM.BUDDY, alt: '' }), el('span', { text: 'AI Messenger' }));
    const newBtn = el('button', { class: 'newchat', text: '+  New conversation', onclick: () => { draftProject = ''; newChat(); } });
    const search = el('input', { class: 'sidesearch', placeholder: 'Search conversations...', oninput: () => { filter = search.value.toLowerCase().trim(); renderSide(); }, onkeydown: (e) => { if (e.key === 'Enter' && search.value.trim()) P.searchHistory(search.value.trim()); } });
    const list = el('div', { class: 'side-list' }); const me = el('div', { class: 'side-me' });
    side.append(brand, newBtn, search, list, me);

    const head = (text, extra) => el('div', { class: 'sec' }, el('span', { class: 'sec-t', text }), ...(extra || []));
    const miniBtn = (t, title, fn) => el('button', { class: 'mini', text: t, title, onclick: (e) => { e.stopPropagation(); fn(e); } });
    const dots = (fn) => miniBtn('⋯', 'More', (e) => { const r = e.currentTarget.getBoundingClientRect(); fn(r.left, r.bottom); });

    function chatRow(ch) {
      const c = contactById(ch.participants[0]); const multi = ch.participants.length > 1;
      const row = el('div', { class: 'row chat' + (ch.id === curId ? ' sel' : ''), title: `${ch.title}\n${multi ? ch.participants.map((i) => (contactById(i) || {}).name).join(', ') : c ? c.name : ''}` });
      row.append(avatar(c ? c.name : '?', 18, null, c && c.avatar), el('span', { class: 'rt', text: ch.title }), ...(busy.has(ch.id) ? [el('span', { class: 'busy', text: '…' })] : []), dots((x, y) => chatMenu(x, y, ch)));
      row.onclick = () => openChat(ch.id); row.oncontextmenu = (e) => { e.preventDefault(); chatMenu(e.clientX, e.clientY, ch); }; return row;
    }
    function projectBlock(p, chats) {
      const mine = chats.filter((c) => c.project === p.id && !c.pinned); const open = !closedProj.has(p.id) || !!filter;
      const row = el('div', { class: 'row proj' }, el('span', { class: 'arrow', text: open ? '▾' : '▸' }), el('span', { class: 'rt', text: p.name }), el('span', { class: 'cnt', text: String(mine.length) }), dots((x, y) => projectMenu(x, y, p)));
      row.title = p.instructions ? 'Project instructions are sent with every conversation in it.' : 'Project'; row.oncontextmenu = (e) => { e.preventDefault(); projectMenu(e.clientX, e.clientY, p); };
      row.onclick = () => { closedProj.has(p.id) ? closedProj.delete(p.id) : closedProj.add(p.id); ls.set('closedProj', [...closedProj]); renderSide(); };
      return [row, ...(open ? mine.map((c) => { const r = chatRow(c); r.classList.add('nested'); return r; }) : [])];
    }
    function modelRow(c) {
      const row = el('div', { class: 'row model' + (c.blocked ? ' blocked' : ''), title: `${c.name} <${c.model}>\nClick to start a new conversation with it.` });
      row.append(el('span', { class: 'dot ' + (c.presence === 'offline' ? 'off' : 'on') }), avatar(c.name, 18, null, c.avatar), el('span', { class: 'rt', text: c.name }), el('span', { class: 'cnt', text: c.blocked ? 'blocked' : c.presence === 'offline' ? 'offline' : 'online' }));
      row.onclick = () => { if (c.blocked) return toast(`${c.name} is blocked. Unblock it in its properties.`); draftProject = ''; newChat(c.id); }; row.oncontextmenu = (e) => { e.preventDefault(); contactMenu(e.clientX, e.clientY, c); }; return row;
    }
    function renderSide() {
      const all = mostRecent().filter((c) => !filter || (c.title + ' ' + (c.preview || '')).toLowerCase().includes(filter)); const projs = st().projects || [];
      const pinnedChats = all.filter((c) => c.pinned); const pinnedProj = projs.filter((p) => p.pinned && (!filter || p.name.toLowerCase().includes(filter) || all.some((c) => c.project === p.id)));
      const keep = list.scrollTop; list.replaceChildren();
      if (pinnedChats.length || pinnedProj.length) { list.append(head('Pinned')); for (const p of pinnedProj) list.append(...projectBlock(p, all)); pinnedChats.forEach((c) => list.append(chatRow(c))); }
      const otherProj = projs.filter((p) => !p.pinned && (!filter || p.name.toLowerCase().includes(filter) || all.some((c) => c.project === p.id)));
      list.append(head('Projects', [miniBtn('+', 'New project', () => newProject())]));
      if (otherProj.length) otherProj.forEach((p) => list.append(...projectBlock(p, all))); else list.append(el('div', { class: 'hint', text: filter ? 'No matching projects.' : 'Group conversations that share instructions.' }));
      const recents = all.filter((c) => !c.pinned && !c.project);
      list.append(head('Recents')); if (recents.length) recents.forEach((c) => list.append(chatRow(c))); else list.append(el('div', { class: 'hint', text: filter ? 'No matching conversations.' : 'Your conversations will show up here.' }));
      const sec = head('Models', [miniBtn('+', 'Add a model (Hugging Face and others)', () => cmdAdd())]); sec.classList.add('click'); sec.querySelector('.mini').before(miniBtn('Find', 'Find models already on this computer', () => cmdScan())); sec.prepend(el('span', { class: 'arrow', text: modelsOpen ? '▾' : '▸' }));
      sec.onclick = () => { modelsOpen = !modelsOpen; ls.set('modelsOpen', modelsOpen); renderSide(); }; list.append(sec);
      if (modelsOpen) { const cs = st().contacts.filter((c) => !filter || (c.name + c.model).toLowerCase().includes(filter)).sort((a, b) => (a.presence === 'offline') - (b.presence === 'offline') || a.name.localeCompare(b.name)); cs.forEach((c) => list.append(modelRow(c))); if (!cs.length) list.append(el('div', { class: 'hint', text: 'Use + to add an AI model.' })); }
      list.scrollTop = keep;
    }
    const cmdAdd = async () => { await P.hfBrowser(); await reload(); };
    const cmdScan = async () => { await P.scanModels(); await reload(); };

    function renderMe() {
      const s = st(); const nm = el('div', { class: 'me-name', text: s.profile.name || 'You', title: 'Change display name' }); const ps = el('div', { class: 'me-status', text: `(${s.profile.status || 'Online'})`, title: 'Change status' });
      nm.onclick = async () => { const r = await dialog({ title: 'Change Display Name', rows: [{ key: 'name', label: 'Name:', value: st().profile.name }] }); if (r && r.name.trim()) { st().profile = await API.profile({ name: r.name.trim() }); renderMe(); } };
      ps.onclick = (e) => { const r = e.currentTarget.getBoundingClientRect(); popMenu(r.left, r.top - 200, Object.entries(STATUS).map(([k, [n]]) => [n, async () => { st().profile = await API.profile({ status: n }); renderMe(); }])); };
      const pic = el('div', { class: 'me-pic', title: 'Change display picture', onclick: () => P.displayPicture() }, avatar(s.profile.name || 'You', 34, 210, s.assets.avatar));
      me.replaceChildren(pic, el('div', { class: 'me-txt' }, nm, ps), el('div', { class: 'me-btns' }, miniBtn('Settings', 'Settings (Ctrl+,)', () => P.settings()), miniBtn('Themes', 'Themes', () => P.versionThemes()), miniBtn('Options', 'Options', () => P.options()), miniBtn('Align', 'Align layout: drag blocks into place (Ctrl+Alt+L)', () => AIM.layout.edit()), miniBtn('Update', 'Check GitHub for a newer version', () => P.updates())));
    }

    // ---------- chat / project actions ----------
    const togglePin = async (ch) => { await API.saveChat(ch.id, { pinned: !ch.pinned }); await refresh(); };
    async function renameChat(ch) { const r = await dialog({ title: 'Rename Conversation', rows: [{ key: 'title', label: 'Title:', value: ch.title }] }); if (r && r.title.trim()) { await API.saveChat(ch.id, { title: r.title.trim() }); await refresh(); } }
    async function deleteChat(ch) { if (await confirmBox('Delete conversation', `Delete "${ch.title}" and all its messages?`, 'Delete')) { await API.delChat(ch.id); if (ch.id === curId) { curId = null; await refresh(); newChat(); } else await refresh(); } }
    async function exportChat(ch) { const h = await API.history(ch.id); const nm = (m) => m.role === 'user' ? (st().profile.name || 'You') : (contactById(m.from) || contactById(ch.participants[0]) || { name: 'Assistant' }).name; AIM.download(`${ch.title.replace(/[^\w .-]/g, '_')}.txt`, h.map((m) => `[${new Date(m.t).toLocaleString()}] ${nm(m)}:\n${m.text}\n`).join('\n')); }
    function chatMenu(x, y, ch) {
      const projs = st().projects || [];
      popMenu(x, y, [['Rename...', () => renameChat(ch)], [ch.pinned ? 'Unpin' : 'Pin', () => togglePin(ch)], '-',
        ...projs.filter((p) => p.id !== ch.project).map((p) => [`Move to project: ${p.name}`, async () => { await API.saveChat(ch.id, { project: p.id }); await refresh(); }]),
        ...(ch.project ? [['Remove from project', async () => { await API.saveChat(ch.id, { project: '' }); await refresh(); }]] : []), ...(projs.length || ch.project ? ['-'] : []),
        ['View message history', () => P.history(ch.id)], ['Export transcript...', () => exportChat(ch)], '-', ['Delete', () => deleteChat(ch)]]);
    }
    async function projectDialog(p) {
      const r = await dialog({ title: p ? 'Project Settings' : 'New Project', width: 460, rows: [{ key: 'name', label: 'Name:', value: p ? p.name : '' }, { key: 'instructions', label: 'Instructions for every conversation in this project (optional):', full: true, type: 'textarea', value: p ? p.instructions : '' }], ok: p ? 'Save' : 'Create' });
      if (!r || !r.name.trim()) return null; return p ? API.saveProject(p.id, { name: r.name.trim(), instructions: r.instructions || '' }) : API.newProject({ name: r.name.trim(), instructions: r.instructions || '' });
    }
    async function newProject() { const p = await projectDialog(null); if (p) { await refresh(); toast(`Project "${p.name}" created. Use a conversation's menu to move it in.`); } }
    function projectMenu(x, y, p) {
      popMenu(x, y, [['New conversation in this project', () => { draftProject = p.id; newChat(null, { project: p.id }); }], ['Instructions and rename...', async () => { if (await projectDialog(p)) await refresh(); }], [p.pinned ? 'Unpin' : 'Pin', async () => { await API.saveProject(p.id, { pinned: !p.pinned }); await refresh(); }], '-',
        ['Delete project (keeps its conversations)', async () => { if (await confirmBox('Delete project', `Delete the project "${p.name}"? Its conversations are kept.`, 'Delete')) { await API.delProject(p.id); await refresh(); } }]]);
    }
    function contactMenu(x, y, c) {
      popMenu(x, y, [['New conversation', () => { draftProject = ''; newChat(c.id); }, 1], ['Properties...', async () => { await P.contactDialog(c); await reload(); }], [c.blocked ? 'Unblock' : 'Block', async () => { await API.saveContact({ ...c, blocked: !c.blocked, config: c.config }); await reload(); }], '-',
        ['Delete model', async () => { if (await confirmBox('Delete a Contact', `Delete "${c.name}"? Conversations that only used it are deleted too.`, 'Delete')) { await API.delContact(c.id); await reload(); if (ctl && ctl.contact() && ctl.contact().id === c.id) newChat(); } }]]);
    }

    // ---------- showing a conversation ----------
    const shell = {
      effortChanged: () => updateEffort(), cmd: (cid, label) => wsCmd(cid, label), newChat: () => { draftProject = ''; newChat(); }, refresh: () => refresh(), project: () => draftProject,
      busy: (id, b) => { b ? busy.add(id) : busy.delete(id); renderSide(); },
      created: (chat) => { curId = chat.id; if (!chatById(chat.id)) st().chats.push(chat); renderSide(); updateStrip(); },
    };
    async function show(chat, o) {
      if (ctl) { ctl.dispose(); ctl = null; }
      host.replaceChildren(); curId = chat.id; side.classList.remove('open');
      ctl = await convWindow(chat, host, shell, o || {});
      if (!ctl) { host.replaceChildren(el('div', { class: 'welcome' }, el('h2', { text: 'No models yet' }), el('p', { text: 'Add an AI model to start chatting.' }), el('button', { class: 'btn primary', text: 'Add a Contact...', onclick: cmdAdd }))); }
      renderSide(); updateStrip();
    }
    function newChat(contactId, o) {
      const ok = (i) => { const c = contactById(i); return c && !c.blocked ? i : null; };
      const cid = ok(contactId) || ok(AIM.settings().defaultContact) || ok(ls.get('lastContact', '')) || (st().contacts.find((c) => !c.blocked) || {}).id;
      return show({ id: null, participants: cid ? [cid] : [], project: (o && o.project) || draftProject }, o);
    }
    function openChat(id, o) { const ch = chatById(id); if (ch) return show(ch, o); if (contactById(id)) return newChat(id, o); return newChat(); }
    async function refresh() { try { st().chats = await API.chats(); st().projects = await API.projects(); } catch (e) {} renderSide(); updateStrip(); }
    async function reload() { st().chats = st().chats || []; AIM.state = await API.state(); renderSide(); renderMe(); applyTheme(); if (ctl) { ctl.applyStyle(); ctl.refreshHeader(); } updateStrip(); }
    AIM.hooks.refresh = reload; AIM.hooks.openConv = openChat;

    async function wsCmd(id, label) {
      if (commonCmd(id, label)) return;
      const cc = ctl && ctl.contact(); const needC = () => { if (!cc) toast('Open a conversation first.'); return cc; };
      const set = async (patch) => { await API.settings(patch); AIM.state.settings = Object.assign(AIM.state.settings, patch); renderSide(); };
      switch (id) {
        case 90030: draftProject = ''; return newChat();
        case 90031: return cmdScan();
        case 90032: return P.runtimeSetup();
        case 90006: return P.space();
        case 40282: return cmdAdd();
        case 40289: { const c = needC(); if (c && await confirmBox('Delete a Contact', `Delete "${c.name}"? Conversations that only used it are deleted too.`, 'Delete')) { await API.delContact(c.id); await reload(); newChat(); } return; }
        case 40283: { const c = needC(); if (c) { await P.contactDialog(c); await reload(); } return; }
        case 40292: return P.history(curId || undefined);
        case 40004: case 40205: return newChat(cc && cc.id);
        case 40225: case 40275: return ctl && ctl.pickFiles();
        case 40328: return P.winks((k) => ctl && ctl.send({ text: `*sends a wink: ${k.name}*`, sticker: k.id }));
        case 40273: return P.avSetup('audio'); case 40279: case 40049: return P.avSetup('webcam');
        case 40210: await API.signOut(); bc.postMessage({ signout: true }); location.reload(); return;
        case 40003: window.close(); return;
        case 40074: case 40075: case 40076: case 40285: case 40286: case 40307: case 40308: return set({ 40074: { pictures: 'large' }, 40075: { pictures: 'small' }, 40076: { pictures: 'none' }, 40285: { sortBy: 'groups' }, 40286: { sortBy: 'status' }, 40307: { labelBy: 'name' }, 40308: { labelBy: 'model' } }[id]);
        case 40271: await P.groupOp('create'); return reload(); case 40272: await P.groupOp('delete'); return reload(); case 40295: await P.groupOp('rename'); return reload();
        case 40287: return P.exportContacts(); case 40288: await P.importContacts(); return reload();
        case 40306: case 40291: return toast('Models appear in the Models list: online ones need the internet, offline ones run on this computer.');
        default: if (STATUS[id]) { st().profile = await API.profile({ status: STATUS[id][0] }); renderMe(); return; } return notApplicable(label);
      }
    }
    bc.addEventListener('message', (e) => { if (e.data && e.data.signout) location.reload(); else if (e.data === 'reload') refresh(); else if (e.data && e.data.busy !== undefined) { e.data.busy ? busy.add(e.data.id) : busy.delete(e.data.id); renderSide(); } });
    const KB = AIM.keybinds; // configurable shortcuts (Settings > Keyboard shortcuts)
    document.addEventListener('keydown', (e) => {
      if (document.querySelector('.dlg-shade') && !/Escape/.test(e.key)) { const a0 = KB.match(e); if (a0 !== 'settings') return; }
      const act = KB.match(e); if (!act) return; e.preventDefault();
      switch (act) {
        case 'newChat': draftProject = ''; return newChat();
        case 'cycleEffort': return ctl && ctl.cycleEffort();
        case 'regenerate': return ctl && ctl.send({ regenerate: true });
        case 'toggleSidebar': return tog.click();
        case 'focusSearch': if (!wsEl.classList.contains('nosidebar') || matchMedia('(max-width:720px)').matches) { side.classList.add('open'); } wsEl.classList.remove('nosidebar'); return search.focus();
        case 'settings': return P.settings();
      }
    });
    window.addEventListener('focus', refresh);
    renderMe(); renderSide(); API.alerts().catch(() => {});
    setTimeout(() => sound('online'), 300);
    await newChat(); // like the Claude app: start on a fresh, empty conversation
  }

  // ====================================================================
  //                               BOOT
  // ====================================================================
  let session = await API.session();
  if (!session.signedIn && session.auto) { const p = session.profiles.find((x) => x.id === session.auto); if (p && !p.locked && !qs.get('nologon')) { try { await API.signIn({ id: p.id }); session = await API.session(); } catch (e) {} } }
  if (!session.signedIn) { if (!session.profiles.length) { await API.createProfile({ name: 'Default' }); session = await API.session(); } return showLogon(session); }
  AIM.state = await API.state(); applyTheme();
  if (CONV) { const ch = (AIM.state.chats || []).find((c) => c.id === CONV); await convWindow(ch || { id: null, participants: [CONV] }, root, null, null); }
  else if (qs.get('classic')) await mainWindow();
  else await workspace();
})().catch((e) => { document.body.textContent = 'Startup error: ' + e.message; console.error(e); });
