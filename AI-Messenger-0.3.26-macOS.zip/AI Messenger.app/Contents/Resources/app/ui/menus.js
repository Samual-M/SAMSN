/* Renders the ORIGINAL menu definitions (assets/menus.json, extracted from msgslang.dll) as a classic menu bar. */
(function (g) {
  let defs = null;
  const strip = (s) => s.replace(/&(.)/, '<u>$1</u>');
  const HIDE_LABEL = /^.$/; // single-letter placeholders are filled in at runtime by the original app

  async function load() { if (!defs) defs = await (await fetch('assets/menus.json')).json(); return defs; }

  function closeAll() { document.querySelectorAll('.menu').forEach((m) => m.remove()); document.querySelectorAll('#menubar .mi.open').forEach((m) => m.classList.remove('open')); }

  function popup(items, x, y, onCmd, state) {
    const m = document.createElement('div'); m.className = 'menu';
    let prevSep = true;
    for (const [kind, label, val] of items) {
      if (kind === 'item' && label === '' && val === 0) { if (!prevSep) { const s = document.createElement('div'); s.className = 'sep'; m.append(s); prevSep = true; } continue; }
      if (kind === 'item' && HIDE_LABEL.test(label.replace(/&/g, ''))) continue;
      prevSep = false;
      const it = document.createElement('div'); it.className = 'it';
      const [text, acc] = label.split('\t');
      const l = document.createElement('span'); l.innerHTML = strip(text.replace(/</g, '&lt;'));
      it.append(l);
      if (acc) { const a = document.createElement('span'); a.className = 'acc'; a.textContent = acc; it.append(a); }
      if (kind === 'popup') {
        it.classList.add('sub'); let sub;
        it.addEventListener('mouseenter', () => { closeSubs(m); const r = it.getBoundingClientRect(); sub = popup(val, r.right - 2, r.top - 3, onCmd, state); sub.dataset.parent = '1'; });
      } else {
        const chk = state && state.checked && state.checked(val);
        if (chk) { it.style.fontWeight = 'bold'; it.insertAdjacentHTML('afterbegin', '<span style="position:absolute;left:7px">•</span>'); }
        if (state && state.disabled && state.disabled(val)) it.classList.add('off');
        it.addEventListener('mouseenter', () => closeSubs(m));
        it.addEventListener('click', (e) => { e.stopPropagation(); closeAll(); onCmd(val, label); });
      }
      m.append(it);
    }
    while (m.lastChild && m.lastChild.className === 'sep') m.lastChild.remove();
    document.body.append(m);
    const r = m.getBoundingClientRect();
    m.style.left = Math.max(0, Math.min(x, innerWidth - r.width - 2)) + 'px';
    m.style.top = Math.max(0, Math.min(y, innerHeight - r.height - 2)) + 'px';
    return m;
  }
  function closeSubs(m) { document.querySelectorAll('.menu[data-parent]').forEach((s) => { if (s !== m) s.remove(); }); }

  async function bar(menuId, onCmd, state) {
    await load();
    const bar = document.createElement('div'); bar.id = 'menubar'; bar.className = 'u';
    const top = defs[menuId] || [];
    let openIdx = -1;
    top.forEach(([kind, label, sub], i) => {
      if (kind !== 'popup') return;
      const mi = document.createElement('div'); mi.className = 'mi'; mi.innerHTML = strip(label);
      const show = () => { closeAll(); const r = mi.getBoundingClientRect(); popup(sub, r.left, r.bottom - 1, onCmd, state); mi.classList.add('open'); openIdx = i; };
      mi.addEventListener('mousedown', (e) => { e.stopPropagation(); if (mi.classList.contains('open')) { closeAll(); openIdx = -1; } else show(); });
      mi.addEventListener('mouseenter', () => { if (openIdx >= 0 && document.querySelector('.menu')) show(); });
      bar.append(mi);
    });
    document.addEventListener('mousedown', (e) => { if (!e.target.closest('.menu') && !e.target.closest('#menubar')) { closeAll(); openIdx = -1; } });
    return bar;
  }
  async function context(menuId, x, y, onCmd, state) { await load(); closeAll(); const t = defs[menuId] || []; const items = t.length === 1 && t[0][0] === 'popup' ? t[0][2] : t; return popup(items, x, y, onCmd, state); }
  g.Menus = { bar, context, closeAll, load, raw: () => defs };
})(window);
