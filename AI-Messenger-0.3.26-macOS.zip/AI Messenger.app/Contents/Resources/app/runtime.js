'use strict';
/*
 * One-click install of llama.cpp's "llama-server" (the free, offline program that runs local .gguf models).
 * Nothing here runs until the user has pressed Install in the app and approved the connection. The only hosts are
 * api.github.com (to find the newest build) and github.com / its release-file network (to download it).
 * Sent: a normal web request (your IP address). Never sent: chats, profile, contacts, model names or files.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');

const exe = process.platform === 'win32' ? 'llama-server.exe' : 'llama-server';

function assetName(tag) { // ready-made CPU build for this computer
  const arch = process.arch === 'arm64' ? 'arm64' : process.arch === 'x64' ? 'x64' : null; if (!arch) return null;
  if (process.platform === 'linux') return `llama-${tag}-bin-ubuntu-${arch}.tar.gz`;
  if (process.platform === 'darwin') return `llama-${tag}-bin-macos-${arch}.tar.gz`;
  if (process.platform === 'win32') return `llama-${tag}-bin-win-cpu-${arch}.zip`;
  return null;
}
const BASE = () => (process.env.AIM_RUNTIME_BASE || 'https://github.com/ggml-org/llama.cpp').replace(/\/$/, '');
const HDR = { 'User-Agent': 'ai-messenger' };
async function recentTags(signal) { // newest build tags (b1234...) from the public releases feed, then the releases page
  const tags = [];
  for (const path of ['/releases.atom', '/releases']) {
    try {
      const r = await fetch(BASE() + path, { headers: HDR, signal }); if (!r.ok) continue;
      for (const m of (await r.text()).matchAll(/\/releases\/tag\/(b\d+)/g)) if (!tags.includes(m[1])) tags.push(m[1]);
      if (tags.length) break;
    } catch (e) { if (signal && signal.aborted) throw e; }
  }
  if (!tags.length) tags.push('b12017'); // last resort: a build known to exist, so a working runtime is still installed
  return tags;
}
function findExe(dir, depth = 0) { // llama-server inside an unpacked build
  let ents; try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return null; }
  for (const e of ents) if (e.isFile() && e.name === exe) return path.join(dir, e.name);
  if (depth < 2) for (const e of ents) if (e.isDirectory()) { const r = findExe(path.join(dir, e.name), depth + 1); if (r) return r; }
  return null;
}
const run = (cmd, args) => new Promise((ok, bad) => { const p = spawn(cmd, args, { stdio: ['ignore', 'ignore', 'pipe'] }); let err = ''; p.stderr.on('data', (d) => { err += d; }); p.on('error', bad); p.on('exit', (c) => (c === 0 ? ok() : bad(new Error(`${cmd} failed: ${err.slice(0, 200)}`)))); });

module.exports = function runtimeRoutes({ json, body, dataDir, localServer }) {
  const binDir = () => path.join(dataDir, 'bin');
  let busy = false;
  return async function handle(parts, m, req, res) {
    const sub = parts[1];
    if (sub === 'status' && m === 'GET') return json(res, 200, { found: localServer(), supported: !!assetName('b1'), platform: process.platform + '/' + process.arch, dir: binDir() });
    if (sub === 'install' && m === 'POST') {
      if (!assetName('b1')) return json(res, 400, { error: `There is no ready-made llama.cpp build for ${process.platform}/${process.arch}. Install llama.cpp yourself and put llama-server on your PATH.` });
      if (busy) return json(res, 409, { error: 'An install is already running.' });
      busy = true; res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
      const send = (o) => res.write('data: ' + JSON.stringify(o) + '\n\n'); const ac = new AbortController(); res.on('close', () => ac.abort());
      let part = null, work = null;
      try {
        send({ step: 'Finding the newest build...' });
        const tags = await recentTags(ac.signal); if (!tags.length) throw new Error('No builds were listed on the llama.cpp releases page.');
        let tag = '', name = '', url = '', size = 0;
        for (const t of tags.slice(0, 12)) { // the newest build can still be uploading: take the first that has our file
          const n = assetName(t), u = `${BASE()}/releases/download/${t}/${n}`;
          try { const h = await fetch(u, { method: 'HEAD', headers: HDR, signal: ac.signal }); if (h.ok) { tag = t; name = n; url = u; size = Number(h.headers.get('content-length')) || 0; break; } } catch (e) { if (ac.signal.aborted) throw e; }
        }
        if (!url) throw new Error(`None of the latest ${Math.min(12, tags.length)} llama.cpp releases had a build for ${process.platform}/${process.arch}.`);
        let digest = ''; if (!process.env.AIM_RUNTIME_BASE) { try { const a2 = await fetch(`https://api.github.com/repos/ggml-org/llama.cpp/releases/tags/${tag}`, { headers: HDR, signal: AbortSignal.timeout(6000) }); if (a2.ok) digest = ((await a2.json()).assets || []).find((x) => x.name === name)?.digest || ''; } catch {} } // optional checksum
        const asset = { name, size, digest };
        fs.mkdirSync(binDir(), { recursive: true, mode: 0o700 }); part = path.join(binDir(), `.${asset.name}.part`);
        send({ step: `Downloading llama.cpp ${tag} (${(asset.size / 1048576).toFixed(0)} MB)...` });
        const d = await fetch(url, { headers: { 'User-Agent': 'ai-messenger' }, signal: ac.signal }); if (!d.ok) throw new Error('Download failed: ' + d.status);
        const total = Number(d.headers.get('content-length')) || asset.size || 0; const out = fs.createWriteStream(part); const h = crypto.createHash('sha256'); let got = 0, last = 0;
        for await (const chunk of d.body) { h.update(chunk); if (!out.write(chunk)) await new Promise((ok) => out.once('drain', ok)); got += chunk.length; if (Date.now() - last > 250) { last = Date.now(); send({ got, total }); } }
        await new Promise((ok, bad) => { out.end(ok); out.on('error', bad); });
        if (total && got !== total) throw new Error('The download was cut short; please try again.');
        const want = /^sha256:([0-9a-f]{64})$/i.exec(asset.digest || ''); if (want && want[1].toLowerCase() !== h.digest('hex')) throw new Error('The downloaded file did not match its checksum, so it was discarded.');
        send({ step: 'Unpacking...' });
        work = path.join(binDir(), `llama-${tag}`); fs.rmSync(work, { recursive: true, force: true }); fs.mkdirSync(work, { recursive: true, mode: 0o755 });
        await run('tar', ['-xf', part, '-C', work]); // tar reads .tar.gz everywhere and .zip on Windows 10+
        const found = findExe(work); if (!found) throw new Error('llama-server was not in the download.');
        if (process.platform !== 'win32') fs.chmodSync(found, 0o755);
        for (const n of fs.readdirSync(binDir())) if (/^llama-b\d+$/.test(n) && n !== `llama-${tag}`) fs.rmSync(path.join(binDir(), n), { recursive: true, force: true }); // drop older builds
        try { fs.unlinkSync(part); } catch {}
        send({ done: true, path: found, tag });
      } catch (e) { try { part && fs.unlinkSync(part); } catch {} if (!ac.signal.aborted) send({ error: e.message || String(e) }); }
      busy = false; return res.end();
    }
    return json(res, 404, { error: 'unknown runtime route' });
  };
};
module.exports.findExe = findExe;
