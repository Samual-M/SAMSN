# SAMSN

**SAMSN is a private AI chat app that looks and feels like MSN Messenger.** Your AI models are your "contacts": double-click one,
type, and the reply streams in, just like a chat with a friend in 2005. It runs entirely on your own computer.

## What you can do
* Chat with **Ollama**, **LM Studio**, **llama.cpp**, **OpenAI-compatible** servers, **Anthropic**, **Hugging Face**, or the built-in offline demo.
* Keep many conversations in a sidebar, with projects, pinned chats, search, and full message history.
* A **Details** column (the ⓘ button) for each chat: instructions for that chat, creativity, longest reply, a list of code you can copy, and Export.
* Attach images and text files, regenerate a reply, set the reasoning effort, and choose your own keyboard shortcuts.
* Browse and download models from Hugging Face, or set up a local model runtime (asks first, nothing is automatic).
* Two themes: **MSN Messenger 7.5** and **MSN Modern** (upscaled sprites, rounded modern layout).
* **Paint is built in**: click any picture in a chat, draw on it, close Paint, and it is back in your message ready to send.
* **Plug-ins** (Tools > Plug-ins): slash commands, prompt packs, looks such as Dark mode, and new AI providers.
* A simple **Update** button that checks this GitHub repository for a newer version.

## Install
* **Linux (.deb):** `sudo apt install ./samsn_*_amd64.deb`, then open *SAMSN* from the app menu (or run `samsn`).
* **macOS:** unzip the macOS download, open the app (it asks before downloading Node.js if you do not have it).
* **Anywhere with Node.js 18+:** run `node server.js` in this folder and open the address it prints.

## Updating
Download the newest `SAMSNV*.deb` from github.com/Samual-M/SAMSN and install it with `sudo apt install ./SAMSNV<version>.deb`.
Opening the new version closes any older copy that is still running.

## Privacy
No telemetry, analytics, ads or accounts. Nothing is sent anywhere except the AI service you choose for a model, and the optional model and plug-in searches
after you allow them. The server listens on 127.0.0.1 only, uses a random per-launch token, and rejects foreign Host headers.
Data lives in `~/.config/ai-messenger` (Linux), `~/Library/Application Support/AI Messenger` (macOS) or `%APPDATA%\AI Messenger` (Windows).
API keys are stored in `config.json` (mode 0600) and are never sent back to the interface.

## Plug-ins
Use **Tools > Plug-ins** to add the included ones with one click, or a file of your own. A plug-in is one file in `<data folder>/plugins/`:

* `.json` prompt pack: `{"name":"My prompts","prompts":[{"command":"poem","name":"Write a poem","text":"Write a short poem about "}]}`
* `.css` look: starts with `/* name: My look */`
* `.js` program: slash commands, instructions for every model, and/or a whole AI provider:

```js
module.exports = {
  name: 'Hello', description: 'Says hi',
  commands: [{ name: 'hello', description: 'Say hi', run: (args, ctx) => 'Hi ' + args }], // reply text, or { insert } / { send }
  instructions: 'Always be friendly.',                                                      // added to every system prompt
};
```

An AI provider plug-in:

```js
module.exports = {
  id: 'mybackend', name: 'My backend',
  fields: [{ key: 'apiKey', label: 'API key', type: 'password', secret: true }],
  models: ['model-1'],
  async listModels(cfg) { return ['model-1']; },          // optional
  async *chat({ messages, model, system, config, signal }) { // messages: [{role:'user'|'assistant', text, attachments}]
    yield 'streamed ';  yield 'text';
  },
};
```
Built-in providers live in `providers/` (OpenAI-compatible, Anthropic, offline demo).

## About the interface assets
`ui/assets` contains resources extracted from Microsoft's MSN Messenger 7.5 installer (layouts `.uif`, images, menus, strings).
They remain Microsoft's property: use them for personal/educational purposes and do not redistribute this package publicly
without replacing them. `ui/uif.js` is a new, independent engine that renders those layout files.

## 0.2.1 - Hugging Face model browser

"Add a Contact" now opens a Hugging Face model browser. Nothing connects until you press **Allow connection**
(the window states the server, operator, what is sent and what happens if you decline). Only huggingface.co
is contacted; your chats, contacts and profile are never sent.

* Filter: models that run on this computer (GGUF, checked against your RAM), online models, or all.
* Pick a file (size and fit are shown), press Download; when it finishes the model is added as a contact.
* Local models appear under **Offline**; online (Hugging Face-hosted) models under **Online**.
* Local models run through llama.cpp's `llama-server` (free, offline). Install it so `llama-server` is on your PATH,
  or put it in `<data folder>/bin/`, or set `AI_MESSENGER_LLAMA_SERVER=/path/to/llama-server`.
* Online models need a Hugging Face access token (stored only in your profile on this computer) and send your
  messages to router.huggingface.co.
* "Add manually (any provider)..." in that window keeps the old dialog (OpenAI-compatible, Anthropic, ...).

Also fixed: long lines/URLs in the chat window, the cut-off message toolbar in narrow windows, and misaligned
toolbar labels.

## 0.2.2

* Model browser filters: purpose (coding, reasoning & math, chat, writing & roleplay, multilingual), size
  (tiny to very large), and "Best my computer can run" sorting, on top of the fits-this-computer checkbox.
* The original MSN display pictures (flower, football, chess, ...) and the classic buddy figure are now the
  default pictures and appear in the Display Picture and contact Picture galleries.
* The original sounds are wired to more events and can be previewed under Options > Sounds.
* Chat window: duplicate title strip removed, MSN logo and window buttons at the right edge.

## 0.3.0

* **Tools > Themes...** switches between MSN Messenger 7.5, 7.0, 6.2, 6.0, 5.1, 5.0 and a new **MSN 8.0 (AI edition)**.
  Each version theme uses that version's art (icons, buttons) where it matches the 7.5 layout, its original sounds,
  and a matching colour treatment. An optional, experimental "original conversation window layout" checkbox loads
  the real 6.0/6.2/7.0 layout files. Only 6.0, 6.2 and 7.0 contained layout files; 5.x was drawn by Windows, so
  5.x themes are art, sound and colour only.
* **MSN 8.0**: the 7.5 layout with a brighter look, speech-bubble messages, **Copy** buttons on messages and code
  blocks, the MSN emoticon set (typed shortcuts like `:)` and `(H)` render as the original emoticons and the
  smiley button opens the full set; not applied inside code), wider history and the 7.0 sounds.
* **Claude**: Add a Contact > Add manually > **Claude preset** fills in the Anthropic provider. It needs an
  Anthropic API key from console.anthropic.com (pay-per-use). A claude.ai subscription cannot be imported:
  its sign-in is not available to third-party apps. Desktop-app-only features (Projects, artifacts, etc.) are not
  part of the API.
* All extracted assets from the five installers are in `assets/sets/<version>/` (Microsoft's, personal use).

## 0.3.1

* **One window like the Claude desktop app.** The contact list and the chat window are combined: a conversations
  column on the left, the conversation on the right (the original MSN conversation window, menus and themes).
  The app opens on a new, empty conversation.
* Sidebar: **+ New conversation**, search, **Pinned**, **Projects**, **Recents** and **Models** (your AI contacts, with
  online/offline status; click one to start a conversation with it). Right-click or use the ... button on any row
  to rename, pin, move to a project, export or delete.
* Conversations are now separate threads (several with the same model), saved per profile. Existing histories are
  converted automatically, one conversation per old contact history.
* **Projects** group conversations and can carry instructions that are sent with every message in them.
* Pick (or change) the model for a conversation in the "To:" drop-down above the messages.
* The old contact-list window is still available at `/?classic=1`.

## 0.3.2

* **Find models on this PC**: scans the usual folders (Hugging Face cache, LM Studio, Ollama, GPT4All, Jan, Downloads,
  Documents, your models folders, plus any folder you type) for `.gguf` files you already have and adds the ones you
  tick as offline contacts. Reachable from the Models list in the sidebar ("Find"), from File > Find Models on this
  Computer, and from the Add a Contact window. It only reads file names locally; nothing is sent anywhere and it works
  without allowing the Hugging Face connection.
* **Resizable sidebar**: drag the line between the conversations column and the chat (or focus it and use the
  Left/Right arrow keys); double-click it to reset. The width is remembered.

## 0.3.3

* **Set up local runtime**: local (offline) models need llama.cpp's `llama-server`. Choose **File > Set Up Local
  Runtime (llama.cpp)...** (or click the "Set up local runtime..." button under the error, or the runtime line in the
  Add a Contact window) to download the CPU build for your system. The app asks first and says who the server is
  (GitHub), what is sent and why; it verifies the checksum when GitHub provides one and unpacks it into
  `<data folder>/bin/`. It is found automatically; nothing else is needed. Declining changes nothing.
* The "needs llama-server" message now points to this.

## 0.3.4

* **Ollama support.** New "Ollama (local, offline)" provider that talks to the Ollama app already on your computer
  (default `http://127.0.0.1:11434`, or `OLLAMA_HOST`). **Find models on this PC** now lists the models Ollama has
  and adds the ones you tick, so they work without llama.cpp. If Ollama is not running, the message says how to start
  it (or that you can use File > Set Up Local Runtime instead; Ollama is optional).
* Ollama's internal model files are no longer offered as raw files; use the Ollama entries instead.
* Clearer errors when an OpenAI-compatible server (for example one pointed at Ollama) can't be reached.

## 0.3.5

* Fixed "No matching build was found on the llama.cpp releases page" in Set Up Local Runtime. The installer now reads
  the public releases feed, takes the newest build that has a file for your system (skipping ones still being
  uploaded), and falls back to a known-good build. The checksum check is optional.

## 0.3.6

* **Reasoning effort in the chat** (like opencode's variants): a **Reasoning** box above every conversation
  (Default / Off / Low / Medium / High / Max), remembered per conversation; **Alt+T** cycles it. It maps to each
  provider's own control: Claude extended-thinking budget (2k / 8k / 16k / 32k tokens), OpenAI-style
  `reasoning_effort` (Max = the highest the model accepts), Ollama `think`. Providers or models without it
  (the demo bot, local .gguf) hide the box. The model's streamed thinking is shown in a collapsible "Thought process".
* **Settings window** (Tools > Settings, Ctrl+, or the Settings link in the sidebar): default model, default
  reasoning effort, thinking display, **custom instructions** for every conversation, **context window** (send only the
  last N messages), **keyboard shortcuts** you can rebind, and appearance.

## 0.3.7
- Conversation window now matches the original MSN 7.5 layout: Send/Search buttons stacked with their original artwork, tidy display-picture frames on the right, msn logo top-right, no stray frame lines or roster label, taller input area.

## 0.3.8
- Toolbar right-hand band (tab curve and msn logo) lowered to line up with the toolbar on the left.

## 0.3.9
- Removed the stray dark line along the top of the conversation toolbar.

## 0.3.10
- Model browser: checkbox row tidied; new filters (minimum size, last updated, minimum downloads, open licences only, hide approval-required); new sorts (recently updated, smallest); list shows likes, updated date and licence; detail panel shows author, parameters, memory needed, licence, strengths, languages, base model, popularity and access.

## 0.3.11
- Model browser: Hugging Face style filters (task, library, app, language, licence, inference provider, trending sort) in a collapsible "More filters" area. Chat window: Send and Search buttons visible again.

## 0.3.12
- Conversation toolbar: removed the earlier 16px offset so the tab band lines up with the toolbar like MSN 7.5.

## 0.3.13
- Conversation window rebuilt to match MSN 7.5 more closely: icon toolbar with drop-down carets, Voice Clip, taller input box with Send and Search, status/ink strip, picture frames with drop-down arrow and side tab.

## 0.3.14
- Toolbar: the tab curve now stretches to the full height of the toolbar panel so the panel flows into it like MSN 7.5 (no hard cut under "Games").

## 0.3.15
- Toolbar: msn strip and tab row edges moved down 7px.

## 0.3.16
- Toolbar tab row: top edge raised to meet the msn strip; right end extended down and out.

## 0.3.17
- New "Align layout" tool (Tools menu, the Align link in the sidebar, or Ctrl+Alt+L): click any block of the window and drag it, nudge it with the arrow keys (Shift = 10px), resize with Alt+arrows or type exact X/Y/W/H values, then Save. Stored only in your profile on this computer.

## 0.3.18
- Align layout: movable/foldable panel; list of every block under the pointer (click a name to select a hidden one); click again or Alt+click to cycle to the block underneath; Layer controls (forward, back, to front, to back).

## 0.3.19
- Align layout: Photoshop-style Layers list. Select a block and every block inside it is listed; click one to select it (then move, resize, re-layer it), use the eye to hide or show it, the arrow to open its contents, and "up one level" to go back. Hidden blocks are saved with the layout. Blocks that share a name are now told apart individually.

## 0.3.20
- Align layout: every artwork piece (the small picture tiles that were not selectable, such as the end cap of the tab row) now has its own name like taskbar.art2, so it can be selected, moved, resized, re-layered and hidden independently.

## 0.3.21
- Align layout: per-block colour controls (opacity, brightness, contrast, saturation, hue shift), saved with the layout, so colour mismatches between toolbar pieces can be matched by eye.

## 0.3.22
- Toolbar: the msn logo now sits at the left end of the strip beside the toolbar panel. Older saved offsets for it are cleared once so they do not stack.

## 0.3.23
- Align layout: "Lock size" and "Lock + scale" for any block. A locked block keeps the exact layout it had when locked, so the pieces inside cannot drift apart when the window is resized or maximised; with "Lock + scale" the whole block scales in proportion with the window. The tool panel can no longer be dragged off screen.

## 0.3.24
- Typing box: the missing toolbar background strip (top border and gradient) is now drawn, the frame sides run continuously down the box, and the stray orange highlight on the pen tab is gone.

## 0.3.25
- Typing box ink tabs: the pen and "A" tab icons no longer sit clipped against the top edge of the bottom strip.

## 0.3.26
- Bottom status bar added to the conversation window (as in the original).
- Update button (sidebar, and Help > Check for Updates): checks your own GitHub repository for a newer release. Asks before connecting, shows exactly what is sent, and verifies the download size and GitHub checksum before installing.

## 0.3.27
- The Update button now defaults to the SAMSN GitHub repository and finds the newest installer, either in a GitHub release or as a file in the repository itself. Downloads are checked against GitHub's checksum.

## 0.3.28
- New theme "MSN 8.1 (single picture)": the conversation window is laid out once at a fixed size and scaled as one picture, so nothing tears when you resize or maximise.
- Top toolbar icons keep their own size (Send Files and Activities were stretched); the two round buttons are slightly larger.

## 0.3.29
- New "MSN 8.1 (single picture)" theme: the whole window scales as one picture; drag the bottom-left corner to resize.
- Details column on the right (instructions, creativity, longest reply, code, export); it replaces the display pictures while open.
- Both side columns can be resized or hidden by dragging their divider.
- Download Ollama models from the model finder.
- Menus tidied, "Contacts" are now "Models", the app is called SAMSN.

## 0.3.30
- The package is now called samsn (samsn_0.3.30_all.deb) and replaces the old ai-messenger package.

## 0.3.31
- If a local model reports that the conversation does not fit its context window, SAMSN now leaves out pictures and older messages and retries once, instead of failing.

## 0.3.32
- **Themes:** the MSN 8.0 look is now the only classic theme and is called **MSN Messenger 7.5**; the other version themes and their files were removed. New **MSN Modern** theme: upscaled (sharp) toolbar icons, display pictures and emoticons, rounded bubbles, and a clean, roomy layout with the MSN butterfly colours.
- **Paint built in:** click any picture in a chat (or one waiting to be sent) and it pops up in Paint. Draw on it and close Paint: it saves and the edited picture is put in your message, ready to send back. Right-click a picture to view or save it. A simple mark-up tool is used if Paint can't open.
- **Add a Model** rebuilt: Easy start, Ollama (a built-in list checked against your memory, plus live search of ollama.com), Online services (Claude, OpenAI, Gemini, OpenRouter, Groq, Mistral, DeepSeek, xAI, Together, Fireworks, Cerebras, Perplexity, Hugging Face), the OpenRouter catalogue (300+ models, free ones marked), and local apps (LM Studio, llama.cpp, Jan, GPT4All, KoboldCpp, vLLM, LocalAI, text-generation-webui).
- **Plug-ins:** Tools > Plug-ins with Installed / Included / Online / Add your own. Included: Calculator, Today's date, Handy tools, Short answers, Everyday prompts, Coding prompts, Dark mode, Easy reading.
- **Slash commands** with suggestions as you type: /new /clear /retry /edit /model /memory /export /prompts /plugins /settings /nudge /help, plus plug-in commands and prompt packs.
- **Messages:** proper formatting (headings, lists, tables, quotes, links, code with Copy), Retry, Edit and resend, Read aloud, and reply speed shown under each answer.
- **Settings:** Memory (things every model should know about you), saved Prompts, Replies (creativity, longest reply, how many messages to send), Privacy (switch each internet connection on or off), Updates, Advanced (expert tools hidden for beginners).
- **Simpler updates:** one button: "You are up to date" or "Version X is ready: Update now", then "Restart SAMSN". Optional weekly check.
- **Menus cleaned up**: only items that work, in plain words. Fixed: menus closing when you move from one to the next, unreadable headings in some windows, attachment chips hidden behind the typing box, the toolbar tab edge, the cut-off model box, a missing icon request, local models shown as "offline".
- Getting Started window on first run (Help > Getting Started).

## 0.3.33
- Fixed "image input is not supported ... mmproj" errors. When a model can't see pictures (for example a llama.cpp model without its mmproj file), SAMSN now leaves the pictures out, says so once, and answers normally. It remembers this for that model, so later messages go straight through. Saving the model's properties lets it try pictures again.
- Local .gguf models: if a vision "mmproj" file sits in the same folder as the model, SAMSN loads it automatically so the model can see pictures.

## 0.3.34
- Clicking **any** picture in a conversation now pops it up in Paint, ready to mark up: your attachments, pictures in replies, winks and plug-in pictures (small emoticons inside text are left alone). Close Paint and the edited picture is back in your message.
- If Paint can't open a window, the built-in mark-up tool opens instead of nothing happening.

## 0.3.35
- **Locked layout** for the MSN Messenger 7.5 theme: the conversation window is laid out once at a fixed size with every block locked together, and the toolbar band is painted as one picture. Resizing or maximising now just scales the whole window like an image, so nothing drifts, stretches or tears. The space around it is filled with MSN blue.
- Settings > Appearance lets you switch back to the old stretching behaviour if you prefer more room for the chat.

## 0.3.36
- Installer fix: the package is back to the same simple form as 0.3.31 (Architecture "all", only Node.js required), so software centres such as Discover install it again. The built-in Paint needs libx11 and libcairo, which every Linux desktop already has; if Paint can't start, the built-in mark-up tool is used.
- The installer file is now named SAMSNV0.3.36.deb.

## 0.3.37
- **Tools > Theme** now lists **MSN Messenger 7.5** and **MSN Modern** directly (one click to switch).
- **Tools > Paint** opens Paint with a blank page; **Tools > Open a Picture in Paint** opens any picture from your computer. When you close Paint the picture goes into your message. There is also a **Paint** link at the bottom of the sidebar.
- The version number is shown next to the SAMSN name in the sidebar and in the window title, so you can see which version is running.

## 0.3.38
- Your tuned toolbar layout is now the **built-in default** for the MSN Messenger 7.5 theme (also used on fresh installs). The "Games" label is no longer cut off.
- It works together with the locked layout: the tuned window is shown 1:1 at a normal window size and scaled as one picture when you resize or maximise.
- Fixed Align layout size changes being measured at the on-screen (scaled) size, which made blocks grow when the window was maximised.
- Settings > Advanced: **Export my layout...** (one click, no keys or chats included) and **Reset layout to default**.

## 0.3.39
- **Clean original MSN 7.5 layout, locked and scaled as one piece.** The conversation window uses the original 7.5 block positions again (big toolbar buttons, the swoosh, Block and background buttons in the lower tab, msn logo top right), with the toolbar band drawn as a single picture. The whole window is locked together and scales evenly, like one image, at any window size.
- Older Align layout nudges and per-block locks are cleared once on upgrade, because they no longer line up with the clean layout. (Align layout still works if you want to adjust anything again.)

## 0.3.40
- The **SA** in SAMSN is now MSN orange.
- **Fine-tune models** in the Details column (the ⓘ button): Precise / Balanced / Creative / Reset style buttons, plus "More tuning": Top P, Top K, Min P, repeat penalty, presence and frequency penalty, memory size (context tokens, for Ollama and .gguf models), seed and stop words. Each one is optional and saved per conversation; models ignore the ones they don't support.
- "<name> is typing a message..." now appears just above the typing box, with animated dots.
- Sleeker typing area: no dead ink tabs, roomier text, a soft focus outline, cleaner bottom corner.
- Compact bottom-left area: your picture and name on one line, all buttons on one row below (no wasted space).
- The locked window now fills the full height: extra height goes to the message area instead of empty bands, and the width still scales as one picture.

## 0.3.41
- **Updates always show up now.** Opening SAMSN closes any older copy that is still running in the background (including versions before this one), and the window's files are tagged with the version number so an old cached copy can't be shown. An old window that is left open says it has closed instead of looking frozen.
- The window title and the number beside the SAMSN name show which version is running.

## 0.3.42
- Updates now come from **github.com/Samual-M/SAMSN** (the GitHub account was renamed). Saved settings that pointed at the old name switch over by themselves.

## 0.3.43
- **The built-in updater has been removed** (the Update button, Help > Check for Updates, Settings > Updates and the weekly check). SAMSN no longer contacts GitHub by itself. To update, download the newest SAMSNV*.deb from github.com/Samual-M/SAMSN and install it; opening the new version closes the old one automatically.

## 0.3.44
- The apps-menu shortcut now always starts the installed SAMSN (/usr/bin/samsn), even if an older copy is lying around in ~/.local/bin.

## 0.3.45
- Built-in Paint updated to **SmPaint V1.12** (from SmPaint V1.11: movable/resizable text boxes with per-selection fonts, save as PDF, outline thickness, touchpad pinch zoom).
- Pictures now open **fitted to the window**: big screenshots are zoomed out so you see the whole picture (never zoomed in past 100%), and it re-fits once the window has its final size.

## 0.3.46
- SmPaint (V1.13) has a **Send back to AI >>** button when it was opened from a chat (or press Ctrl+Enter). It saves your edit, closes SmPaint and sends the picture to the AI straight away, together with anything you had typed in the message box. Closing SmPaint the normal way still just puts the picture in your message so you can add a note first.

## 0.3.47
- SmPaint (V1.14): **Send back to AI** now opens a small box where you can type a message to go with the picture (optional). Press Send and the picture and your message go to the AI together.

## 0.3.48
- **Display pictures:** fixed changing your picture (it now updates straight away in the conversation too, keeps see-through edges instead of turning them black, and is stored sharper).
- **Settings > Appearance** (live preview while you drag):
  - **Display picture size** slider (bigger or smaller pictures on the right; the chat makes room).
  - **Typing box height** slider (the split between the messages and the typing box).
  - **Text size** slider.
  - **Text effects:** None, **Coding** (code-editor colours, monospace), **Matrix** (green glowing text over falling code), **Rainbow** (shimmering text), **Rave** (slowly cycling neon). Effects respect the system "reduce motion" setting.
  - **Dark mode** built in: the white message and typing boxes go dark too, in both themes. The included Dark mode plug-in was updated the same way.
- **MSN Modern** now shows chat backgrounds (Tools > My Backgrounds).
- Conversation titles keep text written in `code`.
- Plug-ins that come with SAMSN update themselves when a newer copy ships (your own plug-ins are never changed).

## 0.3.49
- **The chat you are in is highlighted** in the left column (blue bar and bold title).
- **MSN Modern:** the "To:" bar is gone; switch models with the box in the strip at the top.
- **Drag the line above the typing box** to make it taller or shorter (both themes; double-click resets).
- **The "A" button** on the typing toolbar opens text effects (None, Coding, Matrix, Rainbow, Rave), bigger/smaller text, dark mode and font and colour.
- **MSN Modern:** slimmer typing toolbar (small icons, no labels) for more room.

## 0.3.50
- Built-in SmPaint updated to your **V1.17** (left-column palette, -/+ zoom buttons, live text boxes, desktop file dialogs, smoother resizing...) plus the SAMSN mode (V1.18).
- Marking up a picture: press **Done - add to my message** in SmPaint (or Ctrl+Enter, or just close it). The marked-up picture is attached to your normal message box, exactly as if you had dragged it in, so you can type your comments before sending. The small message box in SmPaint is gone.
- **Enter now starts a new line.** Messages are sent only with the **Send** button (slash commands too).

## 0.3.51
- **Fixed the "too long for this model's memory of 4096 tokens" message on every reply.**
  - Only the newest picture is sent to the model; older pictures are mentioned instead of re-sent (each picture uses about 800 tokens).
  - Ollama and .gguf models now get 8192 tokens of memory by default instead of 4096 (change it with "Memory size" in the Details column).
  - When a model's limit is reached, SAMSN remembers it and trims old messages before sending, instead of failing first.
  - The note is shown once as a grey line in the window and is no longer written into the model's replies (old notes are hidden too).
- "<name> is typing a message..." now only shows while the reply's text is actually appearing.
